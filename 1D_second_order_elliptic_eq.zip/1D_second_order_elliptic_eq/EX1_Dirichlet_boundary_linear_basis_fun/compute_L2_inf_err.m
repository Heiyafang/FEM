function error = compute_L2_inf_err(analytic_fun,solution,P,T,Tb,basis_type,basis_der_x,Gauss_type)

N = size(T,2);
for n=1:N
    vertices = P(:,T(:,n)); % coordinates of nth mesh elements
    uh_local_vec = solution(Tb(:,n)); % P T Pb Tb ? which one ?
    N_lb = size(Tb,1);
    [~,Gauss_nodes] = generate_Gauss(vertices,Gauss_type);
    int_value(n) = L2_inf_err(analytic_fun,Gauss_nodes,uh_local_vec,N_lb,vertices,basis_type,basis_der_x);

end
error = max(int_value);