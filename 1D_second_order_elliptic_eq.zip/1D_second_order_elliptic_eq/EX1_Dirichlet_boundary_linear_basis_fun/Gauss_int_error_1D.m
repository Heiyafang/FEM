function int_value = Gauss_int_error_1D(analytic_fun,Gauss_nodes,Gauss_weights,uh_local_vec,N_lb,vertices,basis_type,basis_der_x)

%------------------------------
% Gpn: guass point of number
%-------------------------------
Gpn=length(Gauss_nodes);
int_value = 0;
for k = 1:Gpn
    int_value = int_value+Gauss_weights(k)*...
    (feval(analytic_fun,Gauss_nodes(k)) - local_FE_fun_1D(Gauss_nodes(k),uh_local_vec,N_lb,vertices,basis_type,basis_der_x))^2;
%     local_FE_fun_1D(x,uh_local_vec,N_lb,vertices,basis_type,basis_index,basis_der_x)
end