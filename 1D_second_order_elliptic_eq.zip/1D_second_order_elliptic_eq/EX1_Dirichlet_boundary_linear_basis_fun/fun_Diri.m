function result=fun_Diri(x)

result=x*cos(x);