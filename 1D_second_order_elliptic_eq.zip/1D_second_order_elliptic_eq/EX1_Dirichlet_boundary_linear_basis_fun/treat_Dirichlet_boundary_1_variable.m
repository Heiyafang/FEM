function [A,b]=treat_Dirichlet_boundary_1_variable( Diri_fun, A, b, boundarynodes, Pb_test)
%Dirichlet = 0
nbn=size(boundarynodes,2);%the number of boundarynodes that is columns of boundarynodes
  for k=1:nbn
     if boundarynodes(1,k) == 0 % % Dirichlet condition
           i=boundarynodes(2,k);
           A(i,:)=0;
           A(i,i)=1;
           b(i)=feval(Diri_fun, Pb_test(i));    
      end
  end

