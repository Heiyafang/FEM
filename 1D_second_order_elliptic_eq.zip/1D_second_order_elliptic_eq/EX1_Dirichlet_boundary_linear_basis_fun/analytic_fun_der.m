function result = analytic_fun_der(x)
result = cos(x) - x.*sin(x);