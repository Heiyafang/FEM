function [solution,Basis,Grobal,err] = FE_solver_1D_Poisson(left,right,h,basis_type_trial, ...
                                         basis_type_test,Gauss_type,left_boundary_type,right_boundary_type)
% Yafang Hei, 02/02/2024;


%% ----------------------------------------
% basis_type_trial = 101 : 1D linear
% basis_type_trial = 102 : 1D Qudratic
%%-----------------------------------------
format long e
% generate the information matrices
[Grobal.P,Grobal.T] =  generate_PT(left, right, h, basis_type_trial); % in 1D P_test=P_trail,T_test=T_trail
N = size(Grobal.T,2);% uniform 1D

if basis_type_trial == 101 
    Basis.Pb_trail= Grobal.P;
    Basis.Tb_trail=Grobal.T;
    Basis.N_lb_trial =size(Basis.Tb_trail,1);
elseif basis_type_trial == 102
       %Basis.Pb_trail=;
       %Basis.Tb_trail=;
     Basis.N_lb_trial =size(Basis.Tb_trail,1);
end
if basis_type_test == 101
    Basis.Pb_test=Grobal.P;
    Basis.Tb_test=Grobal.T;
    Basis.N_lb_test = size(Basis.Tb_test,1);

elseif basis_type_test == 102
       %Basis.Pb_test=;
       %Basis.Tb_test=;
       Basis.N_lb_test = size(Basis.Tb_test,1);
end
Nb = N+1; 


%%----------------- Assemble matrix A------------------

Basis.matrix_size=[Nb, Nb];
Basis.A_basis_der_x_trail = 1;
Basis.A_basis_der_x_test = 1;
Basis.b_basis_der_x_test = 0;
A = assemble_matrix_1D('fun_c',Gauss_type,Basis.matrix_size,N,Grobal.P,Grobal.T,Basis.Tb_trail,Basis.Tb_test, ...
                                Basis.N_lb_trial,Basis.N_lb_test, ...
                                basis_type_trial,Basis.A_basis_der_x_trail,...
                                basis_type_test,Basis.A_basis_der_x_test); % steady, linear, without time

%%----------------- Assemble vector  b------------------
b= assmble_vector_1D('fun_f',Gauss_type,Basis.matrix_size,N,Grobal.P,Grobal.T,Basis.Tb_test, ...
                                Basis.N_lb_test,basis_type_test,Basis.b_basis_der_x_test);

%% --------------------- Boundary -----------------------
boundarynodes = generate_boundarynodes(left_boundary_type, right_boundary_type, Nb);
[A,b] = treat_Dirichlet_boundary_1_variable('fun_Diri', A, b, boundarynodes, Basis.Pb_test);

%% ---------------- Solution--------------------------
solution = A\b;


%% --------------------- compute  error--------------------------%%

x=(left:h:right);
accrate_result=analytic_fun(x);
max_error=max(abs(accrate_result'-solution));

L2_error_temp = compute_int_square_error('analytic_fun',solution,Grobal.P,Grobal.T,Basis.Tb_trail,basis_type_trial,0,Gauss_type);
H1_semi_error_temp = compute_int_square_error('analytic_fun_der',solution,Grobal.P,Grobal.T,Basis.Tb_trail,basis_type_trial,1,Gauss_type);
H1_error = sqrt(L2_error_temp + H1_semi_error_temp);

L2_error = sqrt(L2_error_temp);
H1_semi_error = sqrt(H1_semi_error_temp);

L2_inf_err = compute_L2_inf_err('analytic_fun',solution,Grobal.P,Grobal.T,Basis.Tb_trail,basis_type_trial,0,Gauss_type);


err.max_err = max_error;
err.L2_inf_err = L2_inf_err;
err.L2_err = L2_error;
err.H1_semi_err = H1_semi_error;
err.H1_err = H1_error;
