function [P, T]=generate_PT(left, right, h, basis_type)
%p45 p48
%basis_type==101; 1D  linear nodal basis functions
    
N=(right-left)/h;

if basis_type==101
      for k=1:N+1
         P(k)=left+(k-1)*h; %P=(x1,x2....,xn)
      end
        for n=1:N
         T(1,n)=n; %T=[1,2,...N; 2 3 ...N+1]
         T(2,n)=n+1;
        end
end
if basis_type==102
      for k=1:N+1
         P(k)=left+(k-1)*h; %P=(x1,x2....,xn)
      end
        for n=1:N
         T(1,n)=n; %T=[1,2,...N; 2 3 ...N+1]
         T(2,n)=n+1;
        end
end


