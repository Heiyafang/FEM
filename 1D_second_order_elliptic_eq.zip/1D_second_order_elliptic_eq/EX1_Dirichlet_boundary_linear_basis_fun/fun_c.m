function result = fun_c(x)

result =  exp(x);