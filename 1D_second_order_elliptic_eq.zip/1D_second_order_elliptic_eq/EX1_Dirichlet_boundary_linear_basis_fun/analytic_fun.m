function result = analytic_fun(x)
result = x.*cos(x);