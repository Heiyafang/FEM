function result = fun_f(x)

result =  -exp(x) * (cos(x) - 2 * sin(x) - x * cos(x) - x*sin(x));