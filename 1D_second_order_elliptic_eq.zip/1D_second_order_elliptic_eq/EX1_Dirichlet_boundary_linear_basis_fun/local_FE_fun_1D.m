function result = local_FE_fun_1D(x,uh_local_vec,N_lb,vertices,basis_type,basis_der_x)
% wn
result = 0;
for k = 1:N_lb
    result = result + uh_local_vec(k) * ...
  FE_basis_local_fun_1D(x,vertices,basis_type,k,basis_der_x);
end