function boundarynodes = generate_boundarynodes(left_boundary_type, right_boundary_type, Nb)

 boundarynodes=[left_boundary_type right_boundary_type; 1 Nb];
 % Onle left and right have boundary condition