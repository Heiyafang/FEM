function [Pb,Tb]=generate_PbTb(left, right, h, basis_type)
%p45 p48
%basis_type==101; 1D  linear nodal basis functions
    
N=(right-left)/h;


if basis_type==101
    Nb = N+1;
      for k=1:Nb
         Pb(k)=left+(k-1)*h; %P=(x1,x2....,xn)
      end
      for n=1:Nb
         Tb(1,n)=n; %T=[1,2,...N; 2 3 ...N+1]
         Tb(2,n)=n+1;
      end
end
if basis_type==102
    Nb = 2*N+1;
      for k=1:Nb
         Pb(k)=left+(k-1)*h/2; %P=(x1,x2....,xn)
      end
      for n=1:Nb
         Tb(1,n)=2*n-1; %T=[1,2,...N; 2 3 ...N+1]
         Tb(2,n)=2*n+1;
         Tb(3,n) = 2*n;
      end
end



