function result = FE_basis_local_fun_1D(x,vertices,basis_type,basis_index,basis_der_x)
%%------------------------------------------------------------------
% basis_type: basis_function_type
% vertices: 顶点
% basis_type 101: 1D finite element linear basis functions
% basis_type 102: 1D quadratic basis functions
% vertices(1) = x_n
% vertices(2) = x_n+1
%%--------------------------------------------------------------
h = vertices(2) -  vertices(1);
 if basis_type == 101 % 1D linear finite element just have two local linear basis functions
     if basis_index == 1
         if basis_der_x == 0
             result = (vertices(2)-x)/h ;
         elseif basis_der_x == 1
             result = -1/h;
         elseif basis_der_x >= 2 && (basis_der_x == fix(basis_der_x)) % integer
             result = 0;
         else
             warning = 'wrong input for basis derivative that can not be negative or fraction' ;
         end
     elseif basis_index == 2
         if basis_der_x == 0
             result = (x- vertices(1))/h;
         elseif basis_der_x == 1
             result = 1/h;
         elseif basis_der_x >= 2 && (basis_der_x == fix(basis_der_x))
             result = 0;
         else
             warning = 'wrong input for basis derivative that can not be negative or fraction';
         end
     else
         warning = 'wrong input for basis index, the basis index cannot over 2 for 1D linear finite element (basis_type = 101)';
     end

 elseif basis_type == 102 % quadratic basis functions have 3 basis function
     if basis_index == 1
         if basis_der_x == 0
             result = 2 * ((x - vertices(1))/h)^2 - 3 * (x - vertices(1))/h + 1; 
         elseif basis_der_x == 1
             result = 4 *((x - vertices(1))/h) * (1/h) - 3 * (1/h);
         elseif  basis_der_x == 2
             result = 4 / (h^2);
         elseif  basis_der_x >= 3 && (basis_der_x == fix(basis_der_x))
             result = 0;
         else
             warning = 'wrong input for basis derivative that can not be negative or fraction';
         end
     elseif basis_index == 2
         if basis_der_x == 0
             result =  2 * ((x - vertices(1))/h)^2 - (x - vertices(1))/h; 
         elseif basis_der_x == 1
             result = 4*((x - vertices(1))/h) * (1/h) - (1/h);
         elseif  basis_der_x == 2
             result = 4 / (h^2);
         elseif  basis_der_x >= 3 && (basis_der_x == fix(basis_der_x))
             result = 0;
         else
             warning = 'wrong input for basis derivative that can not be negative or fraction';
         end
     elseif basis_index == 3
         if basis_der_x == 0
             result = -4 * ((x - vertices(1))/h)^2 + 4 * (x - vertices(1))/h; 
         elseif basis_der_x == 1
             result = -8 * ((x - vertices(1))/h) * (1/h) + 4*(1/h);
         elseif  basis_der_x == 2
             result = -8 / (h^2);
         elseif  basis_der_x >= 3 && (basis_der_x == fix(basis_der_x))
             result = 0;
         else
             warning = 'wrong input for basis derivative that can not be negative or fraction';

         end

     else
          warning = 'wrong input for basis index the basis index cannot over 3 for 1D quadratic finite element (basis_type = 102)';
     end

 end