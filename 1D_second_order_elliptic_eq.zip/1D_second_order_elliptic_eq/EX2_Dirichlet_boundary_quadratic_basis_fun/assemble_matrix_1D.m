function A = assemble_matrix_1D(coe_fun,Gauss_type,matrix_size,N,P,T,Tb_trail,Tb_test, ...
                                N_lb_trial,N_lb_test, ...
                                basis_type_trail,basis_der_x_trail,...
                                basis_type_test,basis_der_x_test)
%----------------------------
% matrix_size(1) = Nb_test; matrix_size(2) = Nb_trail
% N: number of elements
% N_lb_trial : number of local basis trail function
% N_lb_test : number of local basis test function
% quad: quadrature
%---------------------------------
A = sparse (matrix_size(1), matrix_size(2));
for n=1:N
    vertices = P(:,T(:,n)); % coordinates of nth mesh elements
    [Gauss_weights,Gauss_nodes] = generate_Gauss(vertices,Gauss_type);
    for alpha = 1:N_lb_trial
        for beta = 1: N_lb_test
            int_value = Gauss_quad_1D_trail_test(coe_fun,Gauss_weights,...
                Gauss_nodes,vertices,basis_type_trail,alpha,basis_der_x_trail,...
                basis_type_test,beta,basis_der_x_test);
            % S(beta,alpha) = int_value;
            i = Tb_test(beta,n);
            j = Tb_trail(alpha,n);
            A(i,j) =  A(i,j) + int_value;
        end
    end
    %A(Tb_test(:,n),Tb_trail(:,n)) = A(Tb_test(:,n),Tb_trail(:,n))+S
end

