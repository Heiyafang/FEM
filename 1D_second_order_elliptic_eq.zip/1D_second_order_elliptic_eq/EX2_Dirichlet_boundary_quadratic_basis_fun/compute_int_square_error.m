function error = compute_int_square_error(analytic_fun,solution,P,T,Tb,basis_type,basis_der_x,Gauss_type)

error = 0;
N = size(T,2);
for n=1:N
    vertices = P(:,T(:,n)); % coordinates of nth mesh elements
    uh_local_vec = solution(Tb(:,n)); % P T Pb Tb ? which one ?
    N_lb = size(Tb,1);
    [Gauss_weights,Gauss_nodes] = generate_Gauss(vertices,Gauss_type);
    error = error + Gauss_int_error_1D(analytic_fun,Gauss_nodes,Gauss_weights,uh_local_vec,N_lb,vertices,basis_type,basis_der_x);
end
% error = error;