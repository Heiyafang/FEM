function output = L2_inf_err(analytic_fun,Gauss_nodes,uh_local_vec,N_lb,vertices,basis_type,basis_der_x)

Gpn=length(Gauss_nodes);
for k = 1:Gpn
rn(k) = abs((feval(analytic_fun,Gauss_nodes(k)) - ...
    local_FE_fun_1D(Gauss_nodes(k),uh_local_vec,N_lb,vertices,basis_type,basis_der_x)));

end
output = max(rn);