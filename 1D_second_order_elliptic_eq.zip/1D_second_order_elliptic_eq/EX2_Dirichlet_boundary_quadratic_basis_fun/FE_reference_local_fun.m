function result = FE_reference_local_fun(x_hat,basis_type,basis_index,basis_der_x)

% x_hat = (x - vertices(1))/h;


if basis_type == 101
    if basis_index == 1
        if basis_der_x == 0 
            result = -x_hat +1;
        elseif basis_der_x == 1
            result = -1;
        elseif basis_der_x >= 2 && (basis_der_x == fix(basis_der_x))
             result = 0;
         else
             warning = 'wrong input for basis derivative that can not be negative or fraction';
        end

    elseif basis_index == 2
        if basis_der_x == 0
            result = x_hat;
        elseif basis_der_x == 1
            result = 1;
        elseif basis_der_x >= 2 && (basis_der_x == fix(basis_der_x))
             result = 0;
         else
             warning = 'wrong input for basis derivative that can not be negative or fraction';
        end

    else
        warning = 'wrong input for basis index, the basis index cannot over 2 for 1D linear finite element (basis_type = 101)';
    end



elseif basis_type == 102
    if basis_index ==1
        if basis_der_x == 0
            result = 2 * x_hat.^2 - 3 *x_hat +1;
        elseif basis_der_x == 1
            result = 4 * x_hat -3;
        elseif basis_der_x ==2
            result = 4;
        elseif basis_der_x > 3 && (basis_der_x == fix(basis_der_x))
            result = 0;
        else 
            warning = 'wrong input for basis derivative that can not be negative or fraction';
        end

    elseif basis_index ==2
        if basis_der_x == 0
            result = 2 * x_hat.^2 - x_hat;
        elseif basis_der_x == 1
            result = 4 * x_hat -1;
        elseif basis_der_x ==2
            result = 4;
        elseif basis_der_x > 3 && (basis_der_x == fix(basis_der_x))
            result = 0;
        else 
            warning = 'wrong input for basis derivative that can not be negative or fraction';
        end

    elseif basis_index == 3
        if basis_der_x == 0
            result = -4 * x_hat.^2 + 4 *x_hat;
        elseif basis_der_x == 1
            result = -8 * x_hat +4;
        elseif basis_der_x ==2
            result = -8;
        elseif basis_der_x > 3 && (basis_der_x == fix(basis_der_x))
            result = 0;
        else 
            warning = 'wrong input for basis derivative that can not be negative or fraction';
        end
    else
        warning = 'wrong input for basis index, the basis index cannot over 3 for 1D linear finite element (basis_type = 102)';

    end

else
    warning = 'wrong input for basis_type, basis type= 101 or 102';

end



