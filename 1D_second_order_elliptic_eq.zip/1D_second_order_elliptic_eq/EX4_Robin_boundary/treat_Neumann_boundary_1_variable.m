function [A,b]=treat_Neumann_boundary_1_variable(fun_Neum,fun_c, A, b, boundarynodes, Pb_test)

nbn=size(boundarynodes,2);%the number of boundarynodes that is columns of boundarynodes 
A = A;
for k =1:nbn
    if boundarynodes(1,k) == 1
        i = boundarynodes(2,k); % i is the location of xi i=1 or i=N+1
        b(i) =b(i) - feval(fun_c,Pb_test(i)) * feval(fun_Neum,Pb_test(i)) ;
    end
end