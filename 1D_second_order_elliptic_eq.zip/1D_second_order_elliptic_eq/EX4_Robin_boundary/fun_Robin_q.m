function result = fun_Robin_q(x)

result = 1;