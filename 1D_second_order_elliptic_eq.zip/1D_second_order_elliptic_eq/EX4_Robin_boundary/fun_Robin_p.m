function result = fun_Robin_p(x)

result = 1;