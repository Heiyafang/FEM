clear
clc
format shortE
left = 0;
right = 1;
h = [1/4 1/8 1/16 1/32]';
basis_type = 102;
basis_type_trial = 102;
basis_type_test = 102;

Gauss_type = 3;
left_boundary_type = 1;
right_boundary_type = 0;

for i = 1:length(h)
    [solution, Basis, Grobal,err(i)] = FE_solver_1D_Poisson(left,right,h(i),basis_type,basis_type_trial, ...
                                         basis_type_test,Gauss_type,left_boundary_type,right_boundary_type);

end


b=struct2cell(err);
max_err = cell2mat(b(1,:))';
L_inf_error=cell2mat(b(2,:))';
Convergence_L_inf = log(L_inf_error(1:end-1) ./ L_inf_error(2:end)) ./ log(h(1:end-1) ./ h(2:end));
Convergence_L_inf = [0;Convergence_L_inf];

L2_norm_error=cell2mat(b(3,:))';
Convergence_L2 = log(L2_norm_error(1:end-1) ./ L2_norm_error(2:end)) ./ log(h(1:end-1) ./ h(2:end));
Convergence_L2 = [0;Convergence_L2];

H1_semi_error=cell2mat(b(4,:))';
Convergence_H1_semi = log(H1_semi_error(1:end-1) ./ H1_semi_error(2:end)) ./ log(h(1:end-1) ./ h(2:end));
Convergence_H1_semi = [0;Convergence_H1_semi];

H1_err = cell2mat(b(5,:))';
Convergence_H1_err = log(H1_err(1:end-1) ./ H1_err(2:end)) ./ log(h(1:end-1) ./ h(2:end));
Convergence_H1_err = [0;Convergence_H1_err];


T = table( h, max_err,  L_inf_error,  L2_norm_error,  H1_semi_error,H1_err)
Covergence = table( h, Convergence_L_inf,  Convergence_L2,  Convergence_H1_semi,  Convergence_H1_err)


% Open the file in append mode
fileID = fopen('EX3_Result_quadratic.txt', 'w');  

% Append a separator line or any other information you want
headerText = '-----------This is the result for Dirichlet condition, quadratic basis funciton, Triangular element--------.\n';
fprintf(fileID, headerText);

% Append the table data with specific formatting
fprintf(fileID, 'h\tmax_err \tL_inf_error\tL2_norm_error\tH1_semi_error\tH1_err\n');
for i = 1:height(T)
    fprintf(fileID, '%.4f\t%.4e\t%.4e\t%.4e\t%.4e\t%.4e\n',T.h(i), T.max_err(i),T.L_inf_error(i), T.L2_norm_error(i), T.H1_semi_error(i),T.H1_err(i));
end


headerText = '-----------convergence -------.\n';
fprintf(fileID, headerText);

% Append the table data with specific formatting
fprintf(fileID, 'h\t L_inf\t L2\t H1_semi\t H1_err\n');

for i = 1:height(T)
    fprintf(fileID, '%.4f\t%.4e\t%.4e\t%.4e\t%.4e\t\n',Covergence.h(i),Covergence.Convergence_L_inf(i), Covergence.Convergence_L2(i), Covergence.Convergence_H1_semi(i),Covergence.Convergence_H1_err(i));
end
% Close the file
fclose(fileID);
disp('See the result in txt file')
