function error = compute_L_inf_err(analytic_fun,solution,P,T,Tb,basis_type,basis_der_x,Gauss_type)

error = 0;
N = size(T,2);
for n=1:N
    vertices = P(:,T(:,n)); % coordinates of nth mesh elements
    lower_bound=min(vertices(1),vertices(2));
    upper_bound=max(vertices(1),vertices(2));
    vertices=[lower_bound,upper_bound];
    uh_local_vec = solution(Tb(:,n)); % P T Pb Tb ? which one ?
    N_lb = size(Tb,1);
    [~,Gauss_nodes] = generate_Gauss(vertices,Gauss_type);

    %int_value(n) = L_inf_err(analytic_fun,Gauss_nodes,uh_local_vec,N_lb,vertices,basis_type,basis_der_x);
     %temp=max(abs(feval(accurate_function,Gauss_point_local_1D(:))-FE_solution_1D(Gauss_point_local_1D(:),uh_local,vertices,basis_type,derivative_degree)));    
    temp = abs((feval(analytic_fun,Gauss_nodes(:)) - ...
    local_FE_fun_1D(Gauss_nodes(:),uh_local_vec,N_lb,vertices,basis_type,basis_der_x)));
     if temp>error
        error=temp;
    end

end
%error = max(int_value);