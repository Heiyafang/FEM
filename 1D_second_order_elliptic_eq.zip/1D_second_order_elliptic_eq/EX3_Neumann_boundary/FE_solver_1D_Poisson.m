function [solution,Basis,Grobal,err] = FE_solver_1D_Poisson(left,right,h,basis_type,basis_type_trial, ...
                                         basis_type_test,Gauss_type,left_boundary_type,right_boundary_type)
%% ----------------------------------------
% basis_type = 101 : 1D linear
% basis_type = 102 : 1D Qudratic
%%-----------------------------------------

%%------------------Obtain P, T, Pb, Tb,N_lb---------------------
[Grobal.P,Grobal.T] =  generate_PT(left, right, h, basis_type); % in 1D P_test=P_trail,T_test=T_trail
[Basis.Pb_trail,Basis.Tb_trail]= generate_PbTb(left, right, h, basis_type_trial);
[Basis.Pb_test,Basis.Tb_test]= generate_PbTb(left, right, h, basis_type_test);
Basis.N_lb_trial =size(Basis.Tb_trail,1);
Basis.N_lb_test =size(Basis.Tb_test,1);

N = size(Grobal.T,2);% uniform 1D
if basis_type == 101
        Nb = N+1; 
elseif basis_type == 102
        Nb = 2*N +1;
end

Basis.matrix_size=[Nb, Nb];
Basis.A_basis_der_x_trail = 1;
Basis.A_basis_der_x_test = 1;
Basis.b_basis_der_x_test = 0;
A = assemble_matrix_1D('fun_c',Gauss_type,Basis.matrix_size,N,Grobal.P,Grobal.T,Basis.Tb_trail,Basis.Tb_test, ...
                                Basis.N_lb_trial,Basis.N_lb_test, ...
                                basis_type_trial,Basis.A_basis_der_x_trail,...
                                basis_type_test,Basis.A_basis_der_x_test); % steady, linear, without time
b= assmble_vector_1D('fun_f',Gauss_type,Basis.matrix_size,N,Grobal.P,Grobal.T,Basis.Tb_test, ...
                                Basis.N_lb_test,basis_type_test,Basis.b_basis_der_x_test);

boundarynodes = generate_boundarynodes(left_boundary_type, right_boundary_type, Nb);
[A,b] = treat_Neumann_boundary_1_variable('fun_Neum','fun_c', A, b, boundarynodes, Basis.Pb_test);
[A,b] = treat_Dirichlet_boundary_1_variable('fun_Diri', A, b, boundarynodes, Basis.Pb_test);


solution = A\b;
%% --------------------- compute  error--------------------------%%

if basis_type == 101
    x=(left:h:right);
    accrate_result=analytic_fun(x);
    max_error=max(abs(accrate_result'-solution));
elseif basis_type == 102
    for k=1:(2*N+1)
        y(k)=left+(k-1)*h/2;
    end
    accrate_result=analytic_fun(y);
    max_error=max(abs(accrate_result'-solution)); 
else
end

L2_error_temp = compute_int_square_error('analytic_fun',solution,Grobal.P,Grobal.T,Basis.Tb_trail,basis_type_trial,0,Gauss_type);
H1_semi_error_temp = compute_int_square_error('analytic_fun_der',solution,Grobal.P,Grobal.T,Basis.Tb_trail,basis_type_trial,1,Gauss_type);

H1_error = sqrt(L2_error_temp + H1_semi_error_temp);
L2_error = sqrt(L2_error_temp);
H1_semi_error = sqrt(H1_semi_error_temp);
L_inf_err = compute_L2_inf_err('analytic_fun',solution,Grobal.P,Grobal.T,Basis.Tb_trail,basis_type_trial,0,Gauss_type);


err.max_err = max_error;
err.L2_inf_err = L_inf_err;
err.L2_err = L2_error;
err.H1_semi_err = H1_semi_error;
err.H1_err = H1_error;