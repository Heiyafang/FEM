function result = fun_Neum(x)

result = cos(x) - sin(x);