function result = FE_reference_basis_2D(element_type,x_hat,y_hat,basis_type,basis_index,basis_der_x,basis_der_y)
%x,vertices,basis_type,basis_index,basis_der_x
%%----------basis type------------
% basis_type = 201   2D linear
% basis_type = 202 2D quadratic
%%------------------
if strcmpi(element_type,'Triangular')
    if basis_type == 201
       if basis_index == 1
         if basis_der_x == 0 && basis_der_y == 0
            result = - x_hat -y_hat +1;
            elseif basis_der_x == 1 && basis_der_y ==0
            result = -1;
            elseif basis_der_x == 0 && basis_der_y == 1
            result = -1;
            else
                disp('der_x and der_y can not over 1');
          end
       
        elseif basis_index == 2
             if basis_der_x == 0 && basis_der_y == 0
                result = x_hat;
            elseif basis_der_x == 1 && basis_der_y == 0
                result = 1;
            elseif basis_der_x == 0 && basis_der_y ==1
                result = 0;
            else
                disp('der_x and der_y can not over 1')
             end
           
     elseif basis_index == 3
            if basis_der_x == 0 && basis_der_y == 0
                result = y_hat;
            elseif basis_der_x == 1 && basis_der_y == 0
                result = 0;
            elseif basis_der_x == 0 && basis_der_y ==1
                result = 1;
            else
                 disp('der_x and der_y can not over 1')
            end
        
        else
            disp(' wrong basis_index(can not over 3) for basis_type =201')
       end

    elseif basis_type == 202
        if basis_index == 1
            if basis_der_x == 0 && basis_der_y == 0  
                result = 2 .* (x_hat.^2) + 2 .* (y_hat.^2) + 4 .* x_hat.*y_hat- 3.*y_hat - 3 .* x_hat +1;
            elseif basis_der_x == 1 && basis_der_y == 0
                result = 4 .* x_hat  + 4 .*y_hat- 3;
            elseif basis_der_x == 0 && basis_der_y == 1
                result = 4 .* y_hat + 4 .* x_hat -3;
            elseif basis_der_x == 2 && basis_der_y == 0
                result = 4;
            elseif basis_der_x == 0 && basis_der_y == 2
                result = 4;
            elseif basis_der_x == 1 && basis_der_y == 1
                result = 4;
            else
                disp('der_x and der_y can not over 2')
            end
        elseif basis_index == 2
            if basis_der_x == 0 && basis_der_y == 0  
                result = 2 .* (x_hat.^2) - x_hat;
            elseif basis_der_x == 1 && basis_der_y == 0
                result = 4 .* x_hat - 1;
            elseif basis_der_x == 0 && basis_der_y == 1
                result = 0;
            elseif basis_der_x == 2 && basis_der_y == 0
                result = 4;
            elseif basis_der_x == 0 && basis_der_y == 2
                result = 0;
            elseif basis_der_x == 1 && basis_der_y == 1
                result = 0;
            else
                disp('der_x and der_y can not over 2')
            end
        
        elseif basis_index == 3
            if basis_der_x == 0 && basis_der_y == 0  
                result = 2 .* (y_hat.^2) - y_hat; 
            elseif basis_der_x == 1 && basis_der_y == 0
                result = 0;
            elseif basis_der_x == 0 && basis_der_y == 1
                result = 4 .* y_hat - 1;
            elseif basis_der_x == 2 && basis_der_y == 0
                result = 0;
            elseif basis_der_x == 0 && basis_der_y == 2
                result = 4;
            elseif basis_der_x == 1 && basis_der_y == 1
                result = 0;
            else
                disp('der_x and der_y can not over 2')
            end
        
        elseif basis_index == 4
            if basis_der_x == 0 && basis_der_y == 0  
                result = - 4 .*(x_hat.^2) - 4.*x_hat .*y_hat + 4.*x_hat;
            elseif basis_der_x == 1 && basis_der_y == 0
                result = -8.*x_hat - 4.*y_hat +4;
            elseif basis_der_x == 0 && basis_der_y == 1
                result = -4.*x_hat;
            elseif basis_der_x == 2 && basis_der_y == 0
                result = -8;
            elseif basis_der_x == 0 && basis_der_y == 2
                result = 0;
            elseif basis_der_x == 1 && basis_der_y == 1
                result = -4;
            else
                disp('der_x and der_y can not over 2')
            end   
        elseif basis_index == 5
            if basis_der_x == 0 && basis_der_y == 0  
                result = 4.*x_hat.*y_hat;
            elseif basis_der_x == 1 && basis_der_y == 0
                result = 4.* y_hat;
            elseif basis_der_x == 0 && basis_der_y == 1
                result = 4.*x_hat;
            elseif basis_der_x == 2 && basis_der_y == 0
                result = 0;
            elseif basis_der_x == 0 && basis_der_y == 2
                result = 0;
            elseif basis_der_x == 1 && basis_der_y == 1
                result = 4;
            else
                disp('der_x and der_y can not over 2')
            end
       
        elseif basis_index == 6
            if basis_der_x == 0 && basis_der_y == 0  
                result = -4 .* (y_hat.^2) - 4.*x_hat.*y_hat + 4.*y_hat;
            elseif basis_der_x == 1 && basis_der_y == 0
                result = -4.*y_hat;
            elseif basis_der_x == 0 && basis_der_y == 1
                result = -8 .*y_hat - 4.*x_hat + 4;
            elseif basis_der_x == 2 && basis_der_y == 0
                result = 0;
            elseif basis_der_x == 0 && basis_der_y == 2
                result = -8;
            elseif basis_der_x == 1 && basis_der_y == 1
                result = -4;
            else
                disp('der_x and der_y can not over 2')
            end  
        end
    end
elseif strcmpi(element_type,'Rectangular')
    if basis_type == 201
        if basis_index == 1
            if basis_der_x == 0 && basis_der_y == 0
                result = (1-x_hat - y_hat + x_hat .* y_hat)/4;
            elseif basis_der_x ==1 && basis_der_y == 0
                result = (-1  + y_hat)/4;
            elseif basis_der_x ==0 && basis_der_y == 1
                result = (-1 + x_hat)/4;
            else
                disp("Wrong basis der for x or y");
            end
        elseif basis_index == 2
            if basis_der_x == 0 && basis_der_y == 0
                result = (1+x_hat - y_hat - x_hat .* y_hat)/4;
            elseif basis_der_x ==1 && basis_der_y == 0
                result = (1  -  y_hat)/4;
            elseif basis_der_x ==0 && basis_der_y == 1
                result = (-1 - x_hat)/4;
            else
                disp("Wrong basis der for x or y");
            end
        elseif basis_index ==3
            if basis_der_x == 0 && basis_der_y == 0
                result = (1 + x_hat + y_hat + x_hat .* y_hat)/4;
            elseif basis_der_x ==1 && basis_der_y == 0
                result = (1 +  y_hat)/4;
            elseif basis_der_x ==0 && basis_der_y == 1
                result = (1 + x_hat )/4;
            else
                disp("Wrong basis der for x or y");
            end
        elseif basis_index == 4
            if basis_der_x == 0 && basis_der_y == 0
                result = (1 - x_hat + y_hat - x_hat .* y_hat)/4;
            elseif basis_der_x ==1 && basis_der_y == 0
                result = ( - 1 - y_hat)/4;
            elseif basis_der_x ==0 && basis_der_y == 1
                result = (1  - x_hat)/4;
            else
                disp("Wrong basis der for x or y");
            end
        end
        


    elseif basis_type == 202
        if basis_index == 1
            if basis_der_x == 0 && basis_der_y == 0
                result = (1/4).*(x_hat.*y_hat - (x_hat.^2).* y_hat - x_hat.*(y_hat.^2) + (x_hat.^2).*(y_hat.^2));
            elseif basis_der_x ==1 && basis_der_y == 0
                result = (1/4).*(y_hat - y_hat .* 2.* x_hat - y_hat.^2 +(y_hat.^2) .* 2.*x_hat);
            elseif basis_der_x ==0 && basis_der_y == 1
                result = x_hat./4 - (x_hat.*y_hat)/2 + ((x_hat.^2).*y_hat)./2 - x_hat.^2./4;
            elseif basis_der_x ==2 && basis_der_y == 0
                result = y_hat.^2./2 - y_hat./2;
            elseif basis_der_x ==0 && basis_der_y == 2
                 result = x_hat.^2./2 - x_hat./2;
            elseif basis_der_x ==1 && basis_der_y == 1
                result = x_hat.*y_hat - y_hat./2 - x_hat./2 + 1/4;
            else
                disp("Wrong basis der for x or y");
            end
        elseif basis_index == 2
            if basis_der_x == 0 && basis_der_y == 0
                result = (1/4).*(-x_hat.*y_hat - (x_hat.^2).* y_hat + x_hat.*(y_hat.^2) + (x_hat.^2).*(y_hat.^2));
            elseif basis_der_x ==1 && basis_der_y == 0
               result = (x_hat.*y_hat.^2)./2 - (x_hat.*y_hat)./2 - y_hat./4 + y_hat.^2/4;
            elseif basis_der_x ==0 && basis_der_y == 1
                result = (x_hat.*y_hat)/2 - x_hat/4 + (x_hat.^2.*y_hat)/2 - x_hat.^2/4;
            elseif basis_der_x ==2 && basis_der_y == 0
                result = y_hat.^2/2 - y_hat/2;
            elseif basis_der_x ==0 && basis_der_y == 2
                result = x_hat.^2/2 + x_hat/2;
            elseif basis_der_x ==1 && basis_der_y == 1
                result = y_hat/2 - x_hat/2 + x_hat.*y_hat - 1/4;
            else
                disp("Wrong basis der for x or y");
            end
        elseif basis_index == 3
            if basis_der_x == 0 && basis_der_y == 0
                result = (1/4).*(x_hat.*y_hat + (x_hat.^2).* y_hat + x_hat.*(y_hat.^2) + (x_hat.^2).*(y_hat.^2));
            elseif basis_der_x ==1 && basis_der_y == 0
                result =  y_hat/4 + (x_hat.*y_hat)/2 + (x_hat.*y_hat.^2)/2 + y_hat.^2/4;
            elseif basis_der_x ==0 && basis_der_y == 1
                result = x_hat/4 + (x_hat.*y_hat)/2 + (x_hat.^2.*y_hat)/2 + x_hat.^2/4;
            elseif basis_der_x ==2 && basis_der_y == 0
                result = y_hat.^2/2 + y_hat/2;
            elseif basis_der_x ==0 && basis_der_y == 2
                result = x_hat.^2/2 + x_hat/2;
            elseif basis_der_x ==1 && basis_der_y == 1
                result = x_hat/2 + y_hat/2 + x_hat.*y_hat + 1/4;
            else
                disp("Wrong basis der for x or y");
            end
        elseif basis_index == 4
            if basis_der_x == 0 && basis_der_y == 0
                result = (1/4).*(-x_hat.*y_hat + (x_hat.^2).* y_hat - x_hat.*(y_hat.^2) + (x_hat.^2).*(y_hat.^2));
            elseif basis_der_x ==1 && basis_der_y == 0
                result = (x_hat.*y_hat)/2 - y_hat/4 + (x_hat.*y_hat.^2)/2 - y_hat.^2/4;
            elseif basis_der_x ==0 && basis_der_y == 1
                result = (x_hat.^2.*y_hat)/2 - (x_hat.*y_hat)/2 - x_hat/4 + x_hat.^2/4;
            elseif basis_der_x ==2 && basis_der_y == 0
                result = y_hat.^2/2 + y_hat/2;
            elseif basis_der_x ==0 && basis_der_y == 2
                result = x_hat.^2/2 - x_hat/2;
            elseif basis_der_x ==1 && basis_der_y == 1
                result = x_hat/2 - y_hat/2 + x_hat.*y_hat - 1/4;
            else
                disp("Wrong basis der for x or y");
            end
        elseif basis_index == 5
            if basis_der_x == 0 && basis_der_y == 0
                result = (1/2).*(-y_hat + (y_hat.^2) + (x_hat.^2).*y_hat - (x_hat.^2).*(y_hat.^2));
            elseif basis_der_x ==1 && basis_der_y == 0
                result = - x_hat.*y_hat.^2 + x_hat.*y_hat;
            elseif basis_der_x ==0 && basis_der_y == 1
                result = y_hat - x_hat.^2.*y_hat + x_hat.^2/2 - 1/2;
            elseif basis_der_x ==2 && basis_der_y == 0
                result = - y_hat.^2 + y_hat;
            elseif basis_der_x ==0 && basis_der_y == 2
                result = 1 - x_hat.^2;
            elseif basis_der_x ==1 && basis_der_y == 1
                result = x_hat - 2.*x_hat.*y_hat;
            else
                disp("Wrong basis der for x or y");
            end
        elseif basis_index == 6
            if basis_der_x == 0 && basis_der_y == 0
                result = (1/2).*(x_hat + (x_hat.^2) - x_hat.*(y_hat.^2) - (x_hat.^2).*(y_hat.^2));
            elseif basis_der_x ==1 && basis_der_y == 0
                result = x_hat - x_hat.*y_hat.^2 - y_hat.^2/2 + 1/2;
            elseif basis_der_x ==0 && basis_der_y == 1
                result = - y_hat.*x_hat.^2 - y_hat.*x_hat;
            elseif basis_der_x ==2 && basis_der_y == 0
                result = 1 - y_hat.^2;
            elseif basis_der_x ==0 && basis_der_y == 2
                result = - x_hat.^2 - x_hat;
            elseif basis_der_x ==1 && basis_der_y == 1
                result = - y_hat - 2.*x_hat.*y_hat;
            else
                disp("Wrong basis der for x or y");
            end
        elseif basis_index == 7
            if basis_der_x == 0 && basis_der_y == 0
                result = (1/2).*(y_hat + (y_hat.^2) - (x_hat.^2).*y_hat - (x_hat.^2).*(y_hat.^2));
            elseif basis_der_x ==1 && basis_der_y == 0
                result = - x_hat.*y_hat.^2 - x_hat.*y_hat;
            elseif basis_der_x ==0 && basis_der_y == 1
                result = y_hat - x_hat.^2.*y_hat - x_hat.^2/2 + 1/2;
            elseif basis_der_x ==2 && basis_der_y == 0
                result = - y_hat.^2 - y_hat;
            elseif basis_der_x ==0 && basis_der_y == 2
                result = 1 - x_hat.^2;
            elseif basis_der_x ==1 && basis_der_y == 1
                result = - x_hat - 2.*x_hat.*y_hat;
            else
                disp("Wrong basis der for x or y");
            end
        elseif basis_index == 8
            if basis_der_x == 0 && basis_der_y == 0
                result = (1/2).*(-x_hat + (x_hat.^2) + x_hat.*(y_hat.^2) - (x_hat.^2).*(y_hat.^2));
            elseif basis_der_x ==1 && basis_der_y == 0
                result = x_hat - x_hat.*y_hat.^2 + y_hat.^2/2 - 1/2;
            elseif basis_der_x ==0 && basis_der_y == 1
                result = - y_hat.*x_hat.^2 + y_hat.*x_hat;
            elseif basis_der_x ==2 && basis_der_y == 0
                result = 1 - y_hat.^2;
            elseif basis_der_x ==0 && basis_der_y == 2
                result = - x_hat.^2 + x_hat;
            elseif basis_der_x ==1 && basis_der_y == 1
                result = y_hat - 2.*x_hat.*y_hat;
            else
                disp("Wrong basis der for x or y");
            end
        elseif basis_index == 9
            if basis_der_x == 0 && basis_der_y == 0
                result = 1 - x_hat.^2 - y_hat.^2 + (x_hat.^2).*(y_hat.^2);
            elseif basis_der_x ==1 && basis_der_y == 0
                result = 2.*x_hat.*y_hat^2 - 2.*x_hat;
            elseif basis_der_x ==0 && basis_der_y == 1
                result = 2.*y_hat.*x_hat^2 - 2.*y_hat;
            elseif basis_der_x ==2 && basis_der_y == 0
                result = 2.*y_hat.^2 - 2;
            elseif basis_der_x ==0 && basis_der_y == 2
                result = 2.*x_hat.^2 - 2;
            elseif basis_der_x ==1 && basis_der_y == 1
                result = 4.*x_hat.*y_hat;
            else
                disp("Wrong basis der for x or y");
            end
        end  
    end
end
