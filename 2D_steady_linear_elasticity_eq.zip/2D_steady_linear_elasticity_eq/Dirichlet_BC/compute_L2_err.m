function result = compute_L2_err(fun_u,solution,element_type,P,T,Tb_error,Gauss_type,...
    basis_type_error)


result= sqrt(compute_int_error(fun_u,solution,element_type,P,T,Tb_error,Gauss_type,basis_type_error,0,0));
