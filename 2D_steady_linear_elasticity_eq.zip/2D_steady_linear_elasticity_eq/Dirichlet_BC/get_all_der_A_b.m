function [der_A,der_b]=get_all_der_A_b

% r s p q, / der_x_trail,der_y_trail;der_x_test,der_y_test;
%%  Pre der info for A matrix and b vector
% A1
der_x_trail_A1  = 1; %r
der_y_trail_A1 = 0; %s
der_x_test_A1 = 1;  %p
der_y_test_A1 = 0;  %q

%A2
der_x_trail_A2 = 1; %r
der_y_trail_A2 = 0; %s
der_x_test_A2 = 1; %p
der_y_test_A2 = 0; %q



% A3
der_x_trail_A3 = 0; %r
der_y_trail_A3 = 1; %s
der_x_test_A3 = 0; %p
der_y_test_A3 = 1; %q

%A4

der_x_trail_A4 = 0; %r
der_y_trail_A4 = 1; %s
der_x_test_A4 = 1; %p
der_y_test_A4 = 0; %q


%A5
der_x_trail_A5 = 1; %r
der_y_trail_A5 = 0; %s
der_x_test_A5 = 0; %p
der_y_test_A5 = 1; %q


% A6
der_x_trail_A6 = 1; %r
der_y_trail_A6 = 0; %s
der_x_test_A6 = 0; %p
der_y_test_A6 = 1; %q

%A7
der_x_trail_A7 = 0; %r
der_y_trail_A7 = 1; %s
der_x_test_A7 = 1; %p
der_y_test_A7 = 0; %q


%A8
der_x_trail_A8 = 0; %r
der_y_trail_A8 = 1; %s
der_x_test_A8 = 0; %p
der_y_test_A8 = 1; %q


% der for all matrix
der_A.der_A1 =  [der_x_trail_A1,der_y_trail_A1;der_x_test_A1,der_y_test_A1];
der_A.der_A2 =  [der_x_trail_A2,der_y_trail_A2;der_x_test_A2,der_y_test_A2];
der_A.der_A3 =  [der_x_trail_A3,der_y_trail_A3;der_x_test_A3,der_y_test_A3];
der_A.der_A4 =  [der_x_trail_A4,der_y_trail_A4;der_x_test_A4,der_y_test_A4];
der_A.der_A5 =  [der_x_trail_A5,der_y_trail_A5;der_x_test_A5,der_y_test_A5];
der_A.der_A6 =  [der_x_trail_A6,der_y_trail_A6;der_x_test_A6,der_y_test_A6];
der_A.der_A7 =  [der_x_trail_A7,der_y_trail_A7;der_x_test_A7,der_y_test_A7];
der_A.der_A8 =  [der_x_trail_A8,der_y_trail_A8;der_x_test_A8,der_y_test_A8];

% b1
der_x_test_b1 = 0;
der_y_test_b1 = 0;
der_b.der_b1 =[der_x_test_b1,der_y_test_b1];
der_b.der_b2 =[der_x_test_b1,der_y_test_b1];