function result = fun_c(x,y)

result =  1;