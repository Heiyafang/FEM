function result=fun_Diri(point)

x=point(1);
y=point(2);
result=x.*y.*(1-x./2).*(1-y).*exp(x+y);