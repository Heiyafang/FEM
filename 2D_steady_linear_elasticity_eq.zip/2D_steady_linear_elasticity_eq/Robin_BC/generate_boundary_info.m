function [boundaryedges,boundarynodes] = generate_boundary_info(element_type,basis_type,domain,h)
%Generate the information matrices for boundary nodes and boundary edges.
%The following boundary condition may change for different problems.

%boundary_nodes(1,k): specifiy the type of the kth boundary node.
%boundary_nodes(1,k)=-1: Dirichlet boundary node;
%boundary_nodes(1,k)=-2: Neumann boundary node;
%boundary_nodes(1,k)=-3: Robin boundary node. 
%boundary_nodes(2,k): global index of the kth boundary node among all nodes of FE. 
%                     That is, the index of FE is used here.

%boundary_edges(1,k): specifiy the type of the kth boundary edge.
%boundary_edges(1,k)=-1: Dirichlet boundary edge;
%boundary_edges(1,k)=-2: Neumann boundary edge;
%boundary_edges(1,k)=-3: Robin boundary edge. 
%boundary_edges(2,k): index of the element which contains the kth boundary edge.
%boundaryedges(3, k) is the global node index of the first end node of the kth boundary boundary edge ek.
%boundaryedges(4, k) is the global node index of the second end node of the kth boundary boundary edge ek .
%boundary_edges(3:4,k): indices of the two end points of the kth boundary edge among all grid points, not the nodes of FE.
%                       That is, the index of partition is used here.
% nbe = size(boundaryedges, 2) is the number of boundary edges;

%% -----------   Boundary type     -------- %%

    %  ---- -1: Dirichlet  -2: Neumann -3: Robin
  
    
    boundary_info=generate_boundaryedges(domain,h,element_type,basis_type);
    %Global=generate_boundaryedges(boundarytype,N1_partition,N2_partition,N1_basis,N2_basis,element_type)
    boundaryedges = boundary_info.boundaryedges;
    boundarynodes = boundary_info.boundary_nodes;




    