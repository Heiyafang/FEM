function [Gauss_weights,Gauss_nodes] = generate_Gauss_2D_BC_line(corrdinates_bc,Gauss_type)

% 1<k<nbe
Gauss_nodes = zeros(2,Gauss_type);
point_1_corrdinate_bc=corrdinates_bc(:,1);%[x1,y1]
point_2_corrdinate_bc=corrdinates_bc(:,2);%[x2,y2]

if point_1_corrdinate_bc(1) == point_2_corrdinate_bc(1) %'vertical for x, x=c', 'x1=x2=c'
    %The y−coordinates of the Gauss quadrature nodes on this boundary edge and the Gauss
    % quadrature weights can be obtained from the 1D local Gaussquadrature on [y1, y2]. 
    % And the x−coordinates of the Gaussquadrature nodes are fixed to be c.

   % fprintf('Neumann Boundary conditions: vertical, x=c ')
    Point1_y = min(point_1_corrdinate_bc(2),point_2_corrdinate_bc(2));
    Point2_y = max(point_1_corrdinate_bc(2),point_2_corrdinate_bc(2));
    vertices_y = [Point1_y,Point2_y]; % [y1,y2]
    [Gauss_weights_1D_y,Gauss_nodes_1D_y] = generate_Gauss_local_1D(vertices_y,Gauss_type);

    Gauss_weights = Gauss_weights_1D_y;
    Gauss_nodes(1,:) = point_1_corrdinate_bc(1); %fixed to be c
    Gauss_nodes(2,:) = Gauss_nodes_1D_y;  %for y
elseif point_1_corrdinate_bc(2) == point_2_corrdinate_bc(2) %'horizontal y=c','y1=y2'
    %fprintf('Neumann Boundary conditions: horizontal, y=c')
    point1_x = min(point_1_corrdinate_bc(1),point_2_corrdinate_bc(1));
    point2_x = max(point_1_corrdinate_bc(1),point_2_corrdinate_bc(1));
    vertices_x = [point1_x,point2_x];
    [Gauss_weights_1D_x,Gauss_nodes_1D_x] = generate_Gauss_local_1D(vertices_x,Gauss_type);

    Gauss_weights = Gauss_weights_1D_x;
    Gauss_nodes(1,:) = Gauss_nodes_1D_x; %for x is gauss nodes for [x1,x2]
    Gauss_nodes(2,:) = point_1_corrdinate_bc(2);  %for y is fixed to be c

else
   % fprintf('Neumann Boundary conditions: horizontal, y=ax+b')
    point1_x = min(point_1_corrdinate_bc(1),point_2_corrdinate_bc(1));
    point2_x = max(point_1_corrdinate_bc(1),point_2_corrdinate_bc(1));
    vertices_x = [point1_x,point2_x];
    [Gauss_weights_1D_x,Gauss_nodes_1D_x] = generate_Gauss_local_1D(vertices_x,Gauss_type);
    
    a_value = (point_2_corrdinate_bc(2)- point_1_corrdinate_bc(2)) / (point_2_corrdinate_bc(1)- point_1_corrdinate_bc(1));
    b_value = point_1_corrdinate_bc(2) - a_value * point_1_corrdinate_bc(1);

    %point_1_corrdinate_bc(2) = (a_value*point_2_corrdinate_bc(1)+b_value); %'y=ax+b'
    J = sqrt(1+a_value.^2);  %%% curve integration  ds -》 dx
    Gauss_weights = J.*Gauss_weights_1D_x;
    Gauss_nodes(1,:) = Gauss_nodes_1D_x; %x
    Gauss_nodes(2,:) = a_value.*Gauss_nodes_1D_x+b_value; %y

end


