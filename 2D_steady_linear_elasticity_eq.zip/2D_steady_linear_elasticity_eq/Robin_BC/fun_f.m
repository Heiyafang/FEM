function result = fun_f(point)

x= point(:,1);
y =point(:,2) ;
result=-y.*(1-y).*(1-x-x.^2/2).*exp(x+y)-x.*(1-x/2).*(-3*y-y.^2).*exp(x+y);