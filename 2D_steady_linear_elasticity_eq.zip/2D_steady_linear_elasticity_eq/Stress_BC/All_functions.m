function all_funs = All_functions

all_funs=struct('fun_f1',@fun_f1,'fun_f2',@fun_f2, ...
    'fun_Diri1',@fun_Diri1, 'fun_Diri2',@fun_Diri2,'Stress_fun1',@Stress_fun1, 'Stress_fun2',@Stress_fun2,...
    'fun_analytic1', @fun_analytic1,'fun_analytic1_der_x', ...
    @fun_analytic1_der_x,'fun_analytic1_der_y',@fun_analytic1_der_y, ...
    'fun_analytic2', @fun_analytic2,'fun_analytic2_der_x', ...
    @fun_analytic2_der_x,'fun_analytic2_der_y',@fun_analytic2_der_y,...
    'fun_lamda',@fun_lamda,'fun_miu',@fun_miu);


    function result = fun_f1(point)
        x= point(:,1);
        y =point(:,2);
        lamda = fun_lamda(point);
        miu = fun_miu(point);
        result= -(lamda + 3 *miu).*(-pi.^2.*sin(pi.*x).*sin(pi.*y)) - (lamda+miu).*((2.*x-1).*(2.*y-1));
    end
    function result = fun_f2(point)
        x= point(:,1);
        y =point(:,2);
        lamda = fun_lamda(point);
        miu = fun_miu(point);
        result= -(lamda + 2 *miu).*(2.*x.*(x-1)) - (lamda+miu).*(pi.^2 .*cos(pi.*x)*cos(pi.*y)) - miu.*(2.*y.*(y-1));
    end
    function result=fun_Diri1(point)
        x=point(1);
        y=point(2);
        result=0;
    end
    function result=fun_Diri2(point)
        x=point(1);
        y=point(2);
        result=0;
    end
    function result=Stress_fun1(point)
        x=point(1);
        y=point(2);
        result=0;
    end
    function result=Stress_fun2(point)
        x=point(1);
        y=point(2);
        result=0;
    end
    function result=fun_analytic1(point)
        x= point(:,1);
        y =point(:,2) ;
        result=sin(pi.*x).*sin(pi.*y);
    end
    function result=fun_analytic1_der_x(point)
        x= point(:,1);
        y =point(:,2) ;
       % syms x y; f= sin(pi.*x).*sin*(pi.*y)
       % diff(f,x)
        result= pi.*cos(pi.*x).*sin(pi.*y);
        
    end
    function result=fun_analytic1_der_y(point)
        x= point(:,1);
        y =point(:,2);
        % diff(f,y)
       result= pi.*cos(pi.*y).*sin(pi.*x);
  
    end
    function result=fun_analytic2(point)
        x= point(:,1);
        y =point(:,2) ;
        result=x.*(x-1).*y.*(y-1);
    end
    function result=fun_analytic2_der_x(point)
        x= point(:,1);
        y =point(:,2) ;
       % syms x y; f= x.*(x-1).*y.*(y-1)
       % diff(f,x)
        result= x.*y.*(y - 1) + y.*(x - 1).*(y - 1);
        
    end
    function result=fun_analytic2_der_y(point)
        x= point(:,1);
        y =point(:,2);
        % diff(f,y)
       result= x.*y.*(x - 1) + x.*(x - 1).*(y - 1);
  
    end
    function result = fun_lamda(point)
        result = 1;
    end
    function result = fun_miu(point)
        result = 2;
    end

end
