function [b]=treat_Stress_BC_steady_2_variable(element_type, Stress_fun1,Stress_fun2, Gauss_type, b,Nb_test,P,T, boundaryedges, Tb_test,N_lb_test,basis_type_test)
%  ---- -1: Dirichlet  -2: Neumann -3: Robin --------- %
v=sparse(2*Nb_test,1);

nbe=size(boundaryedges,2);

  for k=1:nbe
     if boundaryedges(1,k) == -2
         nk=boundaryedges(2,k);
         vertices = P(:,T(:,nk));
         corrdinates_bc=P(:,boundaryedges(3:4,k));
         [Gauss_weights,Gauss_nodes] = generate_Gauss_2D_BC_line(corrdinates_bc,Gauss_type);
           
           
           for beta = 1:N_lb_test
               int_value1=Gauss_quad_BC_line_test(element_type,Stress_fun1,Gauss_weights,Gauss_nodes,vertices,...
    basis_type_test,beta,0,0);
               v(Tb_test(beta,nk),1)=v(Tb_test(beta,nk),1)+int_value1;
               int_value2=Gauss_quad_BC_line_test(element_type,Stress_fun2,Gauss_weights,Gauss_nodes,vertices,...
    basis_type_test,beta,0,0);
               v(Nb_test+Tb_test(beta,nk),1)=v(Nb_test+Tb_test(beta,nk),1)+int_value2;

           end
           
             
      end
  end

  b = b+v;

