function int_value = Gauss_quad_BC_line_trail_test(element_type,fun_name,Gauss_weights,Gauss_nodes,vertices,...
    basis_type_trail,basis_type_test,basis_index_trail,basis_index_test,basis_der_x_trail,basis_der_y_trail,basis_der_x_test,basis_der_y_test)

Gpn = length(Gauss_nodes);
int_value = 0;
Gauss_nodes=Gauss_nodes';

for k = 1: Gpn
    int_value = int_value + Gauss_weights(k)*(feval(fun_name,Gauss_nodes(k,:))* ...
        FE_local_basis_2D(element_type,Gauss_nodes(k,1),Gauss_nodes(k,2),vertices,basis_type_test,basis_index_test,basis_der_x_test,basis_der_y_test)*...
        FE_local_basis_2D(element_type,Gauss_nodes(k,1),Gauss_nodes(k,2),vertices,basis_type_trail,basis_index_trail,basis_der_x_trail,basis_der_y_trail));
end