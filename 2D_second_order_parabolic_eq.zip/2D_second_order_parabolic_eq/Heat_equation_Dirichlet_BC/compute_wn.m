
function result = compute_wn(element_type,x,y,uh_local_vec,vertices,basis_type,basis_der_x,basis_der_y)
% wn
result = 0;
N_lb = length(uh_local_vec);
for k = 1:N_lb
    result = result + uh_local_vec(k) * FE_local_basis_2D(element_type,x,y,vertices,basis_type,k,basis_der_x,basis_der_y); 
end