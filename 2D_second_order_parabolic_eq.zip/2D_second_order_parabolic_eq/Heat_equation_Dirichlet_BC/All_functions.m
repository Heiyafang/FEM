function all_funs = All_functions

all_funs=struct('fun_c',@fun_c,'fun_f',@fun_f,'fun_Diri',@fun_Diri, ...
    'fun_analytic',@fun_analytic,'fun_analytic_der_x',@fun_analytic_der_x, ...
    'fun_analytic_der_y',@fun_analytic_der_y,'fun_Neumann',@fun_Neumann, ...
    'fun_Robin_cq',@fun_Robin_cq,'fun_Robin_cr',@fun_Robin_cr,'fun_c_M',@fun_c_M,'fun_initial',@fun_initial);


    function result = fun_initial(point)
         x= point(:,1);
         y =point(:,2) ;
        result = exp(x+y);

    end
    function result = fun_c(point,t)
        x= point(:,1);
        y =point(:,2) ;
        result =  2;
    end
    function result = fun_c_M(point)
            result = 1;
    end
    function result = fun_f(point,t)
        x= point(:,1);
        y =point(:,2) ;
        result= -3*exp(x+y+t);
    end
    function result=fun_Diri(point,t)
        x=point(1);
        y=point(2);
        if x == 0
            result = exp(y+t);
        elseif x == 2
            result = exp(2+y+t);
        elseif y == 0
            result = exp(x+t);
        elseif y == 1
            result = exp(x+1+t);
        end
        %result=exp(x+y+t);
    end
    function result=fun_analytic(point,t)
        x= point(:,1);
        y =point(:,2);
        result = exp(x+y+t);
    end
    function result=fun_analytic_der_x(point,t)
        x= point(:,1);
        y =point(:,2);
        result=exp(x+y+t);
        
    end
    function result=fun_analytic_der_y(point,t)
        x= point(:,1);
        y =point(:,2);
       result= exp(x+y+t);
    end
    function result = fun_Neumann(point) % Neumann_fun = c * p
        x= point(:,1);
        y =point(:,2);
        c = 1;
        p = -exp(x+y);
        result = c.* p;
    end
    function result = fun_Robin_cq(point)
        x= point(:,1);
        y =point(:,2);
        c = 1;
        q = 0;
        result = c.*q;
    end
    function result = fun_Robin_cr(point)
        x= point(:,1);
        y =point(:,2);
        c = 1;
        r = 1;
        result = c.*r;
    end

end
