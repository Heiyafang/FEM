function Global=generate_2D_PbTb(domain, h, basis_type,element_type)

left = domain(1,1);
right = domain(1,2);
bottom = domain(2,1);
top = domain(2,2);
h1 = h(1);
h2 = h(2);
N1 = (domain(1,2) - domain(1,1))/h1;
N2 = (domain(2,2) - domain(2,1))/h2;

if strcmpi(element_type,'Triangular')
    if basis_type == 201
         temp = generate_2D_PT(domain, h,element_type);
         Global.Pb = temp.P;
         Global.Tb = temp.T;

    elseif basis_type == 202  
          k = 0;
        for i = 1: N1
             for j = 1:N2
         %t1 = (2*i-2)*(N2+1) +(2*j-1);
                c= 2 *i -1;
                r = 2*j -1;
                k=k+1;
                t1 = (c-1) * (2*N2+1) + r;
                t2 = (c-1) * (2* N2+1) +r+1;
                t3 =(c-1) * (2* N2+1) +r+2;
                t4 = c *(2 * N2+1) + r;
                t5 = c *(2 * N2+1) + r+1;
                t6 = c *(2 * N2+1) + r+2;
                t7 = (c+1) * (2 * N2 +1)+r;
                t8 = (c+1) * (2 * N2 +1)+r+1;
                t9 = (c+1) * (2 * N2 +1)+r+2;
                Temp_Tb(:,k) = [t1 t2 t3 t4 t5 t6 t7 t8 t9];
            end
        end
        for n = 1:(N1*N2)
             Tb(:,2*n-1) = [Temp_Tb(1,n); Temp_Tb(7,n); Temp_Tb(3,n);Temp_Tb(4,n); Temp_Tb(5,n); Temp_Tb(2,n)];
             Tb(:,2*n) = [Temp_Tb(3,n); Temp_Tb(7,n); Temp_Tb(9,n);Temp_Tb(5,n); Temp_Tb(8,n); Temp_Tb(6,n)];
        end
         x_node = left:(h1/2):right;
         y_node = bottom:(h2/2):top;
        k = 0; 
        for r = 1:(2*N1+1)  
            for c = 1:(2*N2+1)
                k = k+1;
                Pb(:,k) = [x_node(r);y_node(c)];
            end
        end
        Global.Pb = Pb;
        Global.Tb = Tb;
    else
         waring = 'wrong basis_type'
    end
elseif strcmpi(element_type,'Rectangular')
        if basis_type == 201
            temp = generate_2D_PT(domain, h,element_type);
            Global.Pb = temp.P;
            Global.Tb = temp.T;
        elseif basis_type == 202
                k = 0;
            for i = 1: N1
                for j = 1:N2
         %t1 = (2*i-2)*(N2+1) +(2*j-1);
                    c= 2 *i -1;
                    r = 2*j -1;
                    k=k+1;
                    t1 = (c-1) * (2*N2+1) + r;
                    t2 = (c-1) * (2* N2+1) +r+1;
                    t3 =(c-1) * (2* N2+1) +r+2;
                    t4 = c *(2 * N2+1) + r;
                    t5 = c *(2 * N2+1) + r+1;
                    t6 = c *(2 * N2+1) + r+2;
                    t7 = (c+1) * (2 * N2 +1)+r;
                    t8 = (c+1) * (2 * N2 +1)+r+1;
                    t9 = (c+1) * (2 * N2 +1)+r+2;
                    Temp_Tb(:,k) = [t1 t2 t3 t4 t5 t6 t7 t8 t9];
                end
            end
            for n = 1:(N1*N2)
                Tb(:,n) = [Temp_Tb(1,n); Temp_Tb(7,n); Temp_Tb(9,n);Temp_Tb(3,n); 
                    Temp_Tb(4,n); Temp_Tb(8,n);Temp_Tb(6,n); Temp_Tb(2,n); Temp_Tb(5,n)];
            end
            x_node = left:(h1/2):right;
            y_node = bottom:(h2/2):top;
            k = 0; 
            for r = 1:(2*N1+1)  
                for c = 1:(2*N2+1)
                    k = k+1;
                    Pb(:,k) = [x_node(r);y_node(c)];
                end
            end
            Global.Pb = Pb;
            Global.Tb = Tb;

        else
            disp("wrong basis type")
        end

end