function [A,b]=treat_Robin_boundary(element_type, Robin_fun_cq,Robin_fun_cr, Gauss_type, A,b,Nb_test,Nb_trail,P,T, boundaryedges, ...
    Tb_test,N_lb_test,N_lb_trial,basis_type_test,basis_type_trial,basis_der_x_Robin_w,basis_der_y_Robin_w,basis_der_x_R_trail,basis_der_y_R_trail,basis_der_x_R_test,basis_der_y_R_test)
%  ---- -1: Dirichlet  -2: Neumann -3: Robin --------- %
w=zeros(Nb_test,1);
nbe=size(boundaryedges,2);
R = sparse(Nb_test, Nb_trail);

  for k=1:nbe
     if boundaryedges(1,k) == -3
         nk=boundaryedges(2,k);
         vertices = P(:,T(:,nk));
         corrdinates_bc=P(:,boundaryedges(3:4,k));
         [Gauss_weights,Gauss_nodes] = generate_Gauss_2D_BC_line(corrdinates_bc,Gauss_type);
                 
           for beta = 1:N_lb_test
               int_value1=Gauss_quad_BC_line_test(element_type,Robin_fun_cq,Gauss_weights,Gauss_nodes,vertices,...
    basis_type_test,beta,basis_der_x_Robin_w,basis_der_y_Robin_w);
               w(Tb_test(beta,nk),1)=w(Tb_test(beta,nk),1)+int_value1;
           end
           for alpha = 1:N_lb_trial
               for beta = 1:N_lb_test
                    int_value2 = Gauss_quad_BC_line_trail_test(element_type,Robin_fun_cr,Gauss_weights,Gauss_nodes,vertices,...
    basis_type_trial,basis_type_test,alpha,beta,basis_der_x_R_trail,basis_der_y_R_trail,basis_der_x_R_test,basis_der_y_R_test);
                    R(Tb_trail(beta,nk),Tb_trail(alpha,nk)) = R(Tb_trail(beta,nk),Tb_trail(alpha,nk))+int_value2;
               end
           end
           
      end
  end
  b = b + w;
  A = A + R;