function [b]=treat_Neumann_boundary(element_type, Neumann_fun, Gauss_type, b,Nb_test,P,T, boundaryedges, Tb_test,N_lb_test,basis_type_test)
%  ---- -1: Dirichlet  -2: Neumann -3: Robin --------- %
v=sparse(Nb_test,1);
nbe=size(boundaryedges,2);

  for k=1:nbe
     if boundaryedges(1,k) == -2
         nk=boundaryedges(2,k);
         vertices = P(:,T(:,nk));
         corrdinates_bc=P(:,boundaryedges(3:4,k));
         [Gauss_weights,Gauss_nodes] = generate_Gauss_2D_BC_line(corrdinates_bc,Gauss_type);
           
           
           for beta = 1:N_lb_test
               int_value=Gauss_quad_BC_line_test(element_type,Neumann_fun,Gauss_weights,Gauss_nodes,vertices,...
    basis_type_test,beta,0,0);
               v(Tb_test(beta,nk),1)=v(Tb_test(beta,nk),1)+int_value;

           end
           
           %b(i)=feval(Neumann_fun, Pb_test(:,i));    
      end
  end

  b = b+v;

