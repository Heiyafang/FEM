function b= assmble_vector_2D_time(element_type,fun_f,t,Gauss_type,matrix_size,N,P,T,Tb_test, ...
                                N_lb_test,basis_type_test,basis_der_x_test,basis_der_y_test)

b = zeros(matrix_size(1),1);
for n = 1:N
    vertices = P(:,T(:,n)); % coordinates of nth mesh elements
    [Gauss_weights,Gauss_nodes] = generate_Gauss_local_2D(element_type,vertices,Gauss_type);
    for beta = 1:N_lb_test
        r = Gauss_quad_2D_test_time(element_type,fun_f,t,Gauss_weights,Gauss_nodes,vertices,...
            basis_type_test,beta,basis_der_x_test,basis_der_y_test);
        
        b(Tb_test(beta,n),1) = b(Tb_test(beta,n),1) + r;
        % d(beta,1) = Gauss_quad_1D_test(fun_f,Gauss_weights,Gauss_nodes,vertices,basis_type_test,basis_index_test,basis_der_x_test);
    end
    %b(Tb(:,n),1) = b(Tb(:,n),1) + d;
end