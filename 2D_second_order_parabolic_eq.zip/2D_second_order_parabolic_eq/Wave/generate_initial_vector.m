function [result1,result2] = generate_initial_vector(fun_initial,Pb_trail)


result1 = feval(fun_initial,Pb_trail');
result2 = feval(fun_initial,Pb_trail');
