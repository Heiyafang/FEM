function [A,b]=treat_Dirichlet_boundary_time( Diri_fun,t, A, b, boundarynodes, Pb_test)
%  ---- -1: Dirichlet  -2: Neumann -3: Robin --------- %
nbn=size(boundarynodes,2);
  for k=1:nbn
     if boundarynodes(1,k) == -1
           i=boundarynodes(2,k);
           A(i,:)=0;
           A(i,i)=1;
           b(i,1)=feval(Diri_fun, Pb_test(:,i),t);    
      end
  end

