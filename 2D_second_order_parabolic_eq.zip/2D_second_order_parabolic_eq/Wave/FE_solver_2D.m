function [err] = FE_solver_2D(element_type,start_t,end_t,dt,theta,domain,h,basis_type,basis_type_trial, ...
                                         basis_type_test,basis_type_error,Gauss_type)
format shorte
%% ----------------------------------------
% basis_type = 201 : 2D linear
% basis_type = 202 : 2D Qudratic
%%-----------------------------------------

N1 = (domain(1,2) - domain(1,1))/h(1);
N2 = (domain(2,2) - domain(2,1))/h(2);
%% ------------------Obtain P, T, Pb, Tb,N_lb ---------------------
PT =  generate_2D_PT(domain, h, element_type); % (domain, h,element_type)
P = PT.P;
T = PT.T;
Global.T = T;
Global.P = P;
clear PT

PbTb_Trail = generate_2D_PbTb(domain, h, basis_type_trial,element_type);
Pb_trail = PbTb_Trail.Pb;
Tb_trail = PbTb_Trail.Tb;
N_lb_trial =size(Tb_trail,1);
PbTb_Test = generate_2D_PbTb(domain, h, basis_type_test,element_type);
Pb_test = PbTb_Test.Pb;
Tb_test = PbTb_Test.Tb;
N_lb_test =size(Tb_test,1);

Basis.Pb_trail = Pb_trail;
Basis.Pb_test = Pb_test;
Basis.Tb_trail = Tb_trail;
Basis.Tb_test = Tb_test;
Basis.N_lb_trial = N_lb_trial;
Basis.N_lb_test = N_lb_test;
clear PbTb_Trail PbTb_Test

N = size(T,2); 
Nb_trail = size(Pb_trail,2);
Nb_test =size(Pb_test,2);


matrix_size=[Nb_test, Nb_trail];

%% ------------------Obtain all functions ---------------------
all_funs = All_functions;

%% ------------------Obtain A stiff matrix ---------------------
der_x_trail = 1;
der_y_trail = 0;
der_x_test = 1;
der_y_test = 0;
A1 = assemble_matrix_2D(element_type,all_funs.fun_c,Gauss_type,matrix_size,N,P,T,Tb_trail,Tb_test, ...
                                N_lb_trial,N_lb_test, ...
                                basis_type_trial,der_x_trail,der_y_trail,...
                                basis_type_test,der_x_test,der_y_test);
der_x_trail = 0;
der_y_trail = 1;
der_x_test = 0;
der_y_test = 1;
A2 = assemble_matrix_2D(element_type,all_funs.fun_c,Gauss_type,matrix_size,N,P,T,Tb_trail,Tb_test, ...
                                N_lb_trial,N_lb_test, ...
                                basis_type_trial,der_x_trail,der_y_trail,...
                                basis_type_test,der_x_test,der_y_test);
A =A1+A2;
clear der_x_trail  der_y_trail der_x_test  der_y_test 

%% -----------------Obtain M matrix-------------------
der_x_trail = 0;
der_y_trail = 0;
der_x_test = 0;
der_y_test = 0;
M = assemble_matrix_2D(element_type,all_funs.fun_c_M,Gauss_type,matrix_size,N,P,T,Tb_trail,Tb_test, ...
                                N_lb_trial,N_lb_test, ...
                                basis_type_trial,der_x_trail,der_y_trail,...
                                basis_type_test,der_x_test,der_y_test);

[X_old,X_older] = generate_initial_vector(all_funs.fun_initial,Pb_trail); % X_old : Xm; X_older: X(m-1).

%A = sparse (matrix_size(1), matrix_size(2));
%A_tlide\b_tlide

number_of_time_step=(end_t-start_t)/dt;

A_tlide= M./(dt^2) +A /4;
temp1_b = 2*M./(dt^2) - A/2;
temp2_b = M./(dt^2) + A/4;

for m = 1:number_of_time_step-1
    % X_old: Xm;
    tm = start_t + m*dt;
  %% ------------------Obtain b load vector ---------------------

    der_x_test = 0;
    der_y_test = 0;
    b_tm = assmble_vector_2D_time(element_type,all_funs.fun_f,tm,Gauss_type,matrix_size,N,P,T,Tb_test, ...
                                N_lb_test,basis_type_test,der_x_test,der_y_test);

  

    b_tlide=  b_tm +temp1_b*X_old - temp2_b * X_older;
    %% ------------------ Handle Boundary conditions ---------------------

    [boundaryedges,boundarynodes] = generate_boundary_info(element_type,basis_type,N1,N2);

    [A_tlide,b_tlide] = treat_Dirichlet_boundary_time(all_funs.fun_Diri,tmp1, A_tlide, b_tlide, boundarynodes, Basis.Pb_test);
    %% ------------------ Get Solution --------------
    solution = A_tlide\b_tlide;
    X_older = X_old;
    X_old = solution;


end



% Global.boundarynodes = boundarynodes;
% Global.A = A;
% Global.b = b;
% 
% 
% Global.solution = solution;

%% --------------------- compute  error--------------------------%%

%PbTb_error = generate_2D_PbTb(domain, h, basis_type_trial,element_type);
t = start_t:dt:end_t;
Tb_error = Tb_trail;
L2_inf_err_time = compute_L2_inf_err_time(element_type,all_funs.fun_analytic,solution,P,T,Tb_error,basis_type_error,0,0,Gauss_type,t);

L2_err_time = compute_L2_err_time(all_funs.fun_analytic,solution,element_type,P,T,Tb_error,Gauss_type,basis_type_error,t);

H1_semi_err_time = compute_H1_err_time(all_funs.fun_analytic_der_x,all_funs.fun_analytic_der_y,solution,element_type,P,T,Tb_error,Gauss_type,...
    basis_type_error,t);
for i = 1:length(t)
    if t(i) == 1

       L2_inf_err = L2_inf_err_time(i);
       L2_err = L2_err_time(i);
       H1_semi_err = H1_semi_err_time(i);

    end
end

err.L2_inf_err = L2_inf_err;
err.L2_err = L2_err;
err.H1_semi_err = H1_semi_err;