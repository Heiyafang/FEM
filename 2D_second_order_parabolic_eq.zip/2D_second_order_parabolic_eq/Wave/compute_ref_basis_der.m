clear
clc
syms x_hat y_hat
result = 1 - x_hat.^2 - y_hat.^2 + (x_hat.^2).*(y_hat.^2);
dff1_x = diff(result, x_hat)
dff1_y = diff(result, y_hat)
dff2_x=diff(dff1_x,x_hat)
dff2_y=diff(dff1_y,y_hat)
dff2_xy=diff(dff1_x,y_hat)