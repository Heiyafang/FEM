function A = assemble_matrix_2D(element_type,coe_fun,Gauss_type,matrix_size,N,P,T,Tb_trail,Tb_test, ...
                                N_lb_trial,N_lb_test, ...
                                basis_type_trial,basis_der_x_trail,basis_der_y_trail,...
                                basis_type_test,basis_der_x_test,basis_der_y_test)
%----------------------------
% matrix_size(1) = Nb_test; matrix_size(2) = Nb_trail
% N: number of elements
% N_lb_trial : number of local basis trail function
% N_lb_test : number of local basis test function
% quad: quadrature
%---------------------------------
A = sparse (matrix_size(1), matrix_size(2));
%[Gauss_coefficient_reference_triangle,Gauss_point_reference_triangle]=generate_Gauss_reference_triangle(Gauss_type);
for n=1:N
    vertices = P(:,T(:,n)); % coordinates of nth mesh elements
    %[Gauss_weights,Gauss_nodes]=generate_Gauss_local_triangle(Gauss_coefficient_reference_triangle,Gauss_point_reference_triangle,vertices);
    [Gauss_weights,Gauss_nodes] = generate_Gauss_local_2D(element_type,vertices,Gauss_type);
    for alpha = 1:N_lb_trial
        for beta = 1: N_lb_test
            int_value = Gauss_quad_2D_trail_test(element_type,coe_fun,Gauss_weights,...
                Gauss_nodes,vertices,basis_type_trial,alpha,basis_der_x_trail,basis_der_y_trail,...
                basis_type_test,beta,basis_der_x_test,basis_der_y_test);
            A(Tb_test(beta,n),Tb_trail(alpha,n)) =  A(Tb_test(beta,n),Tb_trail(alpha,n)) + int_value;
        end
    end
    %A(Tb_test(:,n),Tb_trail(:,n)) = A(Tb_test(:,n),Tb_trail(:,n))+S
end
