function r = compute_int_error_time(der_fun_u,solution,element_type,P,T,Tb_error,Gauss_type,...
    basis_type_error,basis_der_x_error,basis_der_y_error,t)

r=0;
N_lb =size(Tb_error,1);
N = size(T,2);
for n = 1:N

    vertices = P(:,T(:,n)); % coordinates of nth mesh elements
    uh_local_vec = solution(Tb_error(:,n)); %
    [Gauss_weights,Gauss_nodes] = generate_Gauss_local_2D(element_type,vertices,Gauss_type);
    r =  r + Gauss_quad_2D_error_time(der_fun_u,element_type,uh_local_vec,N_lb,Gauss_weights,Gauss_nodes,vertices,...
    basis_type_error,basis_der_x_error,basis_der_y_error,t);

end

