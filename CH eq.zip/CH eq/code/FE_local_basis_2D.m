function result = FE_local_basis_2D(element_type,x,y,vertices,basis_type,basis_index,der_x,der_y)

if strcmpi(element_type,'Triangular')
    x1 = vertices(1,1);
    x2 = vertices(1,2);
    x3 = vertices(1,3);
    y1 = vertices(2,1);
    y2 = vertices(2,2);
    y3 = vertices(2,3);
    %% affine mapping
    a = x2-x1;
    b = x3-x1;
    c = y2-y1;
    d = y3-y1;
    e = x1;
    f = y1;
    xh = 1/(a*d-b*c)*(d*(x-e) - b*(y-f));
    yh = 1/(a*d-b*c)*(-c*(x-e)+a*(y-f));
    x_hat_der_x = 1/(a*d-b*c)*d;
    x_hat_der_y = 1/(a*d-b*c)*(-b);
    y_hat_der_x = 1/(a*d-b*c)*(-c);
    y_hat_der_y = 1/(a*d-b*c)*a;

    % p43
%     J = (x2-x1)*(y3-y1)-(x3-x1)*(y2-y1);% |J| =(x2 −x1)(y3 −y1)−(x3 −x1)(y2 −y1),
%     xh=((y3-y1)*(x-x1)-(x3-x1)*(y-y1))/J;
%     yh=(-(y2-y1)*(x-x1)+(x2-x1)*(y-y1))/J;
%     x_hat_der_x = (y3-y1)/(J);
%     x_hat_der_y = (x1-x3)/(J);
%     y_hat_der_x = (y1-y2)/(J);
%     y_hat_der_y = (x2-x1)/(J);

elseif strcmpi(element_type,'Rectangular') 
    x1 = vertices(1,1);
    x2 = vertices(1,2);
    x3 = vertices(1,3);
    x4 = vertices(1,4);
    y1 = vertices(2,1);
    y2 = vertices(2,2);
    y3 = vertices(2,3);
    y4 = vertices(2,4);
    %% affine mapping
    a = (x2-x1)/2;
    b = (x3-x2)/2;
    c = (y2-y1)/2;
    d = (y3-y2)/2;
    e = (x1+x3)/2;
    f = (y1+y3)/2;
    xh = (d*(x-e) - b*(y-f)) /(a*d-b*c);
    yh = (-c*(x-e)+a*(y-f))/(a*d-b*c) ;

    x_hat_der_x = d/(a*d-b*c);
    x_hat_der_y = (-b)/(a*d-b*c);
    y_hat_der_x = (-c)/(a*d-b*c);
    y_hat_der_y = a/(a*d-b*c);
    
%     h1=x2-x1;
%     h2=y4-y1;
%     xh=(2*x-2*x1-h1)/h1;
%     yh=(2*y-2*y1-h2)/h2;
%     
%     x_hat_der_x = 2/h1;
%     x_hat_der_y = 0;
%     y_hat_der_x = 0;
%     y_hat_der_y = 2/h2;
%     if der_x == 0 && der_y == 0
%         result = FE_reference_basis_2D(element_type,xh,yh,basis_type,basis_index,0,0);
%     elseif der_x == 1 && der_y == 0
%         result = x_hat_der_x*FE_reference_basis_2D(element_type,xh,yh,basis_type,basis_index,1,0) +...
%             y_hat_der_x*FE_reference_basis_2D(element_type,xh,yh,basis_type,basis_index,0,1);
%     elseif der_x == 0 && der_y == 1
%         result = x_hat_der_y*FE_reference_basis_2D(element_type,xh,yh,basis_type,basis_index,1,0) +...
%             y_hat_der_y*FE_reference_basis_2D(element_type,xh,yh,basis_type,basis_index,0,1);
%     elseif der_x == 2 && der_y == 0
%         result = x_hat_der_x*x_hat_der_x*FE_reference_basis_2D(element_type,xh,yh,basis_type,basis_index,2,0) +...
%             2*y_hat_der_x*x_hat_der_x*FE_reference_basis_2D(element_type,xh,yh,basis_type,basis_index,1,1)+...
%             y_hat_der_x*y_hat_der_x*FE_reference_basis_2D(element_type,xh,yh,basis_type,basis_index,0,2);
%     elseif der_x == 0 && der_y == 2
%         result = x_hat_der_y*x_hat_der_y*FE_reference_basis_2D(element_type,xh,yh,basis_type,basis_index,2,0) +...
%             2*y_hat_der_y*x_hat_der_y*FE_reference_basis_2D(element_type,xh,yh,basis_type,basis_index,1,1)+...
%             y_hat_der_y*y_hat_der_y*FE_reference_basis_2D(element_type,xh,yh,basis_type,basis_index,0,2);
%     elseif der_x == 1 && der_y == 1
%         result = x_hat_der_y*x_hat_der_x*FE_reference_basis_2D(element_type,xh,yh,basis_type,basis_index,2,0) +...
%             y_hat_der_y*x_hat_der_x*FE_reference_basis_2D(element_type,xh,yh,basis_type,basis_index,1,1) +...
%             x_hat_der_y*y_hat_der_x*FE_reference_basis_2D(element_type,xh,yh,basis_type,basis_index,1,1) +...
%             y_hat_der_y*y_hat_der_x*FE_reference_basis_2D(element_type,xh,yh,basis_type,basis_index,2,0);
%     end

end


if der_x == 0 && der_y == 0
        result = FE_reference_basis_2D(element_type,xh,yh,basis_type,basis_index,0,0);
elseif der_x == 1 && der_y == 0
        result = x_hat_der_x*FE_reference_basis_2D(element_type,xh,yh,basis_type,basis_index,1,0) +...
            y_hat_der_x*FE_reference_basis_2D(element_type,xh,yh,basis_type,basis_index,0,1);
elseif der_x == 0 && der_y == 1
        result = x_hat_der_y*FE_reference_basis_2D(element_type,xh,yh,basis_type,basis_index,1,0) +...
            y_hat_der_y*FE_reference_basis_2D(element_type,xh,yh,basis_type,basis_index,0,1);
elseif der_x == 2 && der_y == 0
        result = x_hat_der_x*x_hat_der_x*FE_reference_basis_2D(element_type,xh,yh,basis_type,basis_index,2,0) +...
            2*y_hat_der_x*x_hat_der_x*FE_reference_basis_2D(element_type,xh,yh,basis_type,basis_index,1,1)+...
            y_hat_der_x*y_hat_der_x*FE_reference_basis_2D(element_type,xh,yh,basis_type,basis_index,0,2);
elseif der_x == 0 && der_y == 2
        result = x_hat_der_y*x_hat_der_y*FE_reference_basis_2D(element_type,xh,yh,basis_type,basis_index,2,0) +...
            2*y_hat_der_y*x_hat_der_y*FE_reference_basis_2D(element_type,xh,yh,basis_type,basis_index,1,1)+...
            y_hat_der_y*y_hat_der_y*FE_reference_basis_2D(element_type,xh,yh,basis_type,basis_index,0,2);
 elseif der_x == 1 && der_y == 1
        result = x_hat_der_y*x_hat_der_x*FE_reference_basis_2D(element_type,xh,yh,basis_type,basis_index,2,0) +...
            y_hat_der_y*x_hat_der_x*FE_reference_basis_2D(element_type,xh,yh,basis_type,basis_index,1,1) +...
            x_hat_der_y*y_hat_der_x*FE_reference_basis_2D(element_type,xh,yh,basis_type,basis_index,1,1) +...
            y_hat_der_y*y_hat_der_x*FE_reference_basis_2D(element_type,xh,yh,basis_type,basis_index,2,0);
 end
