function [der_A,der_b]=get_all_der_A_b

% der_x_trail_A  %r
% der_y_trail_A  %s
% der_x_test_A  %p
% der_y_test_A  %q



% r s p q, / der_x_trail,der_y_trail;der_x_test,der_y_test;
%%  Pre der info for A matrix and b vector
% A11
der_x_trail_A1  = 1; %r
der_y_trail_A1 = 0; %s
der_x_test_A1 = 1;  %p
der_y_test_A1 = 0;  %q

%A12
der_x_trail_A2 = 0; %r
der_y_trail_A2 = 1; %s
der_x_test_A2 = 0; %p
der_y_test_A2 = 1; %q

% M
der_x_trail_M = 0;
der_y_trail_M = 0;
der_x_test_M = 0;
der_y_test_M = 0;


% der for all matrix
der_A.der_A11 =  [der_x_trail_A1,der_y_trail_A1;der_x_test_A1,der_y_test_A1];
der_A.der_A12 =  [der_x_trail_A2,der_y_trail_A2;der_x_test_A2,der_y_test_A2];

der_A.der_A21 =der_A.der_A11;
der_A.der_A22=der_A.der_A12;

der_A.der_M = [der_x_trail_M,der_y_trail_M;der_x_test_M,der_y_test_M];

% b1
% der_x_test_b  %p
% der_y_test_b    %q
der_x_test_b1 = 0;
der_y_test_b1 = 0;
der_b.der_b1 =[der_x_test_b1,der_y_test_b1];
der_b.der_b2 =der_b.der_b1;