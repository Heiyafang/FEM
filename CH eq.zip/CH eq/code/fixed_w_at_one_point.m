function [A,b] = fixed_w_at_one_point(Diri_fun,A,b,Nb,Pb_test,t)

i=1;
A(Nb+i,:)=0;
A(Nb+i,2*Nb+i)=1;

b(Nb+i)=feval(Diri_fun,  Pb_test(:,i),t);  