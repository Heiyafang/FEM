%main
clear
clc
tic
%%   ------  Domain and mesh information  -----   %%
left = 0;
right = 1;
bottom = 0;
top = 1;
domain = [left, right; bottom, top];
start_t = 0;
end_t = 1;

% Finite difference method
% theta = 1 is Backward Euler scheme, theta = 0 is Forward Euler scheme, theta = 1/2 is Crank_Nicolson(Trapezoidal) scheme
theta = 1/2; 
clear left right top bottom

element_type = 'Triangular';% 'Triangular' or 'Rectangular'
basis_type = 202;
basis_type_trial = 202;
basis_type_test = 202;
Gauss_type = 9;
disp('Dirichlet  boundary condition, linear basis funciton, Triangular element and 9 Gauss points ')

h1=[1/4,1/8,1/16,1/32]';
h2=[1/4,1/8,1/16,1/32]';
dt = [1/8,1/64,1/512,1/4096]';
for i = 1:length(h1)
   
    h{i}=[h1(i) h2(i)];
   
%% plot basis function 
    getPbTb=generate_2D_PbTb(domain, h{i}, basis_type,element_type);% # tri and rec
    user_plot = 'false'; % false or true
    plot_basis_function(user_plot,basis_type,element_type,getPbTb.Tb);
    clear getPbTb

%% Solver 
    [err(i)] = FE_solver_2D_CH_equation(element_type,start_t,end_t,dt(i),theta,domain,h{i},basis_type,basis_type_trial, ...
                                         basis_type_test,Gauss_type);
    %solution1=solution
end
toc
%%  Compute error and Convergence
b=struct2cell(err);

% For u
L_inf_error_u=cell2mat(b(1,:))';
Convergence_L_inf_u = log(L_inf_error_u(1:end-1) ./ L_inf_error_u(2:end)) ./ log(h1(1:end-1) ./ h1(2:end));
Convergence_L_inf_u = [0;Convergence_L_inf_u];

L2_norm_error_u=cell2mat(b(2,:))';
Convergence_L2_u = log(L2_norm_error_u(1:end-1) ./ L2_norm_error_u(2:end)) ./ log(h1(1:end-1) ./ h1(2:end));
Convergence_L2_u = [0;Convergence_L2_u];

H1_semi_error_u=cell2mat(b(3,:))';
Convergence_H1_semi_u = log(H1_semi_error_u(1:end-1) ./ H1_semi_error_u(2:end)) ./ log(h1(1:end-1) ./ h1(2:end));
Convergence_H1_semi_u = [0;Convergence_H1_semi_u];

% For w
L_inf_error_w=cell2mat(b(4,:))';
Convergence_L_inf_w = log(L_inf_error_w(1:end-1) ./ L_inf_error_w(2:end)) ./ log(h1(1:end-1) ./ h1(2:end));
Convergence_L_inf_w = [0;Convergence_L_inf_w];

L2_norm_error_w=cell2mat(b(5,:))';
Convergence_L2_w = log(L2_norm_error_w(1:end-1) ./ L2_norm_error_w(2:end)) ./ log(h1(1:end-1) ./ h1(2:end));
Convergence_L2_w = [0;Convergence_L2_w];

H1_semi_error_w=cell2mat(b(6,:))';
Convergence_H1_semi_w = log(H1_semi_error_w(1:end-1) ./ H1_semi_error_w(2:end)) ./ log(h1(1:end-1) ./ h1(2:end));
Convergence_H1_semi_w = [0;Convergence_H1_semi_w];

%%  Show error and Convergence
T_u = table(h1,h2,dt,L_inf_error_u, Convergence_L_inf_u,   L2_norm_error_u, Convergence_L2_u,  H1_semi_error_u,Convergence_H1_semi_u);
T_w = table(h1,h2,dt,L_inf_error_w, Convergence_L_inf_w,   L2_norm_error_w, Convergence_L2_w,  H1_semi_error_w,Convergence_H1_semi_w);


%%  Store error and Convergence
%Open the file in append mode
fileID = fopen('Result_CH_CN2.txt', 'w'); 

% Append a separator line or any other information you want
headerText = '---------- Dirichlet boundary condition, linear basis funciton, Triangular element--------.\n';
fprintf(fileID, headerText);

headerText = '--------------------------------------------------------------------------------------------.\n';
fprintf(fileID, headerText);

% Append a separator line or any other information you want
headerText = '-----------This is the result for u-----------------------------------\n';
fprintf(fileID, headerText);
% Append the table data
fprintf(fileID, ' h1 \t  h2 \t L_inf_error_u\t Convergence_L_inf_u\t L2_norm_error_u\t Convergence_L2_u\t H1_semi_error_u\t Convergence_H1_semi_u\t \n');
for i = 1:height(T_u)
    fprintf(fileID, '%.4f\t%.4f\t %.4f\t %.4e\t %.4e\t%.4e\t%.4e\t%.4e\t %.4e\n', T_u.h1(i), T_u.h2(i), T_u.dt(i),T_u.L_inf_error_u(i),T_u.Convergence_L_inf_u(i), T_u.L2_norm_error_u(i),T_u.Convergence_L2_u(i), T_u.H1_semi_error_u(i),T_u.Convergence_H1_semi_u(i));
end

headerText = '--------------------------------------------------------------------------------------------.\n';
fprintf(fileID, headerText);
% Append a separator line or any other information you want
headerText = '-----------This is the result for p-----------------------------------\n';
fprintf(fileID, headerText);

% Append the table data
fprintf(fileID, ' h1 \t  h2 \t L_inf_error_p\t Convergence_L_inf_p\t L2_norm_error_p\t Convergence_L2_p\t H1_semi_error_p\t Convergence_H1_semi_p\t \n');
for i = 1:height(T_u)
    fprintf(fileID, '%.4f\t%.4f\t %.4f\t %.4e\t %.4e\t%.4e\t%.4e\t%.4e\t %.4e\n', T_w.h1(1), T_w.h2(i),T_w.dt(i), T_w.L_inf_error_w(i),T_w.Convergence_L_inf_w(i), T_w.L2_norm_error_w(i),T_w.Convergence_L2_w(i), T_w.H1_semi_error_w(i),T_w.Convergence_H1_semi_w(i));
end

%Close the file
fclose(fileID);
disp("The result for u")
disp(T_u)
disp("The result for w")
disp(T_w)

