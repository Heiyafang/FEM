function result = generate_initial_vector(fun_initial,Pb_trail)


result = feval(fun_initial,Pb_trail');

