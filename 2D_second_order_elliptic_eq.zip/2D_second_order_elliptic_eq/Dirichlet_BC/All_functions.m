function all_funs = All_functions

all_funs=struct('fun_c',@fun_c,'fun_f',@fun_f,'fun_Diri',@fun_Diri,'fun_analytic',@fun_analytic,'fun_analytic_der_x',@fun_analytic_der_x,'fun_analytic_der_y',@fun_analytic_der_y);


    function result = fun_c(point)
        x= point(:,1);
        y =point(:,2) ;
        result =  1;
    end
    function result = fun_f(point)
        x= point(:,1);
        y =point(:,2) ;
        result=-y.*(1-y).*(1-x-x.^2./2).*exp(x+y)-x.*(1-x./2).*(-3.*y-y.^2).*exp(x+y);
    end
    function result=fun_Diri(point)
        x=point(1);
        y=point(2);
        result=x.*y.*(1-x./2).*(1-y).*exp(x+y);
    end
    function result=fun_analytic(point)
        x= point(:,1);
        y =point(:,2) ;
        result=x.*y.*(1-x./2).*(1-y).*exp(x+y);
    end
    function result=fun_analytic_der_x(point)
        x= point(:,1);
        y =point(:,2) ;
       % f= x.*y.*(1-x./2).*(1-y).*exp(x+y)
       % diff(f,x)
        result=y.*exp(x + y).*(x/2 - 1).*(y - 1) + (x.*y.*exp(x + y).*(y - 1))./2 + x.*y.*exp(x + y).*(x./2 - 1).*(y - 1);
        
    end
    function result=fun_analytic_der_y(point)
        x= point(:,1);
        y =point(:,2) ;
        % f= x.*y.*(1-x./2).*(1-y).*exp(x+y)
        % diff(f,y)
       result=x.*y.*exp(x + y).*(x./2 - 1) + x.*exp(x + y).*(x./2 - 1).*(y - 1) + x.*y.*exp(x + y).*(x./2 - 1).*(y - 1);
  
    end

end
