function err = compute_max_absolute_err(element_type,analytic_fun,solution,P,T,Tb_error,Gauss_type,basis_type_error,basis_der_x,basis_der_y)


N = size(T,2); 
for n = 1:N
    vertices = P(:,T(:,n)); 
    [Gauss_weights,Gauss_nodes] = generate_Gauss_local_2D(element_type,vertices,Gauss_type);
    point = Gauss_nodes;
    N_lb_error = size(Tb_error,1);

    wn = compute_wn(element_type,x,y,uh_local_vec,N_lb,vertices,basis_type,basis_der_x,basis_der_y);
    r(n) = max(abs(feval(analytic_fun,point)-wn));

end

err=max(r);