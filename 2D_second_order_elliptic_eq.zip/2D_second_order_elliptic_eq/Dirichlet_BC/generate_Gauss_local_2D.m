function [Gauss_weights,Gauss_nodes] = generate_Gauss_local_2D(element_type,vertices,Gauss_point_number)

% Triangular Gauss nodes and Gauss weights -> reference vetices is (0,0),(1,0),(0,1)
% Rectangular Gauss nodes and Gauss weights -> reference vetices is [-1 1]*[-1 1]


if strcmpi(element_type,'Triangular')
    if Gauss_point_number==4
        Gauss_coefficient_reference=[(1-1/sqrt(3))/8,(1-1/sqrt(3))/8,(1+1/sqrt(3))/8,(1+1/sqrt(3))/8];
        Gauss_point_reference=[(1/sqrt(3)+1)/2,(1-1/sqrt(3))*(1+1/sqrt(3))/4;(1/sqrt(3)+1)/2,(1-1/sqrt(3))*(1-1/sqrt(3))/4;(-1/sqrt(3)+1)/2,(1+1/sqrt(3))*(1+1/sqrt(3))/4;(-1/sqrt(3)+1)/2,(1+1/sqrt(3))*(1-1/sqrt(3))/4];
    elseif Gauss_point_number==9
        Gauss_coefficient_reference=[64/81*(1-0)/8,100/324*(1-sqrt(3/5))/8,100/324*(1-sqrt(3/5))/8,100/324*(1+sqrt(3/5))/8,100/324*(1+sqrt(3/5))/8,40/81*(1-0)/8,40/81*(1-0)/8,40/81*(1-sqrt(3/5))/8,40/81*(1+sqrt(3/5))/8];
        Gauss_point_reference=[(1+0)/2,(1-0)*(1+0)/4;(1+sqrt(3/5))/2,(1-sqrt(3/5))*(1+sqrt(3/5))/4;(1+sqrt(3/5))/2,(1-sqrt(3/5))*(1-sqrt(3/5))/4;(1-sqrt(3/5))/2,(1+sqrt(3/5))*(1+sqrt(3/5))/4;(1-sqrt(3/5))/2,(1+sqrt(3/5))*(1-sqrt(3/5))/4;(1+0)/2,(1-0)*(1+sqrt(3/5))/4;(1+0)/2,(1-0)*(1-sqrt(3/5))/4;(1+sqrt(3/5))/2,(1-sqrt(3/5))*(1+0)/4;(1-sqrt(3/5))/2,(1+sqrt(3/5))*(1+0)/4];
    elseif Gauss_point_number==3
        Gauss_coefficient_reference=[1/6,1/6,1/6];
        Gauss_point_reference=[1/2,0;1/2,1/2;0,1/2];
    else
        warning='wrong Gauss point number, it only can be 3, 4 or 9';
    end
    
    x1=vertices(1,1);
    y1=vertices(2,1);
    x2=vertices(1,2);
    y2=vertices(2,2);
    x3=vertices(1,3);
    y3=vertices(2,3);
    %% affine mapping
    a = x2-x1;
    b = x3-x1;
    c = y2-y1;
    d = y3-y1;
    e = x1;
    f = y1;
    
elseif strcmpi(element_type,'Rectangular')
    if Gauss_point_number == 4
        Gauss_point_reference_1D = [-1 1]/sqrt(3);
        Gauss_coefficient_reference_1D = [1 1];
    elseif Gauss_point_number == 9
        Gauss_point_reference_1D = [-sqrt(3/5), 0, sqrt(3/5)];
        Gauss_coefficient_reference_1D = [5/9 8/9 5/9];
    elseif Gauss_point_number == 16
        Gauss_point_reference_1D = [-sqrt((15 + 2 * sqrt(30))/35),-sqrt((15 - 2 * sqrt(30))/35),...
        sqrt((15 - 2 * sqrt(30))/35), sqrt((15 + 2 * sqrt(30))/35)];
        Gauss_coefficient_reference_1D=[(90-5*sqrt(30))/180,(90+5*sqrt(30))/180,(90+5*sqrt(30))/180,(90-5*sqrt(30))/180];
    else
        warning='wrong Gauss point number, it only can be 4, 9 or 16'
    end
    % 1D -> 2D
    Gauss_point_reference = zeros(Gauss_point_number,2);
    Gauss_coefficient_reference=zeros(Gauss_point_number,1);
    n = 0;
    for i = 1: length(Gauss_coefficient_reference_1D)
        for j = 1: length(Gauss_coefficient_reference_1D)
            n = n+1;
            Gauss_point_reference(n,1) = Gauss_point_reference_1D(i);
            Gauss_point_reference(n,2) = Gauss_point_reference_1D(j);
            Gauss_coefficient_reference(n) = Gauss_coefficient_reference_1D(i)*Gauss_coefficient_reference_1D(j);
        end
    end
    
    x1=vertices(1,1);
    y1=vertices(2,1);
    x2=vertices(1,2);
    y2=vertices(2,2);
    x3=vertices(1,3);
    y3=vertices(2,3);
    x4=vertices(1,4);
    y4=vertices(2,4);
 %% affine mapping
    a = (x2-x1)/2;
    b = (x3-x2)/2;
    c = (y2-y1)/2;
    d = (y3-y2)/2;
    e = (x1+x3)/2;
    f = (y1+y3)/2;


else
    waring=('Check if elemen_type is Triangular or Rectangular')
end
%% get local gauss nodes and weights
    J = [a, b; c, d];
    Jacobi=abs(det(J));
    
    Gauss_weights=Gauss_coefficient_reference*Jacobi;
    Gauss_nodes(:,1) = a*Gauss_point_reference(:,1) + b*Gauss_point_reference(:,2)+e;
    Gauss_nodes(:,2) = c*Gauss_point_reference(:,1) + d*Gauss_point_reference(:,2)+f;



end