%main
clear
clc
%%   ------  Domain and mesh information  -----   %%
left = -1;
right = 1;
bottom = -1;
top = 1;
domain = [left, right; bottom, top];
clear left right top bottom


element_type = 'Triangular';% 'Triangular' or 'Rectangular'
basis_type = 201;
basis_type_trial = 201;
basis_type_test = 201;
basis_type_error = 201;
Gauss_type = 9;

for i = 3:7
    h1(i-2,1) = 1/(2^(i-1));
    h2(i-2,1) = 1/(2^i);
    N1 = (domain(1,2) - domain(1,1))/h1(i-2);
    N2 = (domain(2,2) - domain(2,1))/h2(i-2);
    h{i-2}=[h1(i-2),h2(i-2)];
   % N = 2 * N1 * N2;

%% plot basis function 
    getPbTb=generate_2D_PbTb(domain, h{i-2}, basis_type,element_type);% # tri and rec
    user_plot = 'false'; % false or true
    plot_basis_function(user_plot,basis_type,element_type,getPbTb.Tb);
    clear getPbTb

%% Solver 
    [err(i-2)] = FE_solver_2D_second_order_elliptic_equation(element_type,domain,h{i-2},basis_type,basis_type_trial, ...
                                         basis_type_test,Gauss_type);
    %solution1=solution
end

b=struct2cell(err);
%disp('L2_inf_error ');
L_inf_error=cell2mat(b(1,:))';
Convergence_L_inf = log(L_inf_error(1:end-1) ./ L_inf_error(2:end)) ./ log(h1(1:end-1) ./ h1(2:end));
Convergence_L_inf = [0;Convergence_L_inf];


%disp('L2_norm_error ');
L2_norm_error=cell2mat(b(2,:))';
Convergence_L2 = log(L2_norm_error(1:end-1) ./ L2_norm_error(2:end)) ./ log(h1(1:end-1) ./ h1(2:end));
Convergence_L2 = [0;Convergence_L2];

%disp('H1_semi_error ');
H1_semi_error=cell2mat(b(3,:))';
Convergence_H1_semi = log(H1_semi_error(1:end-1) ./ H1_semi_error(2:end)) ./ log(h1(1:end-1) ./ h1(2:end));
Convergence_H1_semi = [0;Convergence_H1_semi];

T = table( h1,h2,L_inf_error,Convergence_L_inf,L2_norm_error,  Convergence_L2, H1_semi_error,Convergence_H1_semi);

% Open the file in append mode
fileID = fopen('Result_linear.txt', 'w');  

% Append a separator line or any other information you want
headerText = '-----------This is the result for Dirichlet boundary condition, linear basis funciton, Rectangular element--------.\n';
fprintf(fileID, headerText);


% Append the table data with specific formatting
fprintf(fileID, ' h1 \t  h2 \t L_inf_error\t Convergence_L_inf\t L2_norm_error\t Convergence_L2\t H1_semi_error\t Convergence_H1_semi\t \n');
for i = 1:height(T)
    fprintf(fileID, '%.4f\t %.4f\t %.4e\t %.4e\t%.4e\t%.4e\t%.4e\t %.4e\n', T.h1(1), T.h2(i), T.L_inf_error(i),T.Convergence_L_inf(i), T.L2_norm_error(i),T.Convergence_L2(i), T.H1_semi_error(i),T.Convergence_H1_semi(i));
end

% Close the file
fclose(fileID);

fprintf('The result for u\n')
disp(T)
