function [A,b]=treat_Robin_boundary_1_variable(Global,Basis, A,b,all_funs,der_R,der_w , boundaryedges)
%  ---- -1: Dirichlet  -2: Neumann -3: Robin --------- %

BC=-3; % Robin

basis_der_x_Robin_w=der_w(1);
basis_der_y_Robin_w=der_w(2);

basis_der_x_R_trail=der_R(1,1);
basis_der_y_R_trail=der_R(1,2);
basis_der_x_R_test=der_R(2,1);
basis_der_y_R_test=der_R(2,2);

w=zeros(Basis.Nb_test,1);
nbe=size(boundaryedges,2);
R = sparse(Basis.Nb_test, Basis.Nb_trail);

  for k=1:nbe
     if boundaryedges(1,k) == BC
         nk=boundaryedges(2,k);
         vertices = Global.P(:,Global.T(:,nk));
         corrdinates_bc=Global.P(:,boundaryedges(3:4,k));
         [Gauss_weights,Gauss_nodes] = generate_Gauss_2D_BC_line(corrdinates_bc,Global.Gauss_type);
                 
           for beta = 1:Basis.N_lb_test
               int_value1=Gauss_quad_BC_line_test(Global.element_type,all_funs.fun_Robin_cq,Gauss_weights,Gauss_nodes,vertices,...
    Basis.basis_type_test,beta,basis_der_x_Robin_w,basis_der_y_Robin_w);
               w(Basis.Tb_test(beta,nk),1)=w(Basis.Tb_test(beta,nk),1)+int_value1;
           end
           for alpha = 1:Basis.N_lb_trial
               for beta = 1:Basis.N_lb_test
                    int_value2 = Gauss_quad_BC_line_trail_test(Global.element_type,all_funs.fun_Robin_cr,Gauss_weights,Gauss_nodes,vertices,...
    Basis.basis_type_trial, Basis.basis_type_test,alpha,beta,basis_der_x_R_trail,basis_der_y_R_trail,basis_der_x_R_test,basis_der_y_R_test);
                    R(Basis.Tb_trail(beta,nk),Basis.Tb_trail(alpha,nk)) = R(Basis.Tb_trail(beta,nk),Basis.Tb_trail(alpha,nk))+int_value2;
               end
           end
           
      end
  end
  b = b + w;
  A = A + R;