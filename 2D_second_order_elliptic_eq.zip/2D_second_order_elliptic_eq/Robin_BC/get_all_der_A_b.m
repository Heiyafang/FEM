function [der_A,der_b]=get_all_der_A_b

% r s p q, / der_x_trail,der_y_trail;der_x_test,der_y_test;
%%  Pre der info for A matrix and b vector
% A1
der_x_trail_A1  = 1; %r
der_y_trail_A1 = 0; %s
der_x_test_A1 = 1;  %p
der_y_test_A1 = 0;  %q

%A2
der_x_trail_A2 = 0; %r
der_y_trail_A2 = 1; %s
der_x_test_A2 = 0; %p
der_y_test_A2 = 1; %q

% der for all matrix
der_A.der_A1 =  [der_x_trail_A1,der_y_trail_A1;der_x_test_A1,der_y_test_A1];
der_A.der_A2 =  [der_x_trail_A2,der_y_trail_A2;der_x_test_A2,der_y_test_A2];


% b1
der_x_test_b = 0;
der_y_test_b = 0;
der_b =[der_x_test_b,der_y_test_b];


% the der of basis function for w matrix
basis_der_x_Robin_w = 0;
basis_der_y_Robin_w = 0;
der_A.der_w = [basis_der_x_Robin_w,basis_der_y_Robin_w];

% the der of basis function for R matrix
basis_der_x_R_trail = 0;
basis_der_y_R_trail = 0;
basis_der_x_R_test = 0;
basis_der_y_R_test = 0;
der_A.der_R = [basis_der_x_R_trail,basis_der_y_R_trail;basis_der_x_R_test,basis_der_y_R_test];