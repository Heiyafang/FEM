function [Gauss_weights,Gauss_nodes] = generate_Gauss_local_1D(vertices,Gauss_type)
% Gauss_type is the number of gauss 
if  Gauss_type==1
    Gauss_nodes=[0] ;
    Gauss_weight=[2];
elseif Gauss_type==2
    Gauss_nodes=[-1 1]/sqrt(3) ;
    Gauss_weight=[1 1];
    %Gauss_p=[-0.5773503, 0.5773503] ;
    %Gauss_weight=[1 1];
elseif Gauss_type==3
    Gauss_nodes = [-sqrt(3/5), 0, sqrt(3/5)];
    Gauss_weights = [5/9 8/9 5/9];
   % Gauss_nodes=[-0.7745967 0 0.7745967]  ;
    %Gauss_weight=[0.5555556 0.8888889 0.5555556];   
elseif Gauss_type == 4
    Gauss_nodes = [-sqrt((15 + 2 * sqrt(30))/35),-sqrt((15 - 2 * sqrt(30))/35),...
        sqrt((15 - 2 * sqrt(30))/35), sqrt((15 + 2 * sqrt(30))/35)];
    Gauss_weights = [(90-5*sqrt(30))/180,(90+5*sqrt(30))/180,(90+5*sqrt(30))/180,(90-5*sqrt(30))/180];
elseif Gauss_type == 5
    Gauss_nodes = [-0.9061798459386640,-0.5384693101056831,0,0.5384693101056831,0.9061798459386640];
    Gauss_weights = [0.2369268850561891,0.4786286704993665,0.5688888888888889,0.4786286704993665,0.2369268850561891];
else
   fprintf('/n not such Gauss_type')
end
for k=1:Gauss_type
    % Standardization Gauss_weight and Gauss_nodes, Transform the interval to [-1, 1]
    Gauss_weights(k)=Gauss_weights(k)*(vertices(2)-vertices(1))/2;
    Gauss_nodes(k)=Gauss_nodes(k)*(vertices(2)-vertices(1))/2+(vertices(2)+vertices(1))/2; 
end
end