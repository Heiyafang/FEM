function [err] = FE_solver_2D_second_order_elliptic_equation(element_type,domain,h,basis_type,basis_type_trial, ...
                                         basis_type_test,Gauss_type)
format shorte
%% ----------------------------------------
% basis_type = 201 : 2D linear
% basis_type = 202 : 2D Qudratic
% P : information matrix consisting of the coordinates of all mesh nodes.
% T: information matrix consisting of the global node indices of the mesh nodes of all the mesh elements.
% Pb : an information matrix consisting of the coordinates of all finite element nodes
% Tb : an information matrix consisting of the global node indices of the finite element nodes of all the mesh elements.
% der_x_trail_A  %r
% der_y_trail_A  %s
% der_x_test_A  %p
% der_y_test_A  %q
% der_x_test_b  %p
% der_y_test_b    %q
%% ================= obtain Global info P T N Gauss_type element_type ===============
% Get P, T, N for global info
PT =  generate_2D_PT(domain, h, element_type); % (domain, h,element_type)
N = size(PT.T,2);
Global.T = PT.T;
Global.P = PT.P;
Global.N = N;
Global.element_type=element_type;
Global.Gauss_type = Gauss_type;

%% ================= obtain Basis info Pb Tb Nb  ===============

PbTb_Trail = generate_2D_PbTb(domain, h, basis_type_trial,element_type);
N_lb_trial =size(PbTb_Trail.Tb,1);

PbTb_Test = generate_2D_PbTb(domain, h, basis_type_test,element_type);
N_lb_test =size(PbTb_Test.Tb,1);

Nb_trail = size(PbTb_Trail.Pb,2);
Nb_test =size(PbTb_Test.Pb,2);


%% ------------------Obtain all functions ---------------------
all_funs = All_functions;


%%  ================= Pre der info for matrix and vector =================
[der_A,der_b]=get_all_der_A_b;

%% ------------------Obtain A stiff matrix ---------------------
% trial and test are same; For A1,A2,A3,A4,A5,A6,A7,A8,A9
Basis.Nb_test= Nb_test;
Basis.Nb_trail= Nb_trail;
Basis.matrix_size= [Basis.Nb_test, Basis.Nb_trail];
Basis.Pb_trail = PbTb_Trail.Pb;
Basis.Pb_test = PbTb_Test.Pb;
Basis.Tb_trail = PbTb_Trail.Tb;
Basis.Tb_test = PbTb_Test.Tb;
Basis.N_lb_trial = N_lb_trial;
Basis.N_lb_test = N_lb_test;
Basis.basis_type_trial = basis_type_trial;
Basis.basis_type_test = basis_type_test;

A1 = assemble_matrix_2D(all_funs.fun_c,Global,Basis,der_A.der_A1);
A2 = assemble_matrix_2D(all_funs.fun_c,Global,Basis,der_A.der_A2);
A =A1+A2;


%% ------------------Obtain b load vector ---------------------


b = assmble_vector_2D(all_funs.fun_f,Global,Basis,der_b);

%% ------------------ Handle Boundary conditions ---------------------

[boundaryedges,boundarynodes] = generate_boundary_info(Global.element_type,basis_type,domain,h);

b = treat_Neumann_boundary_1_variable(Global.element_type,all_funs.fun_Neumann, Global.Gauss_type, b,Basis.Nb_test,Global.P,Global.T, boundaryedges, Basis.Tb_test,Basis.N_lb_test,Basis.basis_type_test);

[A,b] = treat_Dirichlet_boundary_1_variable(all_funs.fun_Diri, A, b, boundarynodes, Basis.Pb_test);



%% ------------------ Get Solution --------------
solution = A\b;


%% --------------------- compute  error--------------------------%%

err = get_all_errors(solution,all_funs,Global,Basis)