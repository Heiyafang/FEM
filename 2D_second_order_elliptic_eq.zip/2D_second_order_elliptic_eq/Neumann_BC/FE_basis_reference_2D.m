function result = FE_basis_reference_2D(xh,yh,basis_type,basis_index,der_x,der_y)

if basis_type==201

    if basis_index==1

        if der_x==0&&der_y==0
            result=-xh-yh+1;
        elseif der_x==1&&der_y==0
            result=-1;
        elseif der_x==0&&der_y==1
            result=-1;
        elseif der_x==1&&der_y==1
            result=0;
        else
            warning('basis_type')
        end

    elseif basis_index==2

        if der_x==0&&der_y==0
            result=xh;
        elseif der_x==1&&der_y==0
            result=1;
        elseif der_x==0&&der_y==1
            result=0;
        elseif der_x==1&&der_y==1
            result=0;
        else
            warning('basis_type')
        end
    elseif basis_index==3
        if der_x==0&&der_y==0
            result=yh;
        elseif der_x==1&&der_y==0
            result=0;
        elseif der_x==0&&der_y==1
            result=1;
        elseif der_x==1&&der_y==1
            result=0;
        else
            warning('basis_type')
        end
    end


elseif basis_type==202


    if basis_index==1
        if der_x==0&&der_y==0
            result=2*xh^2+2*yh^2+4*xh*yh-3*yh-3*xh+1;
        elseif der_x==1&&der_y==0
            result=4*xh+4*yh-3;
        elseif der_x==0&&der_y==1
            result=4*yh+4*xh-3;
        elseif der_x==2&&der_y==0
            result=4;
        elseif der_x==0&&der_y==2
            result=4;
        elseif der_x==1&&der_y==1
            result=4;
        else
            warning('basis_type')
        end



    elseif basis_index==2
        if der_x==0&&der_y==0
            result=2*xh^2-xh;
        elseif der_x==1&&der_y==0
            result=4*xh-1;
        elseif der_x==0&&der_y==1
            result=0;
        elseif der_x==1&&der_y==1
            result=0;
        elseif der_x==2&&der_y==0
            result=4;
        elseif der_x==0&&der_y==2
            result=0;
        else
            warning('basis_type')
        end
    elseif basis_index==3
        if der_x==0&&der_y==0
            result=2*yh^2-yh;
        elseif der_x==1&&der_y==0
            result=0;
        elseif der_x==0&&der_y==1
            result=4*yh-1;
        elseif der_x==1&&der_y==1
            result=0;
        elseif der_x==2&&der_y==0
            result=0;
        elseif der_x==0&&der_y==2
            result=4;
        else
            warning('basis_type')
        end
    elseif basis_index==4
        if der_x==0&&der_y==0
            result=-4*xh^2-4*xh*yh+4*xh;
        elseif der_x==1&&der_y==0
            result=-8*xh-4*yh+4;
        elseif der_x==0&&der_y==1
            result=-4*xh;
        elseif der_x==1&&der_y==1
            result=-4;
        elseif der_x==2&&der_y==0
            result=-8;
        elseif der_x==0&&der_y==2
            result=0;
        else
            warning('basis_type')
        end
    elseif basis_index==5
        if der_x==0&&der_y==0
            result=4*xh*yh;
        elseif der_x==1&&der_y==0
            result=4*yh;
        elseif der_x==0&&der_y==1
            result=4*xh;
        elseif der_x==1&&der_y==1
            result=4;
        elseif der_x==2&&der_y==0
            result=0;
        elseif der_x==0&&der_y==2
            result=0;
        else
            warning('basis_type')
        end
    elseif basis_index==6
        if der_x==0&&der_y==0
            result=-4*yh^2-4*xh*yh+4*yh;
        elseif der_x==1&&der_y==0
            result=-4*yh;
        elseif der_x==0&&der_y==1
            result=-8*yh-4*xh+4;
        elseif der_x==1&&der_y==1
            result=-4;
        elseif der_x==2&&der_y==0
            result=0;
        elseif der_x==0&&der_y==2
            result=-8;
        else
            warning('basis_type')
        end
    else
        warning('basis_index')
    end
end