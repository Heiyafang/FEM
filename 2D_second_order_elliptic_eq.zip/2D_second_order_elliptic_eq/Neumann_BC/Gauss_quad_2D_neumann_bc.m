function int_value = Gauss_quad_2D_neumann_bc(fun_p_hat,)

Gpn = length(Gauss_nodes);
int_value = 0;
for k = 1: Gpn
    int_value = int_value + Gauss_weights(k)*(feval(fun_p_hat,Gauss_nodes(k,:))* ...
        FE_local_basis_2D(element_type,Gauss_nodes(k,1),Gauss_nodes(k,2),vertices,basis_type_test,basis_index_test,basis_der_x_test,basis_der_y_test));

end

