function plot_basis_function(user_plot,basis_type,element_type,Tb)
%x = linspace(0,1,100);
%y = linspace(0,1,100);
%[x_hat,y_hat] = meshgrid(x,y);

%Tb = getPbTb.Tb;

if strcmpi(user_plot,'true') && strcmpi(element_type,'Triangular')
    
    disp("Ref Triangular element is [0,0;0,1;1,0]")
            if basis_type == 201
                vertices = [0,0;1,0;0,1];
                x_hat= vertices(:,1);
                y_hat = vertices(:,2);
                triangles = [1,2,3];
                figure;
                sgtitle('2D Triangular elements and linear basis functions')
                for basis_index =1: size(Tb,1)
                    result = FE_reference_basis_2D(element_type,x_hat,y_hat,basis_type,basis_index,0,0);
                    subplot(1,size(Tb,1),basis_index)
                    trisurf(triangles,x_hat,y_hat,result,'FaceColor','interp','EdgeColor','none');
                    set(gca, 'XGrid', 'on', 'YGrid', 'on', 'ZGrid', 'on');
                    set(gca, 'XMinorGrid', 'off', 'YMinorGrid', 'off', 'ZMinorGrid', 'off');
                    set(gca, 'GridColor', 'k', 'GridLineStyle', '--');
                    set(gca, 'Color', 'none');
                    colorbar;
                    xlabel('x hat')
                    ylabel('y hat')
                    zlabel('Phi hat');
                    title('The basis function for basis index is',basis_index)
                    grid on;
                    colormap('jet');
                end
                 
            elseif basis_type == 202
               figure
               sgtitle('2D Triangular elements and quadratic basis functions')
               for basis_index = 1: size(Tb,1)
                    h = 0.0001;
                    n = (1 / h);
                    vertices = zeros(2, 3 * n);
                    for i = 1: n  
                         vertices(1, i) = (i - 1) * h;
                         vertices(2, i) = 0;
                         vertices(1, n + i) = 1 - (i - 1) * h;
                         vertices(2, n + i) = (i - 1) * h;
                         vertices(1, 2 * n + i) = 0;
                         vertices(2, 2 * n + i) = 1 - (i - 1) * h;
                    end
                    x_hat = vertices(1, :);
                    y_hat = vertices(2, :);
                    triangles = 1:3*n;  % Generate triangles
                    result = FE_reference_basis_2D(element_type, x_hat, y_hat, basis_type, basis_index, 0, 0);
                    subplot(3, size(Tb, 1) / 3, basis_index)
                    trisurf(triangles, x_hat, y_hat, result, 'FaceColor', 'interp', 'EdgeColor', 'none');
                    colorbar;
                    xlabel('x hat');
                    ylabel('y hat');
                    zlabel('Phi hat');
                    title(['The basis function for basis index is ', num2str(basis_index)]);
                    grid on;
                    colormap('jet');
                    zlim([-1, 1]);
                    
              end

            end
elseif strcmpi(user_plot,'true') && strcmpi(element_type,'Rectangular')
    [x_hat,y_hat]=meshgrid(-1:0.1:1,-1:0.1:1); % ref element
    disp("Ref Rectangular element is [-1 1]*[-1 1]")
    if basis_type == 201
                figure;
                sgtitle('2D Rectangular elements and bilinear basis functions')
                for basis_index =1: size(Tb,1)
                    result = FE_reference_basis_2D(element_type,x_hat,y_hat,basis_type,basis_index,0,0);
                    subplot(2,2,basis_index)
                    surf(x_hat,y_hat,result,'FaceColor','interp','EdgeColor','none');
                    colorbar;
                    xlabel('x hat')
                    ylabel('y hat')
                    zlabel('Phi hat');
                    title('The basis function for basis index is',basis_index)
                    grid on;
                    colormap('jet');
                end


    elseif basis_type == 202
       figure
       sgtitle('2D Rectangular elements and biquadratic basis functions')
                for basis_index =1: size(Tb,1)
                    result = FE_reference_basis_2D(element_type,x_hat,y_hat,basis_type,basis_index,0,0);
                    subplot(3,size(Tb,1)/3,basis_index)
                    surf(x_hat,y_hat,result,'FaceColor','interp','EdgeColor','none');
                    colorbar;
                    xlabel('x hat')
                    ylabel('y hat')
                    zlabel('Phi hat');
                    title('The basis function for basis index is',basis_index)
                    grid on;
                    colormap('jet');
                end
    end

elseif strcmpi(user_plot,'false')
           
end
