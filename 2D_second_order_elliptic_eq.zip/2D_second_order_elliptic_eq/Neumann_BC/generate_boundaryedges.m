function boundary_info=generate_boundaryedges(domain,h ,element_type,basis_type)

% BC=-1: Dirichlet boundary node;
% BC=-2: Neumann boundary node;
% BC=-3: Robin boundary node. 
BC = -2; 

N1 = (domain(1,2) - domain(1,1))/h(1);
N2 = (domain(2,2) - domain(2,1))/h(2);

%% 
if strcmpi(element_type,'Triangular')
    %% Information matrix for boundary edges. It uses the index of partition, not the index of FE.
    nbe=2*(N1+N2); % nbe = size(boundaryedges, 2) to be the number of boundary edges;
    boundaryedges=zeros(4,nbe);

%% boundaryedges(1,k),the type of the kth boundary edge ek

%The following boundary condition may change for different problems.
    %% first set all nodes as Dirichlet boundary edges.
    boundaryedges(1,:)=-1;
    %% Modify the bottom boundary edges .
    for k=1:N1
       boundaryedges(1,k)= BC;
    end

    for c = 1:N1
        bottom2(c) = (c-1) *N2*2+1;
        bottom3(c) = 1+(N2+1)*(c-1);
    end

    for r = 1:N2
        right2(r) =  (N1-1) *N2*2+ 2*r;
        right3(r) = (N2+1)*(N1) +r;
    end


    for c = 1:N1
        top2(c) = 2*N1*N2-(c-1)*2*N2;
        top3(c) = (N1+1) * (N2+1) - (N2+1) *(c-1);
    end


    for r = 1:N2
        left2(r) = 2*N2-1-(r-1)*2;
        left3(r) = (N1+1) * (N2+1) - (N2+1) *N1 -  (r-1)*1;

    end
    boundaryedges(2,:) = [bottom2 right2 top2 left2];
    boundaryedges(3,:) = [bottom3 right3 top3 left3];

elseif strcmpi(element_type,'Rectangular')

%% Information matrix for boundary edges. It uses the index of partition, not the index of FE.
    nbe=2*(N1+N2); % nbe = size(boundaryedges, 2) to be the number of boundary edges;
    boundaryedges=zeros(4,nbe);
%The following boundary condition may change for different problems.
    %% first set all nodes as Dirichlet boundary edges.
    boundaryedges(1,:)=-1;
    %% Modify the bottom boundary edges .
    for k=1:N1
       boundaryedges(1,k)=BC;
    end

    for c=1:N1
        bottom2(c) = 1+(c-1) *N2;
        bottom3(c) = 1+(c-1)*(N2+1);
    end

    for r = 1:N2
        right2(r) = (N1-1) *N2 +r;
        right3(r) = (N1)*(N2+1) + r;
    end

    for c = 1:N1
        top2(c) = (N1-1) *N2 +N2 - (c-1) *N2;
        top3(c) = (N1)*(N2+1) + N2+1 -(c-1) *(N2+1);
    end


    for r = 1:N2
        left2(r) = (N1-1) *N2 +N2 - (N1-1) *N2 - (r-1);
        left3(r) = (N1)*(N2+1) + N2+1 -(N1) *(N2+1) - (r-1);
    end

    boundaryedges(2,:) = [bottom2 right2 top2 left2];
    boundaryedges(3,:) = [bottom3 right3 top3 left3];

    
end

%% boundaryedges(4,k) is the global node index of the second end node of the kth boundary boundary edge ek.
    for i =1:length(boundaryedges(3,:))
         if  i < length(boundaryedges(3,:))
            boundaryedges(4,i) = boundaryedges(3,i+1);
        elseif i == length(boundaryedges(3,:))
             boundaryedges(4,i) = boundaryedges(3,1);
        end 
    end
    if basis_type == 201
        nbn=2*(N1+N2);
        boundarynodes=zeros(2,nbn);
         %% first set all nodes as Dirichlet boundary edges.
        boundarynodes(1,:) = -1;
         %% Modify the bottom boundary nodes to be Neumann.
        % The intersection nodes of Dirichlet boundary condition and other boundary conditions 
                % usually need to be treated as Dirichlet boundary nodes

        % Treate the kth intersection node, boundarynodes(1,k)=-1. 
            % (for this case is the first node)
        for k=2:N1
            boundarynodes(1,k)=BC;
        end
        boundarynodes(2,:) =boundaryedges(3,:);
    elseif basis_type == 202
        N2 = 2*N2;
        N1 = 2*N1;
        nbn=2*(N1+N2);
        boundarynodes=zeros(2,nbn);
        for c = 1:N1
            bottom(c) =  1+(N2+1) *(c-1);

        end

        for r = 1:N2
            right(r) = (N2+1) *(N1) +r;
        end

        for c = 1:N1
            top(c) = (N2+1) *(N1) +N2 +1 - (c-1) *(N2+1);
        end

        for r = 1:N2
            left(r) = (N2+1) *(N1) +N2 +1 - (N1) *(N2+1) - (r-1)*1;
        end

        boundarynodes(2,:) = [bottom right top left];
       %% Boundary conditions
        boundarynodes(1,:) = BC;
        %% Modify the bottom boundary nodes to be Neumann.
        % The intersection nodes of Dirichlet boundary condition and other boundary conditions 
                % usually need to be treated as Dirichlet boundary nodes

        % Treate the kth intersection node, boundarynodes(1,k)=-1. 
            % (for this case is the first node)
        for k=2:N1
            boundarynodes(1,k)=-1;
        end
    end
    boundary_info.boundaryedges=boundaryedges;
    boundary_info.nbe = nbe;
    boundary_info.boundary_nodes = boundarynodes;
    boundary_info.nbn = nbn;
