%main
clear
clc
%%   ------  Domain and mesh information  -----   %%
left = -1;
right = 1;
bottom = -1;
top = 1;
domain = [left, right; bottom, top];
clear left right top bottom

element_type = 'Triangular';% 'Triangular' or 'Rectangular'
basis_type = 201;
basis_type_trial = 201;
basis_type_test = 201;
basis_type_error = 201;
Gauss_type = 4;
disp('Dirichlet and Nuemann boundary condition, linear basis funciton and 4 Gauss points ')
fprintf("The element type is %s",element_type)


for i = 3:5
    h1(i-2,1) = 1/(2^(i));
    h2(i-2,1) = 1/(2^i);
    N1 = (domain(1,2) - domain(1,1))/h1(i-2);
    N2 = (domain(2,2) - domain(2,1))/h2(i-2);
    h{i-2}=[h1(i-2),h2(i-2)];
   % N = 2 * N1 * N2;

%% plot basis function 
    getPbTb=generate_2D_PbTb(domain, h{i-2}, basis_type,element_type);% # tri and rec
    user_plot = 'false'; % false or true
    plot_basis_function(user_plot,basis_type,element_type,getPbTb.Tb);
    clear getPbTb

%% Solver 
    [err(i-2)] = FE_solver_2D_second_order_elliptic_equation(element_type,domain,h{i-2},basis_type,basis_type_trial, ...
                                         basis_type_test,Gauss_type);
    %solution1=solution
end

b=struct2cell(err);
%disp('L2_inf_error ');
L_inf_error=cell2mat(b(1,:))';

%disp('L2_norm_error ');
L2_norm_error=cell2mat(b(2,:))';

%disp('H1_semi_error ');
H1_semi_error=cell2mat(b(3,:))';

T = table( h1,h2,L_inf_error,    L2_norm_error,   H1_semi_error)

% Open the file in append mode
fileID = fopen('Result_linear.txt', 'w');  

% Append a separator line or any other information you want
headerText = '-----------This is the result for Dirichlet and Nuemann boundary condition, linear basis funciton, Triangular element--------.\n';
fprintf(fileID, headerText);

% Append the table data
%writetable(T, 'Result_linear.txt', 'Delimiter', '\t', 'WriteRowNames', true, 'WriteVariableNames', true, 'WriteMode', 'append');

% Append the table data with specific formatting
fprintf(fileID, ' h1 \t  h2 \t L_inf_error\t L2_norm_error\t H1_semi_error\n');
for i = 1:height(T)
    fprintf(fileID, '%.4f\t %.4f\t %.4e\t %.4e\t %.4e\n', T.h1(1), T.h2(i), T.L_inf_error(i), T.L2_norm_error(i), T.H1_semi_error(i));
end


% Close the file
fclose(fileID);
