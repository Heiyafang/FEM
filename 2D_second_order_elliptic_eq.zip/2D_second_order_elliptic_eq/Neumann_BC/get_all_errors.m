function err = get_all_errors(solution,all_funs,Global,Basis)
%% ==========   Solution just use trial info   ======



L_inf_err = compute_L2_inf_err(Global.element_type,all_funs.fun_analytic,solution,Global.P,Global.T,Basis.Tb_trail,Basis.basis_type_trial,0,0,Global.Gauss_type); % Tb for u, basis_type for u

L2_err = compute_L2_err(all_funs.fun_analytic,solution,Global.element_type,Global.P,Global.T,Basis.Tb_trail,Global.Gauss_type,Basis.basis_type_trial);% Tb for u, basis_type for u

H1_semi_err = compute_H1_err(all_funs.fun_analytic_der_x,all_funs.fun_analytic_der_y,solution,Global.element_type,Global.P,Global.T,Basis.Tb_trail,Global.Gauss_type,Basis.basis_type_trial);     % Tb for u, basis_type for u



%% --------------------store err------------------------
err.L_inf_err = L_inf_err;
err.L2_err = L2_err;
err.H1_semi_err = H1_semi_err;

