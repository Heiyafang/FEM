Case1， for u1,u2             basis type is 202
        for p, w, \varphi, basis type is 201


Case2,  for u1,u2,w, \varphi,    basis type is 202
        for p,                 basis type is 201
