function [err,solution] = FE_solver_2D_NS_CH(element_type,start_t,end_t,dt,domain,h, basis_type_1,...
                                         basis_type_2,Gauss_type,max_iteration)
format shorte
%% ----------------------------------------
% basis_type = 201 : 2D linear
% basis_type = 202 : 2D Qudratic
% P : information matrix consisting of the coordinates of all mesh nodes.
% T: information matrix consisting of the global node indices of the mesh nodes of all the mesh elements.
% Pb : an information matrix consisting of the coordinates of all finite element nodes
% Tb : an information matrix consisting of the global node indices of the finite element nodes of all the mesh elements.

%% ================= obtain Global info P T N Gauss_type element_type ===============
%% ------------------Obtain P, T, Pb, Tb,N_lb ---------------------
% Get P, T, N for global info
PT =  generate_2D_PT(domain, h, element_type); % (domain, h,element_type)
N = size(PT.T,2);
Global.T = PT.T;
Global.P = PT.P;
Global.N = N;
Global.element_type=element_type;
Global.Gauss_type = Gauss_type;

%% ================= obtain Basis info Pb Tb Nb  ===============

% Get Pb, Tb, basis type = 201
PbTb_1 = generate_2D_PbTb(domain, h, basis_type_1,element_type);
N_lb_1 =size(PbTb_1.Tb,1);
Nb_1 = size(PbTb_1.Pb,2);

% Get Pb, Tb, basis type = 202
PbTb_2 = generate_2D_PbTb(domain, h, basis_type_2,element_type);
N_lb_2 =size(PbTb_2.Tb,1);
Nb_2 =size(PbTb_2.Pb,2);

%% ------------------Obtain all functions ---------------------
all_funs = All_functions;


%%  ================= Pre der info for matrix and vector =================
[der_A,der_b]=get_all_der_A_b;


%% ------------------Obtain Me, A stiff matrix ---------------------

% trail for (202), test for (202)
% Me A1 A2  A7 A8 A9 A10 A11 A12

Basis_22.Nb_test= Nb_2;
Basis_22.Nb_trail= Nb_2;
Basis_22.matrix_size= [Basis_22.Nb_test, Basis_22.Nb_trail];
Basis_22.Tb_trail = PbTb_2.Tb;
Basis_22.Tb_test = PbTb_2.Tb;
Basis_22.Pb_trail = PbTb_2.Pb;
Basis_22.Pb_test = PbTb_2.Pb;
Basis_22.N_lb_trial = N_lb_2;
Basis_22.N_lb_test = N_lb_2;
Basis_22.basis_type_trial = basis_type_2;
Basis_22.basis_type_test = basis_type_2;

Me = assemble_matrix_2D(all_funs.fun_rou,Global,Basis_22,der_A.der_Me);
A1 = assemble_matrix_2D(all_funs.fun_enta,Global,Basis_22,der_A.der_A1);
A2 = assemble_matrix_2D(all_funs.fun_enta,Global,Basis_22,der_A.der_A2);

% coeff function Mc,  -r*eplson , -r/eplson;independent with time
A7 = assemble_matrix_2D(all_funs.fun_Mc,Global,Basis_22,der_A.der_A7);
A8 = assemble_matrix_2D(all_funs.fun_Mc,Global,Basis_22,der_A.der_A8);
A9 = assemble_matrix_2D(all_funs.fun_one,Global,Basis_22,der_A.der_A9);
A10 = assemble_matrix_2D(all_funs.fun_r_eplson_negative,Global,Basis_22,der_A.der_A10);
A11 = assemble_matrix_2D(all_funs.fun_r_eplson_negative,Global,Basis_22,der_A.der_A11);
A12 = assemble_matrix_2D(all_funs.fun_r_eplson_fraction_negative,Global,Basis_22,der_A.der_A12);

% trail for (201), test for (202)
% A3  A4

Basis_12.Nb_trail= Nb_1;
Basis_12.Nb_test= Nb_2;
Basis_12.matrix_size= [Basis_12.Nb_test, Basis_12.Nb_trail];
Basis_12.Tb_trail = PbTb_1.Tb;
Basis_12.Tb_test = PbTb_2.Tb;
Basis_12.Pb_trail = PbTb_1.Pb;
Basis_12.Pb_test = PbTb_2.Pb;
Basis_12.N_lb_trial = N_lb_1;
Basis_12.N_lb_test = N_lb_2;
Basis_12.basis_type_trial = basis_type_1;
Basis_12.basis_type_test = basis_type_2;

A3 = assemble_matrix_2D(all_funs.fun_one,Global,Basis_12,der_A.der_A3);
A4 = assemble_matrix_2D(all_funs.fun_one,Global,Basis_12,der_A.der_A4);


% trail for (202), test for (201)
% A5 A6 
Basis_21.Nb_trail= Nb_2;
Basis_21.Nb_test= Nb_1;
Basis_21.matrix_size= [Basis_21.Nb_test, Basis_21.Nb_trail];
Basis_21.Tb_trail = PbTb_2.Tb;
Basis_21.Tb_test = PbTb_1.Tb;
Basis_21.Pb_trail = PbTb_2.Pb;
Basis_21.Pb_test = PbTb_1.Pb;
Basis_21.N_lb_trial = N_lb_2;
Basis_21.N_lb_test = N_lb_1;
Basis_21.basis_type_trial = basis_type_2;
Basis_21.basis_type_test = basis_type_1;

A5 = assemble_matrix_2D(all_funs.fun_negative_one,Global,Basis_21,der_A.der_A5);
A6 = assemble_matrix_2D(all_funs.fun_negative_one,Global,Basis_21,der_A.der_A6);




O1 = zeros(Nb_1, Nb_1);
O2 = zeros(Nb_1, Nb_2);

O3 = zeros(Nb_1, 1);
O4 = zeros(Nb_2, Nb_1);
O5 = zeros(Nb_2, Nb_2);


%% ------------------ Get the Boundary info ---------------------
% Boundary condition may change
 [boundaryedges1,boundarynodes1] = generate_boundary_info(element_type,basis_type_1,domain,h);
 [boundaryedges2,boundarynodes2] = generate_boundary_info(element_type,basis_type_2,domain,h);


 %% ========================= Iteration =======================================
 % ---------------Newton's iteration-------------------
%initial guess, at t=0 
X_old_tm = generate_initial_vec(all_funs.fun_u1_initial,all_funs.fun_u2_initial, all_funs.fun_p_initial,...
    all_funs.fun_w_initial, all_funs.fun_phi_initial,PbTb_1.Pb,PbTb_2.Pb);

% Time step
number_of_time_step=(end_t-start_t)/dt;

for m = 0:number_of_time_step-1
    % X_old: Xm;
    tm = start_t + m*dt;
    tmp1= start_t + (m+1)*dt;

    %% =================  Obtain b load vector ================= 
     b1_tmp1 = assmble_vector_2D_time(all_funs.fun_f1,Global,Basis_22,der_b.der_b1,tmp1);
     b2_tmp1 = assmble_vector_2D_time(all_funs.fun_f2,Global,Basis_22,der_b.der_b2,tmp1);
     b4_tmp1 = assmble_vector_2D_time(all_funs.fun_f4,Global,Basis_22,der_b.der_b4,tmp1);
     b5_tmp1 = assmble_vector_2D_time(all_funs.fun_f5,Global,Basis_22,der_b.der_b5,tmp1);

    for k = 1:max_iteration
        %initial guess for newton's iteration
        u1h_vec_old = X_old_tm(1:Nb_2);         %u1
        u2h_vec_old = X_old_tm(Nb_2+1 : 2* Nb_2);   %u2
        u3h_vec_old = X_old_tm(2* Nb_2 +1: 2* Nb_2+Nb_1);   %P
        u4h_vec_old = X_old_tm(2* Nb_2+Nb_1 + 1 : 2* Nb_2+Nb_1 +Nb_2);   %W
        u5h_vec_old = X_old_tm(2* Nb_2+Nb_1 +Nb_2+1 : end);   %PHI

%% ------------------Obtain AN stiff matrix ---------------------
        % compute_wn:uh_local_vec*local_basis_fun
        Basis_coe222 = Basis_22;
        Basis_coe222.basis_type_coe = basis_type_2;
        Basis_coe222.Tb_coe = PbTb_2.Tb;
        % rou, u1h(l-1)
        AN1 = assemble_matrix_2D_FE_coe(all_funs.fun_rou,'compute_wn',u1h_vec_old,Global,Basis_coe222,der_A.der_AN1);
        % rou, u1h(l-1)
        AN2 = assemble_matrix_2D_FE_coe(all_funs.fun_rou,'compute_wn',u1h_vec_old,Global,Basis_coe222,der_A.der_AN2);
        % rou, u2h(l-1)
        AN3 = assemble_matrix_2D_FE_coe(all_funs.fun_rou,'compute_wn',u2h_vec_old,Global,Basis_coe222,der_A.der_AN3);
        % rou, u1h(l-1)
        AN4 = assemble_matrix_2D_FE_coe(all_funs.fun_rou,'compute_wn',u1h_vec_old,Global,Basis_coe222,der_A.der_AN4);
        % rou, u2h(l-1)
        AN7 = assemble_matrix_2D_FE_coe(all_funs.fun_rou,'compute_wn',u2h_vec_old,Global,Basis_coe222,der_A.der_AN7);
        % rou, u2h(l-1)
        AN8 = assemble_matrix_2D_FE_coe(all_funs.fun_rou,'compute_wn',u2h_vec_old,Global,Basis_coe222,der_A.der_AN8);
        % -1, u5h(l-1)
        AN5 = assemble_matrix_2D_FE_coe(all_funs.fun_negative_one,'compute_wn',u5h_vec_old,Global,Basis_coe222,der_A.der_AN5);
        % -1, u4h(l-1)
        AN6 = assemble_matrix_2D_FE_coe(all_funs.fun_negative_one,'compute_wn',u4h_vec_old,Global,Basis_coe222,der_A.der_AN6);
        % -1, u5h(l-1)
        AN9 = assemble_matrix_2D_FE_coe(all_funs.fun_negative_one,'compute_wn',u5h_vec_old,Global,Basis_coe222,der_A.der_AN9);
         % -1, u4h(l-1)
        AN10 = assemble_matrix_2D_FE_coe(all_funs.fun_negative_one,'compute_wn',u4h_vec_old,Global,Basis_coe222,der_A.der_AN10);
         % 1, u5h(l-1)
        AN11 = assemble_matrix_2D_FE_coe(all_funs.fun_one,'compute_wn',u5h_vec_old,Global,Basis_coe222,der_A.der_AN11);
         % 1, u5h(l-1)
        AN12 = assemble_matrix_2D_FE_coe(all_funs.fun_one,'compute_wn',u5h_vec_old,Global,Basis_coe222,der_A.der_AN12);
         % 1, u1h(l-1)
        AN13 = assemble_matrix_2D_FE_coe(all_funs.fun_one,'compute_wn',u1h_vec_old,Global,Basis_coe222,der_A.der_AN13);
         % 1, u2h(l-1)
        AN14 = assemble_matrix_2D_FE_coe(all_funs.fun_one,'compute_wn',u2h_vec_old,Global,Basis_coe222,der_A.der_AN14);

  %% ------------------Obtain AN15 stiff matrix ---------------------
        % u5h(l-1)^2, -3*r/eplso
        % -3r/eplson u5h(l-1)
        AN15 = assemble_matrix_2D_FE_coe_square(all_funs.fun_3r_eplson_fraction,'compute_wn',u5h_vec_old,Global,Basis_coe222,der_A.der_AN15);
 %% =======================================     Assemble A Matrix =======================================       
        A_1 = [Me/dt+A1+A2+AN1+AN2+AN3 AN4 A3  AN5  AN6];
        A_2=[AN7 Me/dt+A1+A2+AN8+AN2+AN3 A4 AN9  AN10];
        A_3 = [A5 A6 O1 O2 O2];
        A_4 = [AN11 AN12 O4 A7+A8 A9/dt+AN13+AN14];
        A_5 = [O5 O5 O4 A9 A10+A11+AN15];
        A = [A_1;A_2;A_3;A_4;A_5];

        
        %% ------------------Obtain bN load vector ---------------------
        % test for 202, coe1 for 202, coe2 for 202
        Basis_coe_bN_222 =Basis_22;
        Basis_coe_bN_222.Tb_coe1= PbTb_2.Tb;
        Basis_coe_bN_222.Tb_coe2 = PbTb_2.Tb;
        Basis_coe_bN_222.basis_type_coe1 = basis_type_2;
        Basis_coe_bN_222.basis_type_coe2 = basis_type_2;

        % fun_rou,u1h(l-1) u1h(l-1)
        bN1 = assmble_vector_2D_FE_coe(all_funs.fun_rou,'compute_wn',u1h_vec_old,u1h_vec_old,Global,Basis_coe_bN_222,der_b.der_bN1);
        % fun_rou,u2h(l-1) u1h(l-1)
        bN2= assmble_vector_2D_FE_coe(all_funs.fun_rou,'compute_wn',u2h_vec_old,u1h_vec_old,Global,Basis_coe_bN_222,der_b.der_bN2);
         %fun_rou, u1h(l-1) u2h(l-1)
        bN4= assmble_vector_2D_FE_coe(all_funs.fun_rou,'compute_wn',u1h_vec_old,u2h_vec_old,Global,Basis_coe_bN_222,der_b.der_bN4);
         %fun_rou, u2h(l-1) u2h(l-1)
        bN5= assmble_vector_2D_FE_coe(all_funs.fun_rou,'compute_wn',u2h_vec_old,u2h_vec_old,Global,Basis_coe_bN_222,der_b.der_bN5);
        %-1, u4h(l-1) u5h(l-1)
        bN3= assmble_vector_2D_FE_coe(all_funs.fun_negative_one,'compute_wn',u4h_vec_old,u5h_vec_old,Global,Basis_coe_bN_222,der_b.der_bN3);
        %-1, u4h(l-1) u5h(l-1)
        bN6= assmble_vector_2D_FE_coe(all_funs.fun_negative_one,'compute_wn',u4h_vec_old,u5h_vec_old,Global,Basis_coe_bN_222,der_b.der_bN6);
        %1, u1h(l-1) u5h(l-1)
        bN7= assmble_vector_2D_FE_coe(all_funs.fun_one,'compute_wn',u1h_vec_old,u5h_vec_old,Global,Basis_coe_bN_222,der_b.der_bN7);
        %1, u2h(l-1) u5h(l-1)
        bN8= assmble_vector_2D_FE_coe(all_funs.fun_one,'compute_wn',u2h_vec_old,u5h_vec_old,Global,Basis_coe_bN_222,der_b.der_bN8);

        % test for 201, coe for 201
        Basis_coe_bN_22 =Basis_22;
        Basis_coe_bN_22.Tb_coe= PbTb_2.Tb;
        Basis_coe_bN_22.basis_type_coe=basis_type_2;
         %-2*r/eplso, u5h(l-1)^3, 
         bN9 = assemble_vector_2D_FE_coe_cubic(all_funs.fun_2r_eplson_fraction,'compute_wn',u5h_vec_old,Global,Basis_coe_bN_22,der_b.der_bN9);
     %% =======================================     Assemble b vector ======================================= 
         b_1 = b1_tmp1 + bN1+bN2+bN3+Me*u1h_vec_old/dt;
         b_2=b2_tmp1+bN4+bN5+bN6+Me*u2h_vec_old/dt;
         b_3=O3;
         b_4=b4_tmp1+bN7+bN8+A9*u5h_vec_old/dt;
         b_5=b5_tmp1+bN9+A12*u5h_vec_old;
         b= [b_1; b_2; b_3;b_4;b_5]; 
        
         %% ------------------ Handle Boundary conditions ---------------------
         % including fix p at one point
            [A,b]=treat_Dirichlet_boundary_5_variable_time( all_funs.fun_Diri_u1,all_funs.fun_Diri_u2,all_funs.fun_Diri_p,all_funs.fun_Diri_w,all_funs.fun_Diri_phi, ...
                tmp1, A, b, boundarynodes1,boundarynodes2, PbTb_1.Pb,PbTb_2.Pb,Nb_1,Nb_2);
        %% ------------------ Update Xmp1 - ---------------
            X_old_tmp1 =A\b;
    end
    X_old_tm= X_old_tmp1;
   
end

% Get the solution at the end time
solution = X_old_tm;

%% --------------------- compute  error--------------------------%%
% Compute errors at the end time
t = start_t:dt:end_t;
% Use trial , basis type trial for 201 and basis type trail for 202
err = get_all_errors_time_5_Variable(solution,all_funs,Global,Nb_1,Nb_2,Basis_12,Basis_22,t);








