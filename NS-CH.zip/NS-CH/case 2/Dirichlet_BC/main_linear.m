%main
clear
clc
tic
format long e
%%   ------  Domain and mesh information  -----   %%
left = 0;
right = 1;
bottom = 0;
top = 1;
domain = [left, right; bottom, top];
clear left right top bottom
% Time domain
start_t = 0;
end_t = 1;

element_type = 'Triangular';% 'Triangular' element or 'Rectangular' element
basis_type_plot = 201;
basis_type_1 = 201;
basis_type_2 = 202;
Gauss_type = 9;
max_iteration=10;
%  h=[1/4 1/4],dt=1/8
h1=[1/4 1/8 1/16]';
h2=[1/4 1/8 1/16]';
dt = [1/16 1/64 1/512]';


% Finite difference method is Backward Euler scheme

for i = 1:length(h1)
   
    h{i}=[h1(i) h2(i)];
  

%% plot basis function 
    getPbTb=generate_2D_PbTb(domain, h{i}, basis_type_plot,element_type);% # tri and rec
    user_plot = 'false'; % false or true
    plot_basis_function(user_plot,basis_type_plot,element_type,getPbTb.Tb);
    clear getPbTb

%% Solver 
    [err(i),solution{i}] = FE_solver_2D_NS_CH(element_type,start_t,end_t,dt(i),domain,h{i},basis_type_1, ...
                                         basis_type_2,Gauss_type,max_iteration);
end

%%  Compute error and Convergence
b=struct2cell(err);

% For u
L_inf_error_u=cell2mat(b(1,:))';
Convergence_L_inf_u = log(L_inf_error_u(1:end-1) ./ L_inf_error_u(2:end)) ./ log(h1(1:end-1) ./ h1(2:end));
Convergence_L_inf_u = [0;Convergence_L_inf_u];

L2_norm_error_u=cell2mat(b(2,:))';
Convergence_L2_u = log(L2_norm_error_u(1:end-1) ./ L2_norm_error_u(2:end)) ./ log(h1(1:end-1) ./ h1(2:end));
Convergence_L2_u = [0;Convergence_L2_u];

H1_semi_error_u=cell2mat(b(3,:))';
Convergence_H1_semi_u = log(H1_semi_error_u(1:end-1) ./ H1_semi_error_u(2:end)) ./ log(h1(1:end-1) ./ h1(2:end));
Convergence_H1_semi_u = [0;Convergence_H1_semi_u];

% For p
L_inf_error_p=cell2mat(b(4,:))';
Convergence_L_inf_p = log(L_inf_error_p(1:end-1) ./ L_inf_error_p(2:end)) ./ log(h1(1:end-1) ./ h1(2:end));
Convergence_L_inf_p = [0;Convergence_L_inf_p];

L2_norm_error_p=cell2mat(b(5,:))';
Convergence_L2_p = log(L2_norm_error_p(1:end-1) ./ L2_norm_error_u(2:end)) ./ log(h1(1:end-1) ./ h1(2:end));
Convergence_L2_p = [0;Convergence_L2_p];

H1_semi_error_p=cell2mat(b(6,:))';
Convergence_H1_semi_p = log(H1_semi_error_p(1:end-1) ./ H1_semi_error_p(2:end)) ./ log(h1(1:end-1) ./ h1(2:end));
Convergence_H1_semi_p = [0;Convergence_H1_semi_p];


% For w
L_inf_error_w=cell2mat(b(7,:))';
Convergence_L_inf_w = log(L_inf_error_w(1:end-1) ./ L_inf_error_w(2:end)) ./ log(h1(1:end-1) ./ h1(2:end));
Convergence_L_inf_w = [0;Convergence_L_inf_w];

L2_norm_error_w=cell2mat(b(8,:))';
Convergence_L2_w = log(L2_norm_error_w(1:end-1) ./ L2_norm_error_u(2:end)) ./ log(h1(1:end-1) ./ h1(2:end));
Convergence_L2_w = [0;Convergence_L2_w];

H1_semi_error_w=cell2mat(b(9,:))';
Convergence_H1_semi_w = log(H1_semi_error_w(1:end-1) ./ H1_semi_error_w(2:end)) ./ log(h1(1:end-1) ./ h1(2:end));
Convergence_H1_semi_w = [0;Convergence_H1_semi_w];

% For phi
L_inf_error_phi=cell2mat(b(10,:))';
Convergence_L_inf_phi = log(L_inf_error_phi(1:end-1) ./ L_inf_error_phi(2:end)) ./ log(h1(1:end-1) ./ h1(2:end));
Convergence_L_inf_phi = [0;Convergence_L_inf_phi];

L2_norm_error_phi=cell2mat(b(11,:))';
Convergence_L2_phi = log(L2_norm_error_phi(1:end-1) ./ L2_norm_error_u(2:end)) ./ log(h1(1:end-1) ./ h1(2:end));
Convergence_L2_phi = [0;Convergence_L2_phi];

H1_semi_error_phi=cell2mat(b(12,:))';
Convergence_H1_semi_phi = log(H1_semi_error_phi(1:end-1) ./ H1_semi_error_phi(2:end)) ./ log(h1(1:end-1) ./ h1(2:end));
Convergence_H1_semi_phi = [0;Convergence_H1_semi_phi];

%%  error and Convergence
T_u = table(h1,h2,L_inf_error_u, Convergence_L_inf_u,   L2_norm_error_u, Convergence_L2_u,  H1_semi_error_u,Convergence_H1_semi_u);
T_p = table(h1,h2,L_inf_error_p, Convergence_L_inf_p,   L2_norm_error_p, Convergence_L2_p,  H1_semi_error_p,Convergence_H1_semi_p);
T_w = table(h1,h2,L_inf_error_w, Convergence_L_inf_w,   L2_norm_error_w, Convergence_L2_w,  H1_semi_error_w,Convergence_H1_semi_w);
T_phi = table(h1,h2,L_inf_error_phi, Convergence_L_inf_phi,   L2_norm_error_phi, Convergence_L2_phi,  H1_semi_error_phi,Convergence_H1_semi_phi);


%%  Store error and Convergence
%Open the file in append mode
fileID = fopen('Result_NS_CH_Q_L_Q.txt', 'w'); 

% Append a separator line or any other information you want
headerText = '======================================================================================================.\n';
fprintf(fileID, headerText);
headerText = '                          Dirichlet boundary condition, Triangular element                             \n';
fprintf(fileID, headerText);
headerText = '======================================================================================================.\n';
fprintf(fileID, headerText);

%u 
% Append a separator line or any other information you want
headerText = '==========================================This is the result for u============================================================.\n';
fprintf(fileID, headerText);
% Append the table data
fprintf(fileID, ' h1 \t  h2 \t L_inf_error\t Convergence_L_inf\t L2_norm_error\t Convergence_L2_\t H1_semi_error\t Convergence_H1_semi\t \n');
for i = 1:height(T_phi)
    fprintf(fileID, '%.4f\t %.4f\t %.4e\t %.4e\t%.4e\t%.4e\t%.4e\t %.4e\n', T_u.h1(1), T_u.h2(i), T_u.L_inf_error_u(i),T_u.Convergence_L_inf_u(i), T_u.L2_norm_error_u(i),T_u.Convergence_L2_u(i), T_u.H1_semi_error_u(i),T_u.Convergence_H1_semi_u(i));
end
%p 
headerText = '==========================================This is the result for p============================================================.\n';
fprintf(fileID, headerText);
% Append the table data
fprintf(fileID, ' h1 \t  h2 \t L_inf_error\t Convergence_L_inf\t L2_norm_error\t Convergence_L2_\t H1_semi_error\t Convergence_H1_semi\t \n');
for i = 1:height(T_phi)
    fprintf(fileID, '%.4f\t %.4f\t %.4e\t %.4e\t%.4e\t%.4e\t%.4e\t %.4e\n', T_p.h1(1), T_p.h2(i), T_p.L_inf_error_p(i),T_p.Convergence_L_inf_p(i), T_p.L2_norm_error_p(i),T_p.Convergence_L2_p(i), T_p.H1_semi_error_p(i),T_p.Convergence_H1_semi_p(i));
end

%w
headerText = '==========================================This is the result for w============================================================.\n';
fprintf(fileID, headerText);

fprintf(fileID, ' h1 \t  h2 \t L_inf_error\t Convergence_L_inf\t L2_norm_error\t Convergence_L2_\t H1_semi_error\t Convergence_H1_semi\t \n');
for i = 1:height(T_phi)
    fprintf(fileID, '%.4f\t %.4f\t %.4e\t %.4e\t%.4e\t%.4e\t%.4e\t %.4e\n', T_w.h1(1), T_w.h2(i), T_w.L_inf_error_w(i),T_w.Convergence_L_inf_w(i), T_w.L2_norm_error_w(i),T_w.Convergence_L2_w(i), T_w.H1_semi_error_w(i),T_w.Convergence_H1_semi_w(i));
end


%phi
% Append a separator line or any other information you want
headerText = '==========================================This is the result for phi============================================================.\n';
fprintf(fileID, headerText);
% Append the table data
fprintf(fileID, ' h1 \t  h2 \t L_inf_error\t Convergence_L_inf\t L2_norm_error\t Convergence_L2_\t H1_semi_error\t Convergence_H1_semi\t \n');
for i = 1:height(T_phi)
    fprintf(fileID, '%.4f\t %.4f\t %.4e\t %.4e\t%.4e\t%.4e\t%.4e\t %.4e\n', T_phi.h1(1), T_phi.h2(i), T_phi.L_inf_error_phi(i),T_phi.Convergence_L_inf_phi(i), T_phi.L2_norm_error_phi(i),T_phi.Convergence_L2_phi(i), T_phi.H1_semi_error_phi(i),T_phi.Convergence_H1_semi_phi(i));
end

T_u
T_p
T_w
T_phi