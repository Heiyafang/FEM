function [A,b]=treat_Dirichlet_boundary_5_variable_time( Diri_fun1,Diri_fun2, Diri_fun3,Diri_fun4,Diri_fun5,t, A, b, boundarynodes1, boundarynodes2,Pb_1,Pb_2,Nb_1,Nb_2)
%  ---- -1: Dirichlet  -2: Neumann -3: Robin --------- %
  nbn2=size(boundarynodes2,2);
  for k=1:nbn2
     if boundarynodes2(1,k) == -1
           i=boundarynodes2(2,k);
           %u1  basis type is 202
           A(i,:)=0;
           A(i,i)=1;
           b(i)=feval(Diri_fun1, Pb_2(:,i)',t);  
           %u2 basis type is 202
           A(Nb_2+i,:)=0;
           A(Nb_2+i,Nb_2+i)=1;
           b(Nb_2+i)=feval(Diri_fun2, Pb_2(:,i)',t); 
          
      end
  end

 %p fix p at one point 
 %p:  basis type is 201
   i=2;
           A(2*Nb_2+i,:)=0;
           A(2*Nb_2+i,2*Nb_2+i)=1;
           b(2*Nb_2+i)=feval(Diri_fun3, Pb_1(:,i)',t); 


  nbn2=size(boundarynodes2,2);
  for k=1:nbn2
     if boundarynodes2(1,k) == -1
           i=boundarynodes2(2,k);
           %w  basis type is 201
           A(2*Nb_2+Nb_1+i,:)=0;
           A(2*Nb_2+Nb_1+i,2*Nb_2+Nb_1+i)=1;
           b(2*Nb_2+Nb_1+i)=feval(Diri_fun4, Pb_2(:,i)',t); 
           %phi basis type is 201
           A(2*Nb_2+ Nb_1 + Nb_2+i,:)=0;
           A(2*Nb_2+ Nb_1 + Nb_2+i,2*Nb_2+ Nb_1 + Nb_2+i)=1;
           b(2*Nb_2+ Nb_1 + Nb_2+i)=feval(Diri_fun5, Pb_2(:,i)',t);  
          
      end
  end
  
            
           