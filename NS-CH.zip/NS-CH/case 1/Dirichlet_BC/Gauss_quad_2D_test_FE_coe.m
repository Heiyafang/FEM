function int_value = Gauss_quad_2D_test_FE_coe(element_type,coe_fun,uh_fun,uh_local_vec1,uh_local_vec2,Gauss_weights,Gauss_nodes,vertices,...
                     basis_type_test,basis_index_test,basis_der_x_test,basis_der_y_test, ...
                     basis_type_coe1,basis_type_coe2,basis_der_x_coe1,basis_der_y_coe1,basis_der_x_coe2,basis_der_y_coe2)

%% ----------------------------------------------------------------------------
% Gpn: guass point of number       
%Gauss integrals      f at [a,b] = sum(w(k)*f(x(k))) at [1, gauss_point_number]
% w(k) is gauss weight      x(k) is gauss point
%uh_local_vec: the values of the FE solution at the nodes of FE in a triangular element.
%uh_fun which is a FE solution * a trial FE local basis function(or its derivatives) * a test FE local basis function (or its derivatives).
%% --------------------------------------------------------------------------------
Gpn=length(Gauss_nodes);
int_value = 0;

for k = 1:Gpn
    int_value = int_value+Gauss_weights(k)*(feval(coe_fun,Gauss_nodes(k,:))*feval(uh_fun,element_type,Gauss_nodes(k,1),Gauss_nodes(k,2),uh_local_vec1,vertices,basis_type_coe1,basis_der_x_coe1,basis_der_y_coe1)...
        *feval(uh_fun,element_type,Gauss_nodes(k,1),Gauss_nodes(k,2),uh_local_vec2,vertices,basis_type_coe2,basis_der_x_coe2,basis_der_y_coe2)...
        * FE_local_basis_2D(element_type,Gauss_nodes(k,1),Gauss_nodes(k,2),vertices,basis_type_test,basis_index_test,basis_der_x_test,basis_der_y_test));
end

%FE_local_basis_2D(element_type,x,y,h1,h2,vertices,basis_type,basis_index,der_x,der_y)