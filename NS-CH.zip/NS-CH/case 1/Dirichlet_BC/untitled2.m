syms x y t;

% parameters
Mc=1;
r=1;
eplson=1;
enta = 1;
rou= 1;

% u1
u1 =  1/pi*sin(2*pi.*y)* cos(x) *exp(t);
u1x=diff(u1,x);
fun_u1x = matlabFunction(u1x, 'Vars', [x, y,t])
u1y=diff(u1,y);
fun_u1y = matlabFunction(u1y, 'Vars', [x, y,t])

% u2
u2 = -2 + (1/pi^2)*(sin(pi*y)^2)* sin(x)*exp(t);
u2x=diff(u2,x);
fun_u2x = matlabFunction(u2x, 'Vars', [x, y,t])
u2y=diff(u2,y);
fun_u2y = matlabFunction(u2y, 'Vars', [x, y,t])

% p
p=0;
px = 0;
py = 0;

%w
w=x*y*(1-x/2)*(1-y)*exp(x+y+t);
wx=diff(w,x);
wy=diff(w,y);
% function of derivative 
fun_w_analytic_der_x = matlabFunction(wx, 'Vars', [x, y,t])
fun_w_analytic_der_y = matlabFunction(wy, 'Vars', [x, y,t])

% phi
phi= exp(x+y+t);
phix=diff(phi,x);
fun_phix = matlabFunction(phix, 'Vars', [x, y,t])
phiy=diff(phi,y);
fun_phiy = matlabFunction(phiy, 'Vars', [x, y,t])




% eq1 
u1t = diff(u1,t);
u2t = diff(u2,t);
lap_u1 = laplacian(u1, [x, y]);
lap_u2 = laplacian(u2, [x, y]);

f1 = rou * u1t + rou * u1* u1x + rou *u2*u1y + px -enta*(lap_u1) - w * phix;
fun_f1 = matlabFunction(f1, 'Vars', [x, y,t])

f2 = rou * u2t + rou *u1*u2x + rou *u2*u2y + py - enta * lap_u2- w*phiy;
fun_f2 = matlabFunction(f2, 'Vars', [x, y,t])

% eq3
phit=diff(phi,t);
lap_w = laplacian(w, [x, y]);
f4 = phit + u1*phix + u2*phiy - Mc*lap_w; 
fun_f4 = matlabFunction(f4, 'Vars', [x, y,t])

% eq4
Lap_phi=laplacian(phi,[x,y]);
f=1/eplson * phi *(phi^2-1);
f5 = w+r*eplson*Lap_phi-r*f;
fun_f5 = matlabFunction(f5, 'Vars', [x, y,t])

