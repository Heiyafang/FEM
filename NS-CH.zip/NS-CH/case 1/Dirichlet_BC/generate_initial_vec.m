function result = generate_initial_vec(fun_initial_1,fun_initial_2,fun_initial_3,fun_initial_4,fun_initial_5,Pb_trail_1,Pb_trail_2)


%Pb_trail_1=Basis_1.Pb_trail  % Basis type 201
%Pb_trail_2 = Basis_2.Pb_trail % Basis type 202

result1 = feval(fun_initial_1,Pb_trail_2');

result2 = feval(fun_initial_2,Pb_trail_2');

result3 = feval(fun_initial_3,Pb_trail_1');

result4 = feval(fun_initial_4,Pb_trail_1');

result5 = feval(fun_initial_5,Pb_trail_1');

result = [result1; result2; result3;result4; result5];
