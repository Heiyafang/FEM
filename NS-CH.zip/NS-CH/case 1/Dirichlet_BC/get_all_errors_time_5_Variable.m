function err = get_all_errors_time_5_Variable(solution,all_funs,Global,Nb_1,Nb_2,Basis_11,Basis_22,t)



%% ==========   Solution just use trial info   ======


solution1 = solution(1:Nb_2);          %u1
solution2 = solution(Nb_2+1:2*Nb_2);   %u2
solution3 = solution(2*Nb_2+1: 2*Nb_2+Nb_1);    %p
solution4 = solution(2*Nb_2+Nb_1+1: 2*Nb_2+2*Nb_1); % w
solution5 = solution(2*Nb_2+2*Nb_1+1: end); % phi



L2_inf_err_time_u1 = compute_L2_inf_err_time(Global.element_type,all_funs.fun_u1_analytic,solution1,Global.P,Global.T,Basis_22.Tb_trail,Basis_22.basis_type_trial,0,0,Global.Gauss_type,t(end));% 
L2_inf_err_time_u2 = compute_L2_inf_err_time(Global.element_type,all_funs.fun_u2_analytic,solution2,Global.P,Global.T,Basis_22.Tb_trail,Basis_22.basis_type_trial,0,0,Global.Gauss_type,t(end));% 
L2_inf_err_u= max(L2_inf_err_time_u1,L2_inf_err_time_u2);

L2_inf_err_p = compute_L2_inf_err_time(Global.element_type,all_funs.fun_p_analytic,solution3,Global.P,Global.T,Basis_11.Tb_trail,Basis_11.basis_type_trial,0,0,Global.Gauss_type,t(end));% 
L2_inf_err_w = compute_L2_inf_err_time(Global.element_type,all_funs.fun_w_analytic,solution4,Global.P,Global.T,Basis_11.Tb_trail,Basis_11.basis_type_trial,0,0,Global.Gauss_type,t(end));% 
L2_inf_err_phi = compute_L2_inf_err_time(Global.element_type,all_funs.fun_phi_analytic,solution5,Global.P,Global.T,Basis_11.Tb_trail,Basis_11.basis_type_trial,0,0,Global.Gauss_type,t(end));% 




L2_err_time_u1 = compute_L2_err_time(all_funs.fun_u1_analytic,solution1,Global.element_type,Global.P,Global.T,Basis_22.Tb_trail,Global.Gauss_type,Basis_22.basis_type_trial,t(end));% 
L2_err_time_u2 = compute_L2_err_time(all_funs.fun_u2_analytic,solution2,Global.element_type,Global.P,Global.T,Basis_22.Tb_trail,Global.Gauss_type,Basis_22.basis_type_trial,t(end));% 
L2_err_u = sqrt(L2_err_time_u1.^2+ L2_err_time_u2.^2);

L2_err_p = compute_L2_err_time(all_funs.fun_p_analytic,solution3,Global.element_type,Global.P,Global.T,Basis_11.Tb_trail,Global.Gauss_type,Basis_11.basis_type_trial,t(end));%
L2_err_w = compute_L2_err_time(all_funs.fun_w_analytic,solution4,Global.element_type,Global.P,Global.T,Basis_11.Tb_trail,Global.Gauss_type,Basis_11.basis_type_trial,t(end));% 
L2_err_phi = compute_L2_err_time(all_funs.fun_phi_analytic,solution5,Global.element_type,Global.P,Global.T,Basis_11.Tb_trail,Global.Gauss_type,Basis_11.basis_type_trial,t(end));


H1_semi_err_time_u1 = compute_H1_err_time(all_funs.fun_u1_analytic_der_x,all_funs.fun_u1_analytic_der_y,solution1,Global.element_type,Global.P,Global.T,Basis_22.Tb_trail,Global.Gauss_type,Basis_22.basis_type_trial,t(end));%
H1_semi_err_time_u2 = compute_H1_err_time(all_funs.fun_u2_analytic_der_x,all_funs.fun_u2_analytic_der_y,solution2,Global.element_type,Global.P,Global.T,Basis_22.Tb_trail,Global.Gauss_type,Basis_22.basis_type_trial,t(end));%
H1_semi_err_u=  sqrt(H1_semi_err_time_u1.^2+ H1_semi_err_time_u2.^2);

H1_semi_err_p = compute_H1_err_time(all_funs.fun_p_analytic_der_x,all_funs.fun_p_analytic_der_y,solution3,Global.element_type,Global.P,Global.T,Basis_11.Tb_trail,Global.Gauss_type,Basis_11.basis_type_trial,t(end));% 
H1_semi_err_w = compute_H1_err_time(all_funs.fun_w_analytic_der_x,all_funs.fun_w_analytic_der_y,solution4,Global.element_type,Global.P,Global.T,Basis_11.Tb_trail,Global.Gauss_type,Basis_11.basis_type_trial,t(end));% 
H1_semi_err_phi = compute_H1_err_time(all_funs.fun_phi_analytic_der_x,all_funs.fun_phi_analytic_der_y,solution5,Global.element_type,Global.P,Global.T,Basis_11.Tb_trail,Global.Gauss_type,Basis_11.basis_type_trial,t(end));% 




%% --------------------store err------------------------
err.L2_inf_err_u = L2_inf_err_u;
err.L2_err_u = L2_err_u;
err.H1_semi_err_u = H1_semi_err_u;

err.L2_inf_err_p = L2_inf_err_p;
err.L2_err_p = L2_err_p;
err.H1_semi_err_p = H1_semi_err_p;

err.L2_inf_err_w = L2_inf_err_w;
err.L2_err_w = L2_err_w;
err.H1_semi_err_w = H1_semi_err_w;

err.L2_inf_err_phi = L2_inf_err_phi;
err.L2_err_phi = L2_err_phi;
err.H1_semi_err_phi = H1_semi_err_phi;
