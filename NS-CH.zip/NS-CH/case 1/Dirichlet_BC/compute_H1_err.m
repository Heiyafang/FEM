function result = compute_H1_err(fun_u_x,fun_u_y,solution,element_type,P,T,Tb_error,Gauss_type,...
    basis_type_error)


basis_der_x_error = 1;
basis_der_y_error = 0;
temp1= (compute_int_error(fun_u_x,solution,element_type,P,T,Tb_error,Gauss_type,basis_type_error,basis_der_x_error,basis_der_y_error));


basis_der_x_error = 0;
basis_der_y_error = 1;
temp2= (compute_int_error(fun_u_y,solution,element_type,P,T,Tb_error,Gauss_type,basis_type_error,basis_der_x_error,basis_der_y_error));


result = sqrt(temp1 + temp2);
% 
% r = compute_int_error(der_fun_u,solution,element_type,P,T,Tb_error,Gauss_type,...
%     basis_type_error,basis_der_x_error,basis_der_y_error)


