function  PT =generate_2D_PT(domain, h,element_type)

left = domain(1,1);
right = domain(1,2);
bottom = domain(2,1);
top = domain(2,2);
h1 = h(1);
h2 = h(2);
N1 = (domain(1,2) - domain(1,1))/h1;
N2 = (domain(2,2) - domain(2,1))/h2;

%% Temp_T  from left to right from bottom to top (Rectangular index)
k = 0;
    for c = 1: N1
        for r = 1:N2 %x-axis
            k = k+1;
            t1 = (c-1)*(N2+1)+r;
            t2 = c*(N2+1)+r;
            t3 = c*(N2+1)+r+1;
            t4 = (c-1)*(N2+1)+r+1;
            Temp_T(:,k) = [t1;t2;t3;t4];
        end
    end
%% Compute Temp_P
x_node = left:h1:right;
y_node = bottom:h2:top;
k = 0; 
  for r = 1:(N1+1)  %x-axis
      for c = 1:(N2+1)
          k = k+1;
          Temp_P(:,k) = [x_node(r);y_node(c)];
       end
   end

if strcmpi(element_type,'Triangular')
    for n = 1:(N1*N2)
          T(:,2*n-1) = [Temp_T(1,n); Temp_T(2,n); Temp_T(4,n)];
          T(:,2*n) = [Temp_T(4,n); Temp_T(2,n); Temp_T(3,n)];
    end
    
    PT.P = Temp_P;
    PT.T = T;

elseif strcmpi(element_type,'Rectangular')
    PT.P = Temp_P;
    PT.T = Temp_T;
end