function all_funs = All_functions

all_funs=struct('fun_u1_initial',@fun_u1_initial,'fun_u2_initial',@fun_u2_initial,'fun_p_initial',@fun_p_initial,'fun_w_initial',@fun_w_initial,'fun_phi_initial',@fun_phi_initial, ...
    'r',@r,'eplson',@eplson,...
    'fun_Mc',@fun_Mc, 'fun_rou',@fun_rou,'fun_enta',@fun_enta,...
    'fun_one',@fun_one, 'fun_negative_one',@fun_negative_one,...
    'fun_r_eplson_negative',@fun_r_eplson_negative,'fun_r_eplson_fraction_negative',@fun_r_eplson_fraction_negative, ...
    'fun_2r_eplson_fraction',@fun_2r_eplson_fraction,'fun_3r_eplson_fraction',@fun_3r_eplson_fraction, ...
    'fun_f1',@fun_f1,'fun_f2',@fun_f2, 'fun_f4',@fun_f4,'fun_f5',@fun_f5,...
    'fun_Diri_u1',@fun_Diri_u1,'fun_Diri_u2',@fun_Diri_u2,'fun_Diri_p',@fun_Diri_p,'fun_Diri_w',@fun_Diri_w,'fun_Diri_phi',@fun_Diri_phi, ...
    'fun_u1_analytic',@fun_u1_analytic,'fun_u1_analytic_der_x',@fun_u1_analytic_der_x, 'fun_u1_analytic_der_y',@fun_u1_analytic_der_y, ...
    'fun_u2_analytic',@fun_u2_analytic,'fun_u2_analytic_der_x',@fun_u2_analytic_der_x, 'fun_u2_analytic_der_y',@fun_u2_analytic_der_y, ...
    'fun_p_analytic',@fun_p_analytic,'fun_p_analytic_der_x',@fun_p_analytic_der_x, 'fun_p_analytic_der_y',@fun_p_analytic_der_y, ...
    'fun_w_analytic',@fun_w_analytic,'fun_w_analytic_der_x',@fun_w_analytic_der_x, 'fun_w_analytic_der_y',@fun_w_analytic_der_y,...
    'fun_phi_analytic',@fun_phi_analytic,'fun_phi_analytic_der_x',@fun_phi_analytic_der_x, 'fun_phi_analytic_der_y',@fun_phi_analytic_der_y);


    function result = fun_u1_initial(point)
         x= point(:,1);
         y =point(:,2);
         t=0;
        result = 1/pi.*sin(2*pi.*y).* cos(x)*exp(t);

    end
    function result = fun_u2_initial(point)
         x= point(:,1);
         y =point(:,2);
         t=0;
        result = -2 + (1/pi^2).*(sin(pi.*y).^2).* sin(x)*exp(t);

    end
    function result = fun_p_initial(point)
         x= point(:,1);
         y =point(:,2) ;
         t = 0;
        result = 0.* x .* y;
    end
    function result = fun_w_initial(point)
         x= point(:,1);
         y =point(:,2) ;
         t=0;
        result = x.*y.*(1-x./2).*(1-y).*exp(x+y+t);
    end
    function result = fun_phi_initial(point)
         x= point(:,1);
         y =point(:,2) ;
         t=0;
        result = exp(x+y+t);
    end
    function result = r(point)
            result = 1;
    end
    function result = eplson(point)
            result = 1;
    end
    function result = fun_Mc(point)
            result = 1;
    end
    function result = fun_rou(point)
            result = 1;
    end
    function result = fun_enta(point)
            result = 1;
    end
    function result = fun_r_eplson_negative(point)
        result = - r*eplson;      
    end
    function result = fun_r_eplson_fraction_negative(point)
        result = -r/eplson;      
    end

    function result = fun_2r_eplson_fraction(point)
        result = -2*r/eplson;      
    end
    function result = fun_3r_eplson_fraction(point)
        result = -3*r/eplson;      
    end
    function result = fun_one(point)
            result = 1;
    end
    function result = fun_negative_one(point)
            result = -1;
    end
   
    function result = fun_f1(point,t)
        x= point(:,1);
        y =point(:,2) ;
        result= exp(t).*sin(y.*pi.*2.0).*cos(x).*6.366197723675814e-1-exp(t.*2.0).*sin(y.*pi.*2.0).^2.*cos(x).*sin(x).*1.013211836423378e-1+pi.^2.*exp(t).*sin(y.*pi.*2.0).*cos(x).*1.273239544735163-x.*y.*exp(t.*2.0+x.*2.0+y.*2.0).*(x./2.0-1.0).*(y-1.0)+pi.*exp(t).*cos(y.*pi.*2.0).*cos(x).*(exp(t).*sin(y.*pi).^2.*sin(x).*1.013211836423378e-1-2.0).*6.366197723675814e-1;
    end
    function result = fun_f2(point,t)
        x= point(:,1);
        y =point(:,2);
        result = exp(t).*sin(y.*pi).^2.*sin(x).*2.026423672846756e-1+exp(t.*2.0).*sin(y.*pi).^2.*sin(y.*pi.*2.0).*cos(x).^2.*3.225153443319949e-2-pi.^2.*exp(t).*cos(y.*pi).^2.*sin(x).*2.026423672846756e-1+pi.^2.*exp(t).*sin(y.*pi).^2.*sin(x).*2.026423672846756e-1-x.*y.*exp(t.*2.0+x.*2.0+y.*2.0).*(x./2.0-1.0).*(y-1.0)+pi.*exp(t).*cos(y.*pi).*sin(y.*pi).*sin(x).*(exp(t).*sin(y.*pi).^2.*sin(x).*1.013211836423378e-1-2.0).*2.026423672846756e-1;
    end
    function result = fun_f4(point,t)
        x= point(:,1);
        y =point(:,2) ;
        result=  exp(t+x+y)+exp(t+x+y).*(exp(t).*sin(y.*pi).^2.*sin(x).*1.013211836423378e-1-2.0)-x.*exp(t+x+y).*(x./2.0-1.0).*2.0-y.*exp(t+x+y).*(y-1.0)-x.*exp(t+x+y).*(x./2.0-1.0).*(y-1.0).*2.0-y.*exp(t+x+y).*(x./2.0-1.0).*(y-1.0).*2.0-x.*y.*exp(t+x+y).*(y-1.0)-x.*y.*exp(t+x+y).*(x./2.0-1.0).*2.0+exp(t+x+y).*exp(t).*sin(y.*pi.*2.0).*cos(x).*3.183098861837907e-1-x.*y.*exp(t+x+y).*(x./2.0-1.0).*(y-1.0).*2.0;
    end
    function result = fun_f5(point,t)
        x= point(:,1);
        y =point(:,2) ;
        result= exp(t+x+y).*2.0-exp(t+x+y).*(exp(t.*2.0+x.*2.0+y.*2.0)-1.0)+x.*y.*exp(t+x+y).*(x./2.0-1.0).*(y-1.0);
    end
    function result=fun_Diri_u1(point,t)
         x= point(:,1);
        y =point(:,2) ;
        result= 1/pi.*sin(2*pi.*y).* cos(x)*exp(t);
    end
    function result=fun_Diri_u2(point,t)
         x= point(:,1);
         y =point(:,2);
        result= -2 + (1/pi^2).*(sin(pi.*y).^2).* sin(x)*exp(t);
    end
    function result=fun_Diri_p(point,t)
        x= point(:,1);
        y =point(:,2) ;
        result=0.*x.*y;
    end
    function result=fun_Diri_w(point,t)
         x= point(:,1);
        y =point(:,2) ;
        result=x.*y.*(1-x./2).*(1-y).*exp(x+y+t);
    end
    function result=fun_Diri_phi(point,t)
         x= point(:,1);
        y =point(:,2) ;
        result=exp(x+y+t);
    end

    function result=fun_u1_analytic(point,t)
        x= point(:,1);
        y =point(:,2);
        result = 1/pi.*sin(2*pi.*y).* cos(x)*exp(t);
    end

    function result=fun_u1_analytic_der_x(point,t)
        x= point(:,1);
        y =point(:,2);
        result=exp(t).*sin(y.*pi.*2.0).*sin(x).*(-3.183098861837907e-1);
    end
    function result=fun_u1_analytic_der_y(point,t)
        x= point(:,1);
        y =point(:,2);
       result= pi.*exp(t).*cos(y.*pi.*2.0).*cos(x).*6.366197723675814e-1;

    end
    function result=fun_u2_analytic(point,t)
        x= point(:,1);
        y =point(:,2);
        result = -2 + (1/pi^2).*(sin(pi.*y).^2).* sin(x)*exp(t);
    end

    function result=fun_u2_analytic_der_x(point,t)
        x= point(:,1);
        y =point(:,2);
        result = exp(t).*sin(y.*pi).^2.*cos(x).*1.013211836423378e-1;
    end
    function result=fun_u2_analytic_der_y(point,t)
        x= point(:,1);
        y =point(:,2);
       result= pi.*exp(t).*cos(y.*pi).*sin(y.*pi).*sin(x).*2.026423672846756e-1;

    end
    function result=fun_p_analytic(point,t)
        x= point(:,1);
        y =point(:,2);
        result = 0.*x.*y;
    end

    function result=fun_p_analytic_der_x(point,t)
        x= point(:,1);
        y =point(:,2);
        result=0.*x.*y;
    end
    function result=fun_p_analytic_der_y(point,t)
        x= point(:,1);
        y =point(:,2);
       result= 0.*x.*y;

    end

    function result=fun_w_analytic(point,t)
         x= point(:,1);
        y =point(:,2);
        result=x.*y.*(1-x./2).*(1-y).*exp(x+y+t);
    end
    function result=fun_w_analytic_der_x(point,t)
        x= point(:,1);
        y =point(:,2);
        result = y.*exp(t+x+y).*(x./2.0-1.0).*(y-1.0)+(x.*y.*exp(t+x+y).*(y-1.0))./2.0+x.*y.*exp(t+x+y).*(x./2.0-1.0).*(y-1.0);;
    end
    function result=fun_w_analytic_der_y(point,t)
        x= point(:,1);
        y =point(:,2);
        result =x.*exp(t+x+y).*(x./2.0-1.0).*(y-1.0)+x.*y.*exp(t+x+y).*(x./2.0-1.0)+x.*y.*exp(t+x+y).*(x./2.0-1.0).*(y-1.0);
    end
    function result=fun_phi_analytic(point,t)
         x= point(:,1);
        y =point(:,2);
        result= exp(x+y+t);
    end
    function result=fun_phi_analytic_der_x(point,t)
        x= point(:,1);
        y =point(:,2);
        result = exp(t+x+y);
    end
    function result=fun_phi_analytic_der_y(point,t)
        x= point(:,1);
        y =point(:,2);
        result = exp(t+x+y);
    end


end
