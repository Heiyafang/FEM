function result = generate_initial_vec_Newton(fun_u_analytic,fun_w_analytic,Pb_trail,t)

solution1 = feval(fun_u_analytic,Pb_trail',t); % Phi, X1 %phi
solution2 =  feval(fun_w_analytic,Pb_trail',t);


result =[solution1; solution2];
