function solution=itration_scheme_2(element_type,X_old,basis_type_u,domain,h,A,M,theta,start_t,dt,Nb_u,Nb_p,number_of_time_step,all_funs,Global,Basis_uu,PbTb_p,der_b)


% Iteration Scheme 2
A_tlide= M./dt +theta.*A;
temp = M./dt - (1-theta) .* A;


O = zeros(Nb_p, 1);

for m = 0:number_of_time_step-1
    % X_old: Xm;
    tm = start_t + m*dt;
    tmp1= start_t + (m+1)*dt;

  %% =================  Obtain b load vector ================= 
    

    % Get b_tm  test for u;
    b_tm_1 = assmble_vector_2D_time(all_funs.fun_f1,Global,Basis_uu,der_b.der_b1,tm);
    b_tm_2 = assmble_vector_2D_time(all_funs.fun_f2,Global,Basis_uu,der_b.der_b2,tm);
     
    b_tm = [b_tm_1;b_tm_2;O];

    % Get b_tmp1
    b_tmp1_1 = assmble_vector_2D_time(all_funs.fun_f1,Global,Basis_uu,der_b.der_b1,tmp1);
    b_tmp1_2 = assmble_vector_2D_time(all_funs.fun_f2,Global,Basis_uu,der_b.der_b2,tmp1);

    b_tmp1 = [b_tmp1_1;b_tmp1_2;O];


    b_tlide= theta*b_tmp1+(1-theta)*b_tm+ temp* X_old;

    %% ------------------ Handle Boundary conditions ---------------------

    [boundaryedges,boundarynodes] = generate_boundary_info(element_type,basis_type_u,domain,h);

    [A_tlide,b_tlide]=treat_Dirichlet_boundary_2_variable_time( all_funs.fun_Diri1,all_funs.fun_Diri2, tmp1, A_tlide, b_tlide, boundarynodes, Basis_uu.Pb_test ,Nb_u);
    
    % fix p at one point
    [A_tlide,b_tlide] = fixed_pressure_at_one_point(all_funs.fun_Diri3,A_tlide,b_tlide,Nb_u,PbTb_p.Pb,tmp1);

    %% ------------------ Get Solution --------------
    solution = A_tlide\b_tlide;
    X_old = solution;


end