function bN= assmble_vector_2D_FE_coe(coe_fun,uh_fun,uh_vec1,uh_vec2,Global, Basis,der)



basis_der_x_coe1 = der(1,1);
basis_der_y_coe1 = der(1,2);
basis_der_x_coe2 = der(2,1);
basis_der_y_coe2 = der(2,2);
basis_der_x_test = der(3,1);
basis_der_y_test = der(3,2);


bN= zeros(Basis.matrix_size(1),1);
for n = 1:Global.N
    vertices = Global.P(:,Global.T(:,n)); % coordinates of nth mesh elements
    [Gauss_weights,Gauss_nodes] = generate_Gauss_local_2D(Global.element_type,vertices,Global.Gauss_type);
    uh_local_vec1 = uh_vec1(Basis.Tb_coe1(:,n));
    uh_local_vec2 = uh_vec2(Basis.Tb_coe2(:,n));
    for beta = 1:Basis.N_lb_test
        r = Gauss_quad_2D_test_FE_coe(Global.element_type,coe_fun,uh_fun,uh_local_vec1,uh_local_vec2,Gauss_weights,Gauss_nodes,vertices,...
                     Basis.basis_type_test,beta,basis_der_x_test,basis_der_y_test, ...
                     Basis.basis_type_coe1,Basis.basis_type_coe2,basis_der_x_coe1,basis_der_y_coe1,basis_der_x_coe2,basis_der_y_coe2);
        
        bN(Basis.Tb_test(beta,n),1) = bN(Basis.Tb_test(beta,n),1) + r;
        % d(beta,1) = Gauss_quad_1D_test(fun_f,Gauss_weights,Gauss_nodes,vertices,basis_type_test,basis_index_test,basis_der_x_test);
    end
    %b(Tb(:,n),1) = b(Tb(:,n),1) + d;
end