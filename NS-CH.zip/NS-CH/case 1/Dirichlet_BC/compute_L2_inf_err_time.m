function error = compute_L2_inf_err_time(element_type,analytic_fun,solution,P,T,Tb_error,basis_type_error,basis_der_x,basis_der_y,Gauss_type,t)

error = 0;

N = size(T,2);
for n=1:N
    vertices = P(:,T(:,n));
    uh_local_vec = solution(Tb_error(:,n)); % 
    [Gauss_weights,Gauss_nodes] = generate_Gauss_local_2D(element_type,vertices,Gauss_type);
    rn = max(abs(feval(analytic_fun,Gauss_nodes,t) - compute_wn(element_type,Gauss_nodes(:,1),Gauss_nodes(:,2),uh_local_vec,vertices,basis_type_error,basis_der_x,basis_der_y)));
    if rn>error
        error=rn;
    end
end