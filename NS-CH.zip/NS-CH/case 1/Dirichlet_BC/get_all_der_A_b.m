function [der_A,der_b]=get_all_der_A_b




%%  Pre der info for A matrix 
% r s p q, / der_x_trail,der_y_trail;der_x_test,der_y_test;

% Matrix Me
der_A.der_Me = [0,0; 0,0];

% Matrix A
der_A.der_A1 =  [1,0; 1,0];
der_A.der_A2 =  [0,1; 0,1];
der_A.der_A3 = [1 0 ; 0 0];
der_A.der_A4 =  [0 1; 0 0];
der_A.der_A5 = [1 0; 0 0];
der_A.der_A6 = [0 1; 0 0];
der_A.der_A7 = [1 0 ; 1 0];
der_A.der_A8 = [0 1; 0 1];
der_A.der_A9 = [0 0; 0 0];
der_A.der_A10 = [1 0 ; 1 0];
der_A.der_A11 = [0 1; 0 1];
der_A.der_A12 = [0 0 ; 0 0];

%%  Pre der info for AN matrix 
% der for all matrix  % d e  r s p q  / der_x_AN,der_y_AN_coe;  der_x_trail,der_y_trail;der_x_test,der_y_test;
der_A.der_AN1 = [1 0; 0 0; 0 0]; 
der_A.der_AN2 = [0 0; 1 0; 0 0];
der_A.der_AN3 = [0 0; 0,1; 0 0];
der_A.der_AN4 = [0 1; 0 0; 0 0];
der_A.der_AN5 = [1 0; 0 0; 0 0];
der_A.der_AN6 = [0 0; 1 0; 0 0];
der_A.der_AN7 = [1 0; 0 0; 0 0];
der_A.der_AN8 = [0 1; 0 0; 0 0];
der_A.der_AN9 = [0 1; 0 0; 0 0];
der_A.der_AN10 = [0 0;0 1; 0 0];
der_A.der_AN11 = [1 0; 0 0; 0 0];
der_A.der_AN12 = [0 1; 0 0; 0 0];
der_A.der_AN13 = [0 0; 1 0; 0 0];
der_A.der_AN14 = [0 0; 0 1; 0 0];

% coe^2
der_A.der_AN15 = [0 0; 0 0; 0 0];


%%  Pre der info for b vector 
%[p,q], der_x_test,der_y_test;  

der_b.der_b1 = [0,0];
der_b.der_b2 = [0,0];
der_b.der_b4 = [0,0];
der_b.der_b5 = [0,0];


%d e r s p q / der_x_coe1_bN1,der_y_coe1_bN1; der_x_coe2_bN1,der_y_coe2_bN1;der_x_test_bN1,der_y_test_bN1

der_b.der_bN1 = [0 0; 1 0; 0 0];
der_b.der_bN2 = [0 0; 0 1; 0 0];
der_b.der_bN3 = [0 0; 1 0; 0 0];
der_b.der_bN4 = [0 0; 1 0; 0 0];
der_b.der_bN5 = [0 0; 0 1; 0 0];
der_b.der_bN6 = [0 0; 0 1; 0 0];
der_b.der_bN7 = [0 0; 1 0; 0 0];
der_b.der_bN8 = [0 0; 0 1; 0 0];


%d e  p q / der_x_coe1_bN1,der_y_coe1_bN1; der_x_test_bN1,der_y_test_bN1
%coe^3 
der_b.der_bN9=[0 0; 0 0];
