function int_value = Gauss_quad_2D_error_time(fun_u,element_type,uh_local_vec,Gauss_weights,Gauss_nodes,vertices,...
    basis_type_error,basis_der_x_error,basis_der_y_error,t)

Gpn = length(Gauss_nodes);
int_value = 0;
for k = 1: Gpn
    int_value = int_value +Gauss_weights(k)*(feval(fun_u,Gauss_nodes(k,:),t) - ...
        compute_wn(element_type,Gauss_nodes(k,1),Gauss_nodes(k,2),uh_local_vec,vertices,basis_type_error,basis_der_x_error,basis_der_y_error)).^2;

end

