function [A,b] = fixed_pressure_at_one_point(Diri_fun3,A,b,Nb_u,Pb_p,t)

i=1;
A(2*Nb_u+i,:)=0;
A(2*Nb_u+i,2*Nb_u+i)=1;
b(2*Nb_u+i)=feval(Diri_fun3, Pb_p(:,i),t);  