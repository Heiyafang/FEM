function all_funs = All_functions

all_funs=struct('fun_u_initial',@fun_u_initial,'fun_w_initial',@fun_w_initial,'fun_Mc',@fun_Mc, ...
    'fun_r_eplson',@fun_r_eplson,'fun_r_eplson_fraction',@fun_r_eplson_fraction, ...
    'fun_2r_eplson_fraction',@fun_2r_eplson_fraction,'fun_3r_eplson_fraction',@fun_3r_eplson_fraction, ...
    'fun_one',@fun_one, ...
    'fun_f1',@fun_f1,'fun_f2',@fun_f2,'fun_Diri_u',@fun_Diri_u,'fun_Diri_w',@fun_Diri_w, ...
    'fun_u_analytic',@fun_u_analytic,'fun_u_analytic_der_x',@fun_u_analytic_der_x, 'fun_u_analytic_der_y',@fun_u_analytic_der_y, ...
    'fun_w_analytic',@fun_w_analytic,'fun_w_analytic_der_x',@fun_w_analytic_der_x, 'fun_w_analytic_der_y',@fun_w_analytic_der_y);


    function result = fun_u_initial(point)
         x= point(:,1);
         y =point(:,2) ;
        result = exp(x+y);

    end
    function result = fun_w_initial(point)
         x= point(:,1);
         y =point(:,2) ;
        result = x.*y.*(1-x/2).*(1-y).*exp(x+y);
    end
   
    function result = fun_Mc(point)
            result = 1;
    end
    function result = fun_r_eplson(point)
        r=1;
        eplson=1;
        result = - r*eplson;      
    end
    function result = fun_r_eplson_fraction(point)
        r=1;
        eplson=1;
        result = -r/eplson;      
    end
    function result = fun_2r_eplson_fraction(point)
        r=1;
        eplson=1;
        result = -2*r/eplson;      
    end
    function result = fun_3r_eplson_fraction(point)
        r=1;
        eplson=1;
        result = -3*r/eplson;      
    end
    function result = fun_one(point)
            result = 1;
    end
   
    function result = fun_f1(point,t)
        x= point(:,1);
        y =point(:,2) ;
        result=  exp(t+x+y)-x.*exp(t+x+y).*(x./2.0-1.0).*2.0-y.*exp(t+x+y).*(y-1.0)-x.*exp(t+x+y).*(x./2.0-1.0).*(y-1.0).*2.0-y.*exp(t+x+y).*(x./2.0-1.0).*(y-1.0).*2.0-x.*y.*exp(t+x+y).*(y-1.0)-x.*y.*exp(t+x+y).*(x./2.0-1.0).*2.0-x.*y.*exp(t+x+y).*(x./2.0-1.0).*(y-1.0).*2.0;
    end
    function result = fun_f2(point,t)
        x= point(:,1);
        y =point(:,2);
        result =exp(t+x+y).*2.0-exp(t+x+y).*(exp(t.*2.0+x.*2.0+y.*2.0)-1.0)+x.*y.*exp(t+x+y).*(x./2.0-1.0).*(y-1.0);
    end

    function result=fun_Diri_u(point,t)
        x=point(1);
        y=point(2);
        result=exp(x+y+t);
    end
    function result=fun_Diri_w(point,t)
        x=point(1);
        y=point(2);
        result=x.*y.*(1-x/2).*(1-y).*exp(x+y+t);
    end

    function result=fun_u_analytic(point,t)
        x= point(:,1);
        y =point(:,2);
        result = exp(x+y+t);
    end

    function result=fun_u_analytic_der_x(point,t)
        x= point(:,1);
        y =point(:,2);
        result=exp(x+y+t);
    end
    function result=fun_u_analytic_der_y(point,t)
        x= point(:,1);
        y =point(:,2);
       result= exp(x+y+t);
    end

    function result=fun_w_analytic(point,t)
         x= point(:,1);
        y =point(:,2);
        result=x.*y.*(1-x./2).*(1-y).*exp(x+y+t);
    end
    function result=fun_w_analytic_der_x(point,t)
        x= point(:,1);
        y =point(:,2);
       % result=y.*exp(t + x + y).*(x/2 - 1).*(y - 1) + (x.*y.*exp(t + x + y).*(y - 1))/2 + x.*y.*exp(t + x + y).*(x/2 - 1).*(y - 1);
        result = y.*exp(t+x+y).*(x./2.0-1.0).*(y-1.0)+(x.*y.*exp(t+x+y).*(y-1.0))./2.0+x.*y.*exp(t+x+y).*(x./2.0-1.0).*(y-1.0);
    end
    function result=fun_w_analytic_der_y(point,t)
        x= point(:,1);
        y =point(:,2);
       % result=x.*exp(t + x + y).*(x/2 - 1).*(y - 1) + x.*y.*exp(t + x + y).*(x/2 - 1) + x.*y.*exp(t + x + y).*(x/2 - 1).*(y - 1);
        result =x.*exp(t+x+y).*(x./2.0-1.0).*(y-1.0)+x.*y.*exp(t+x+y).*(x./2.0-1.0)+x.*y.*exp(t+x+y).*(x./2.0-1.0).*(y-1.0);
    end

end
