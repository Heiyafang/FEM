function A = assemble_matrix_2D(coe_fun,Global,Basis,der_A)
%----------------------------
% matrix_size(1) = Nb_test; matrix_size(2) = Nb_trail
% N: number of elements
% N_lb_trial : number of local basis trail function
% N_lb_test : number of local basis test function
% quad: quadrature
%---------------------------------

basis_der_x_trail = der_A(1,1);
basis_der_y_trail = der_A(1,2);
basis_der_x_test = der_A(2,1);
basis_der_y_test = der_A(2,2);

A = sparse (Basis.matrix_size(1), Basis.matrix_size(2));
%[Gauss_coefficient_reference_triangle,Gauss_point_reference_triangle]=generate_Gauss_reference_triangle(Gauss_type);
for n=1:Global.N
    vertices = Global.P(:,Global.T(:,n)); % coordinates of nth mesh elements
    %[Gauss_weights,Gauss_nodes]=generate_Gauss_local_triangle(Gauss_coefficient_reference_triangle,Gauss_point_reference_triangle,vertices);
    [Gauss_weights,Gauss_nodes] = generate_Gauss_local_2D(Global.element_type,vertices,Global.Gauss_type);
    for alpha = 1:Basis.N_lb_trial
        for beta = 1: Basis.N_lb_test
            int_value = Gauss_quad_2D_trail_test(Global.element_type,coe_fun,Gauss_weights,...
                Gauss_nodes,vertices,Basis.basis_type_trial,alpha,basis_der_x_trail,basis_der_y_trail,...
                Basis.basis_type_test,beta,basis_der_x_test,basis_der_y_test);
            A(Basis.Tb_test(beta,n),Basis.Tb_trail(alpha,n)) =  A(Basis.Tb_test(beta,n),Basis.Tb_trail(alpha,n)) + int_value;
        end
    end
    %A(Tb_test(:,n),Tb_trail(:,n)) = A(Tb_test(:,n),Tb_trail(:,n))+S
end
