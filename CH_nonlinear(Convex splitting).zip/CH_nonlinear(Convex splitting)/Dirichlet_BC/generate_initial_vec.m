function result = generate_initial_vec(fun_initial_1,fun_initial_2,Pb_trail)


result1 = feval(fun_initial_1,Pb_trail'); % Phi, X1

result2 = feval(fun_initial_2,Pb_trail'); % w, X2

result = [result1; result2];
