function [err,solution] = FE_solver_2D_CH_nonlinear(element_type,theta,start_t,end_t,dt,domain,h, basis_type_trial,...
                                         basis_type_test,Gauss_type,max_iteration)
format shorte
%% ----------------------------------------
% basis_type = 201 : 2D linear
% basis_type = 202 : 2D Qudratic
% P : information matrix consisting of the coordinates of all mesh nodes.
% T: information matrix consisting of the global node indices of the mesh nodes of all the mesh elements.
% Pb : an information matrix consisting of the coordinates of all finite element nodes
% Tb : an information matrix consisting of the global node indices of the finite element nodes of all the mesh elements.

%% ================= obtain Global info P T N Gauss_type element_type ===============
% Get P, T, N for global info
PT =  generate_2D_PT(domain, h, element_type); % (domain, h,element_type)
N = size(PT.T,2);
Global.T = PT.T;
Global.P = PT.P;
Global.N = N;
Global.element_type=element_type;
Global.Gauss_type = Gauss_type;

%% ================= obtain Basis info Pb Tb Nb  ===============

PbTb_Trail = generate_2D_PbTb(domain, h, basis_type_trial,element_type);
N_lb_trial =size(PbTb_Trail.Tb,1);

PbTb_Test = generate_2D_PbTb(domain, h, basis_type_test,element_type);
N_lb_test =size(PbTb_Test.Tb,1);

Nb_trail = size(PbTb_Trail.Pb,2);
Nb_test =size(PbTb_Test.Pb,2);
%% ------------------Obtain all functions ---------------------
all_funs = All_functions;


%%  ================= Pre der info for matrix and vector =================
[der_A,der_b]=get_all_der_A_b;


%% ------------------Obtain A stiff matrix ---------------------
% trial and test are same; 
Basis.Nb_test= Nb_test;
Basis.Nb_trail= Nb_trail;
Basis.matrix_size= [Basis.Nb_test, Basis.Nb_trail];
Basis.Pb_trail = PbTb_Trail.Pb;
Basis.Pb_test = PbTb_Test.Pb;
Basis.Tb_trail = PbTb_Trail.Tb;
Basis.Tb_test = PbTb_Test.Tb;
Basis.N_lb_trial = N_lb_trial;
Basis.N_lb_test = N_lb_test;
Basis.basis_type_trial = basis_type_trial;
Basis.basis_type_test = basis_type_test;

Basis_coe = Basis;
Basis_coe.basis_type_coe = basis_type_trial;
%% -----------------Obtain  matrix-------------------
% coeff function Mc;independent with time
A11 = assemble_matrix_2D(all_funs.fun_Mc,Global,Basis,der_A.der_A11);
A12 = assemble_matrix_2D(all_funs.fun_Mc,Global,Basis,der_A.der_A12);
A1 =A11+A12;

%coeff function -r*eplson; independent with time
A21 = assemble_matrix_2D(all_funs.fun_r_eplson,Global,Basis,der_A.der_A21);
A22 = assemble_matrix_2D(all_funs.fun_r_eplson,Global,Basis,der_A.der_A22);

%coeff function  is r/eplison,  independent with time
K = assemble_matrix_2D(all_funs.fun_r_eplson_fraction,Global,Basis,der_A.der_K);

A2 =A21+A22 ;

%% -----------------Obtain M matrix-------------------
%coeff function  is one, independent with time
M = assemble_matrix_2D(all_funs.fun_one,Global,Basis,der_A.der_M);



%% ------------------ Get the Boundary info ---------------------
% Boundary condition may change
 [boundaryedges,boundarynodes] = generate_boundary_info(element_type,basis_type_trial,domain,h);


 %% ========================= Iteration =======================================
 % ---------------Newton's iteration-------------------
%initial guess, at t=0 
X_old_tm = generate_initial_vec(all_funs.fun_u_initial,all_funs.fun_w_initial,Basis.Pb_trail);

% Time step
number_of_time_step=(end_t-start_t)/dt;


for m = 0:number_of_time_step-1
    % X_old: Xm;
    tm = start_t + m*dt;
    tmp1= start_t + (m+1)*dt;

    %% =================  Obtain b load vector ================= 
     b1_tm = assmble_vector_2D_time(all_funs.fun_f1,Global,Basis,der_b.der_b1,tm);
    b1_tmp1 = assmble_vector_2D_time(all_funs.fun_f1,Global,Basis,der_b.der_b1,tmp1);
    b2_tmp1 = assmble_vector_2D_time(all_funs.fun_f2,Global,Basis,der_b.der_b2,tmp1);
 %% Get the initial guess Xm for Newton's iteration
    % Get the solution at tm, iteration step k
        u1h_vec_tm = X_old_tm(1:Basis.Nb_trail);         %phi
        u2h_vec_tm = X_old_tm(Basis.Nb_trail+1:end);   %w
        X_old_tmp1= 0.5*X_old_tm;
    for k = 1:max_iteration
        
        u1h_vec_tmp1 = X_old_tmp1(1:Basis.Nb_trail);         %phi
        u2h_vec_tmp1 = X_old_tmp1(Basis.Nb_trail+1:end);   %w
     
           %% ------------------Obtain AN stiff matrix ---------------------
        % u1h(l-1)^2, -3*r/eplso
        AN = assemble_matrix_2D_FE_coe_square(all_funs.fun_3r_eplson_fraction,'compute_wn',u1h_vec_tmp1,Global,Basis_coe,der_A.der_AN);
         %%  ------------------Obtain bN stiff matrix ---------------------
         % u1h(l-1)^3, -2*r/eplso
         bN = assemble_vector_2D_FE_coe_cubic(all_funs.fun_2r_eplson_fraction,'compute_wn',u1h_vec_tmp1,Global,Basis_coe,der_b.der_bN);
      
         % Get the A and b
            A= [M/dt theta*A1; A2 + AN M];
            b1=theta*b1_tmp1 + M/dt *u1h_vec_tm + (1-theta)*(b1_tm-A1*u2h_vec_tm);
            b2=b2_tmp1+bN + K* u1h_vec_tm;
            b=[b1;b2];
        
         %% ------------------ Handle Boundary conditions ---------------------
            [A,b]=treat_Dirichlet_boundary_2_variable_time( all_funs.fun_Diri_u,all_funs.fun_Diri_w, tmp1, A, b, boundarynodes, Basis.Pb_trail, Basis.Nb_trail);
        %% ------------------ Update Xmp1 - ---------------
            X_old_tmp1 =A\b;
    end
    X_old_tm= X_old_tmp1;
   
end

% Get the solution at the end time
solution = X_old_tm;

%% --------------------- compute  error--------------------------%%
% Compute errors at the end time
t = start_t:dt:end_t;
err = get_all_errors_time(solution,all_funs,Global,Basis,t);








