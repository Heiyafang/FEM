function bN= assemble_vector_2D_FE_coe_cubic(coe_fun,uh_fun,uh_vec1,Global, Basis_coe,der_bN)



basis_der_x_coe = der_bN(1,1);
basis_der_y_coe = der_bN(1,2);

basis_der_x_test = der_bN(2,1);
basis_der_y_test = der_bN(2,2);


bN= zeros(Basis_coe.matrix_size(1),1);
for n = 1:Global.N
    vertices = Global.P(:,Global.T(:,n)); % coordinates of nth mesh elements
    [Gauss_weights,Gauss_nodes] = generate_Gauss_local_2D(Global.element_type,vertices,Global.Gauss_type);
    uh_local_vec1 = uh_vec1(Basis_coe.Tb_test(:,n));

    for beta = 1:Basis_coe.N_lb_test
        r = Gauss_quad_2D_test_FE_coe_cubic( Global.element_type,coe_fun,uh_fun,uh_local_vec1,Gauss_weights,Gauss_nodes,vertices,...
                     Basis_coe.basis_type_test,beta,basis_der_x_test,basis_der_y_test, ...
                     Basis_coe.basis_type_coe,basis_der_x_coe,basis_der_y_coe);
        
        bN(Basis_coe.Tb_test(beta,n),1) = bN(Basis_coe.Tb_test(beta,n),1) + r;
        % d(beta,1) = Gauss_quad_1D_test(fun_f,Gauss_weights,Gauss_nodes,vertices,basis_type_test,basis_index_test,basis_der_x_test);
    end
    %b(Tb(:,n),1) = b(Tb(:,n),1) + d;
end