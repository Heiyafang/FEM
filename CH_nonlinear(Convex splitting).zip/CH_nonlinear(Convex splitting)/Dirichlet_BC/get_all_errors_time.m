function err = get_all_errors_time(solution,all_funs,Global,Basis,t)



%% ==========   Solution just use trial info   ======


solution1 = solution(1:Basis.Nb_trail);          %u
solution2 = solution(Basis.Nb_trail+1: end);   %w


L_inf_err_time_u = compute_L2_inf_err_time(Global.element_type,all_funs.fun_u_analytic,solution1,Global.P,Global.T,Basis.Tb_trail,Basis.basis_type_trial,0,0,Global.Gauss_type,t(end));% Tb for u, basis_type for u
L_inf_err_time_w = compute_L2_inf_err_time(Global.element_type,all_funs.fun_w_analytic,solution2,Global.P,Global.T,Basis.Tb_trail,Basis.basis_type_trial,0,0,Global.Gauss_type,t(end));% Tb for u, basis_type for u


L2_err_time_u = compute_L2_err_time(all_funs.fun_u_analytic,solution1,Global.element_type,Global.P,Global.T,Basis.Tb_trail,Global.Gauss_type,Basis.basis_type_trial,t(end));% Tb for u, basis_type for u
L2_err_time_w = compute_L2_err_time(all_funs.fun_w_analytic,solution2,Global.element_type,Global.P,Global.T,Basis.Tb_trail,Global.Gauss_type,Basis.basis_type_trial,t(end));% Tb for u, basis_type for u


H1_semi_err_time_u = compute_H1_err_time(all_funs.fun_u_analytic_der_x,all_funs.fun_u_analytic_der_y,solution1,Global.element_type,Global.P,Global.T,Basis.Tb_trail,Global.Gauss_type,Basis.basis_type_trial,t(end));% Tb for u, basis_type for u
H1_semi_err_time_w = compute_H1_err_time(all_funs.fun_w_analytic_der_x,all_funs.fun_w_analytic_der_y,solution2,Global.element_type,Global.P,Global.T,Basis.Tb_trail,Global.Gauss_type,Basis.basis_type_trial,t(end));% Tb for u, basis_type for u


%% --------------------store err------------------------
err.L_inf_err_u = L_inf_err_time_u;
err.L2_err_u = L2_err_time_u;
err.H1_semi_err_u = H1_semi_err_time_u;

err.L_inf_err_w = L_inf_err_time_w;
err.L2_err_w = L2_err_time_w;
err.H1_semi_err_w = H1_semi_err_time_w;

