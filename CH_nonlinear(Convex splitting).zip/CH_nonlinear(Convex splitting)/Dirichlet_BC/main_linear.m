%main
clear
clc
tic
format long e
%%   ------  Domain and mesh information  -----   %%
left = 0;
right = 1;
bottom = 0;
top = 1;
domain = [left, right; bottom, top];
clear left right top bottom
% Time domain
start_t = 0;
end_t = 1;

% Finite difference method
% theta = 1 is Backward Euler scheme, theta = 0 is Forward Euler scheme, theta = 1/2 is Crank_Nicolson(Trapezoidal) scheme
theta = 1; 


element_type = 'Triangular';% 'Triangular' or 'Rectangular'
basis_type_plot = 202;
basis_type_test = 202;
basis_type_trial = 202;
Gauss_type = 9;
max_iteration=20;
% 
h1=[1/4,1/8]';
h2=[1/4,1/8]';
dt = [1/8,1/64]';

for i = 1:length(h1)
   
    h{i}=[h1(i) h2(i)];
  

%% plot basis function 
    getPbTb=generate_2D_PbTb(domain, h{i}, basis_type_plot,element_type);% # tri and rec
    user_plot = 'false'; % false or true
    plot_basis_function(user_plot,basis_type_plot,element_type,getPbTb.Tb);
    clear getPbTb

%% Solver 
    [err(i),solution{i}] = FE_solver_2D_CH_nonlinear(element_type,theta,start_t,end_t,dt(i),domain,h{i},basis_type_trial, ...
                                         basis_type_test,Gauss_type,max_iteration);
end

%%  Compute error and Convergence
b=struct2cell(err);

% For phi
L_inf_error_phi=cell2mat(b(1,:))';
Convergence_L_inf_phi = log(L_inf_error_phi(1:end-1) ./ L_inf_error_phi(2:end)) ./ log(h1(1:end-1) ./ h1(2:end));
Convergence_L_inf_phi = [0;Convergence_L_inf_phi];

L2_norm_error_phi=cell2mat(b(2,:))';
Convergence_L2_phi = log(L2_norm_error_phi(1:end-1) ./ L2_norm_error_phi(2:end)) ./ log(h1(1:end-1) ./ h1(2:end));
Convergence_L2_phi = [0;Convergence_L2_phi];

H1_semi_error_phi=cell2mat(b(3,:))';
Convergence_H1_semi_phi = log(H1_semi_error_phi(1:end-1) ./ H1_semi_error_phi(2:end)) ./ log(h1(1:end-1) ./ h1(2:end));
Convergence_H1_semi_phi = [0;Convergence_H1_semi_phi];

% For w
L_inf_error_w=cell2mat(b(4,:))';
Convergence_L_inf_w = log(L_inf_error_w(1:end-1) ./ L_inf_error_w(2:end)) ./ log(h1(1:end-1) ./ h1(2:end));
Convergence_L_inf_w = [0;Convergence_L_inf_w];

L2_norm_error_w=cell2mat(b(5,:))';
Convergence_L2_w = log(L2_norm_error_w(1:end-1) ./ L2_norm_error_phi(2:end)) ./ log(h1(1:end-1) ./ h1(2:end));
Convergence_L2_w = [0;Convergence_L2_w];

H1_semi_error_w=cell2mat(b(6,:))';
Convergence_H1_semi_w = log(H1_semi_error_w(1:end-1) ./ H1_semi_error_w(2:end)) ./ log(h1(1:end-1) ./ h1(2:end));
Convergence_H1_semi_w = [0;Convergence_H1_semi_w];

%%  Show error and Convergence
%rowNames = {'h1=[1/8,1/8]';'h2=[1/16,1/16]';'h3=[1/32,1/32]';'h4 =[1/64,1/64]';'h5 =[1/128,1/128]'};
T_phi = table(h1,h2,L_inf_error_phi, Convergence_L_inf_phi,   L2_norm_error_phi, Convergence_L2_phi,  H1_semi_error_phi,Convergence_H1_semi_phi);
T_w = table(h1,h2,L_inf_error_w, Convergence_L_inf_w,   L2_norm_error_w, Convergence_L2_w,  H1_semi_error_w,Convergence_H1_semi_w);


%%  Store error and Convergence
%Open the file in append mode
fileID = fopen('Result_CH_nonlinear.txt', 'w'); 

% Append a separator line or any other information you want
headerText = '---------- Dirichlet boundary condition, linear basis funciton, Triangular element--------.\n';
fprintf(fileID, headerText);

headerText = '--------------------------------------------------------------------------------------------.\n';
fprintf(fileID, headerText);

% Append a separator line or any other information you want
headerText = '-----------This is the result for phi-----------------------------------\n';
fprintf(fileID, headerText);
% Append the table data
fprintf(fileID, ' h1 \t  h2 \t L_inf_error_u\t Convergence_L_inf_phi\t L2_norm_error_phi\t Convergence_L2_phi\t H1_semi_error_phi\t Convergence_H1_semi_phi\t \n');
for i = 1:height(T_phi)
    fprintf(fileID, '%.4f\t %.4f\t %.4e\t %.4e\t%.4e\t%.4e\t%.4e\t %.4e\n', T_phi.h1(1), T_phi.h2(i), T_phi.L_inf_error_phi(i),T_phi.Convergence_L_inf_phi(i), T_phi.L2_norm_error_phi(i),T_phi.Convergence_L2_phi(i), T_phi.H1_semi_error_phi(i),T_phi.Convergence_H1_semi_phi(i));
end

headerText = '--------------------------------------------------------------------------------------------.\n';
fprintf(fileID, headerText);
% Append a separator line or any other information you want
headerText = '-----------This is the result for w----------------------------------\n';
fprintf(fileID, headerText);

% Append the table data
fprintf(fileID, ' h1 \t  h2 \t L_inf_error_w\t Convergence_L_inf_w\t L2_norm_error_w\t Convergence_L2_w\t H1_semi_error_w\t Convergence_H1_semi_w\t \n');
for i = 1:height(T_phi)
    fprintf(fileID, '%.4f\t %.4f\t %.4e\t %.4e\t%.4e\t%.4e\t%.4e\t %.4e\n', T_w.h1(1), T_w.h2(i), T_w.L_inf_error_w(i),T_w.Convergence_L_inf_w(i), T_w.L2_norm_error_w(i),T_w.Convergence_L2_w(i), T_w.H1_semi_error_w(i),T_w.Convergence_H1_semi_w(i));
end

%Close the file
fclose(fileID);
fprintf("This is the result for phi\n")
disp(T_phi)
fprintf("This is the result for w \n")
disp(T_w)

