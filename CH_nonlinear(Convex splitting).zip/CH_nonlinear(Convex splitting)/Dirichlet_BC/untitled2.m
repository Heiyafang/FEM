syms x y t;

% parameters
Mc=1;
r=1;
eplson=1;


u= exp(x+y+t);
w=x*y*(1-x/2)*(1-y)*exp(x+y+t);



ut = diff(u,t);
% compute the Laplacian op
lap_w = laplacian(w, [x, y]);

f1 = ut-Mc*lap_w;

Lap_u=laplacian(u,[x,y]);
fu=1/eplson * u *(u^2-1);
f2 = w+r*eplson*Lap_u-r*fu;

% function f1 f2
fun_f1 = matlabFunction(f1, 'Vars', [x, y,t])

fun_f2 = matlabFunction(f2, 'Vars', [x, y,t])



wx=diff(w,x);
wy=diff(w,y);
% function of derivative 
fun_w_analytic_der_x = matlabFunction(wx, 'Vars', [x, y,t])
fun_w_analytic_der_y = matlabFunction(wy, 'Vars', [x, y,t])

ux=diff(u,x);
uy=diff(u,y);