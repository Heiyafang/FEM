function PAN = assemble_matrix_2D_FE_coe_square_2(coe_fun,uh_fun,uh,Global,Basis,der_A)
%----------------------------
% Assemble AN
% matrix_size(1) = Nb_test; matrix_size(2) = Nb_trail
% N: number of elements
% N_lb_trial : number of local basis trail function
% N_lb_test : number of local basis test function
% quad: quadrature
% uh_vec; Global solution
% uh_local_vec ; local solution
%---------------------------------


basis_der_x_trail = der_A(1,1);
basis_der_y_trail = der_A(1,2);
basis_der_x_test = der_A(2,1);
basis_der_y_test = der_A(2,2);
basis_der_x_coe = der_A(3,1);
basis_der_y_coe = der_A(3,2);
%N_lb_coe = N_lb_trial;

PAN = sparse (Basis.matrix_size(1), Basis.matrix_size(2));

for n=1:Global.N
    vertices = Global.P(:,Global.T(:,n)); % coordinates of nth mesh elements
    [Gauss_weights,Gauss_nodes] = generate_Gauss_local_2D(Global.element_type,vertices,Global.Gauss_type);
    uh_local_vec = uh(Basis.Tb_trail(:,n));
        for beta = 1: Basis.N_lb_test
            int_value =Gauss_quad_2D_trail_test_FE_coe_square_2(Global.element_type,coe_fun,uh_fun,uh_local_vec,Gauss_weights,Gauss_nodes,vertices,...
                     Basis.basis_type_test,beta,basis_der_x_test,basis_der_y_test, ...
                     Basis.basis_type_coe,basis_der_x_coe,basis_der_y_coe);
            PAN(Basis.Tb_test(beta,n),1) =  PAN(Basis.Tb_test(beta,n),1) + int_value;
        end
    %A(Tb_test(:,n),Tb_trail(:,n)) = A(Tb_test(:,n),Tb_trail(:,n))+S
end
